# Radio playback changes — v87

This revision replaces the fixed reusable block pool with the Spotpear 2.4.2 style bounded queue:

- HTTP reads are copied into individually allocated PSRAM chunks (up to 4096 bytes each).
- The queue is capped at 256 KiB and playback starts after a 32 KiB prebuffer.
- Chunks are released after being copied into the decoder input buffer.
- The decoder input scratch buffer is 16 KiB so retained partial-frame bytes and a full HTTP chunk can coexist; it refuses to truncate a chunk if this invariant is ever broken.
- PCM is sent through `codec->OutputData(*out_pcm)`, matching Spotpear.
- Both producer and consumer run flags are set before either thread starts, avoiding a race where the reader could exit before `is_playing_` became true.
- Decoder registries remain registered for firmware lifetime to avoid the earlier repeated-register/unregister allocator crash.

## Exclusive radio mode

- Assistant playback queues are reset when radio silent mode begins; WakeNet and voice processing are disabled.
- Assistant-toggle events and taps in the top area of the radio screen are ignored while radio is active.
- The drone map is hidden before radio starts; its polling task is allowed to exit before stream startup, and the map HTTP timeout is capped at 2.5 seconds.
- Attempting to show the map while radio is active is rejected.

The ZIP was structurally checked, but it has not been built with ESP-IDF in this environment or flashed to the board. A GitHub Actions build and on-device listening test are still required.


## v88 radio UI volume controls

- Added visible vintage-style `+` and `−` buttons on either side of the station name.
- Each touch changes independent radio volume by 5 percentage points, clamped to 0–100%.
- Added a small live volume percentage above the station name.
- New/default radio volume is 40%; one-time migration raises the previous factory default of 20% to 40%, while preserving a previously customized saved volume.
- Volume remains applied to radio PCM only and does not change assistant/TTS volume.
- Static source/ZIP checks only; this revision has not been compiled with ESP-IDF or tested on hardware.


## v93 changes
- Radio preset 2 now uses direct MP3 stream https://strm112.1.fm/crock_mobile_mp3, with migration from previous built-in station URLs.
- Initial/rebuffer threshold remains 64 KiB; maximum stream queue is 192 KiB.
- Removed periodic radio throughput/read-latency statistics and redundant normal-playback logs.
- Wake-word detection remains enabled while radio plays. When radio is launched from an active assistant turn, voice processing is disabled after a 7-second grace period; a detected wake word stops radio so the assistant can respond.


## MP3 player buffer

The online music player keeps the third-party `mydazy/esp_mp3_player` default compressed MP3 ring-buffer size. No build-time patch overrides the managed component buffer. The radio stream queue described above is a separate subsystem and is unchanged.
