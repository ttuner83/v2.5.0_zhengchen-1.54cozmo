# v84 build fix

Fixed the compile error in `Application::HandleStateChangedEvent()`: the generic `Board` class has no `GetWebRadio()` method. Added `TaijiWebRadio::IsAnyRadioActive()` as a board-specific static query and use it from `application.cc` under `CONFIG_BOARD_TYPE_TAIJI_PI_S3`.

Preserves v83 radio buffering (128 KiB minimum / 256 KiB maximum) and silent AFE/WakeNet behavior.

Archive integrity and source-level consistency checks were performed. A full ESP-IDF build was not available in this environment, so GitHub Actions remains the final compile verification.
