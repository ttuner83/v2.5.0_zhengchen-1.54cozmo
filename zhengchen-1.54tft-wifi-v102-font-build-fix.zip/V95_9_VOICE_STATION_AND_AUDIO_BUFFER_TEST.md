# v95-9 — voice station selection and speech playback experiment

Changes in this archive:

- Added `self.radio.play_station_by_name`. It matches the spoken station name against the live station list loaded from the existing Taiji web interface, so user-edited station names are supported without a hardcoded alias table.
- Name matching ignores spaces and punctuation, folds Russian uppercase/lowercase, and treats `ё` as `е`. It prefers exact/substring matches and uses a conservative fuzzy fallback.
- Increased the assistant speech playback queue from 2 to 4 Opus-decoded PCM blocks.
- Raised audio output task priority from 6 to 7 and Opus codec task priority from 2 to 5. CPU-core pinning was intentionally not changed, so this experiment isolates queue depth and scheduling priority more clearly.

Not yet implemented in this test archive:

- Legacy Muzofond and 33ve integrations are intentionally not used by the current music player. The active search source is the public Meting API only.

Validation status:

- Static source edits and ZIP integrity can be checked locally.
- No ESP-IDF build or device playback test has been performed in this environment.
