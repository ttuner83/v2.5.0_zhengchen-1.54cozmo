# Radio stutter fix (v89, based on v88)

Addressed the most likely application-side cause found in the v88 source:

1. The playback loop allowed `LISTENING` to continue, but PCM was emitted only when the device state was exactly `IDLE`. Frames decoded while the app remained in `LISTENING` were silently discarded, which could sound like interruptions. Output gating now matches the playback pause gate: output is paused only for SPEAKING, CONNECTING, ACTIVATING, and NOTIFYING.
2. Increased the compressed-stream queue from 256 KiB to 512 KiB (about 16 seconds at 256 kbit/s), and the startup prebuffer from 32 KiB to 64 KiB (about 2 seconds at 256 kbit/s).
3. When the live stream queue becomes empty, playback now waits for the 64 KiB rebuffer threshold instead of resuming after a single 4 KiB packet. A warning log is emitted on each underrun to help identify network/server stalls.

The 1.FM Rock Classics stream is listed as MP3 at up to 256 kbit/s; that bitrate alone should not overwhelm ESP32-S3. This patch targets silent PCM drops caused by the state check and improves tolerance to short network/server stalls.

Static source/ZIP checks only. No ESP-IDF build or hardware playback test has been run. If the new `Radio buffer underrun` warning repeats frequently, the remaining issue is likely incoming stream/network starvation or server-side instability rather than the decoder's PCM output gate.


## v92 station update
Replaced the built-in 1.FM Rock Classics preset with STAR FM Classic Rock at the broadcaster-listed MP3 128 kbit/s HTTPS stream. Added migration for the previous built-in station entry so a device using the old default URL is updated on first boot; unrelated custom stations are not overwritten.
