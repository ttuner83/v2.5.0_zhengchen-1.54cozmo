# v74 stability patch (Taiji Pi S3 / ESP-IDF 6.0.2)

Changes based on v73:

- Replaced the 10 ms `esp_timer` touch callback with a dedicated FreeRTOS task polling every 20 ms (50 Hz). Touch/swipe/map/radio/page-indicator behavior is retained; GUI methods continue to use the project's `DisplayLockGuard` synchronization.
- Pinned the AudioService audio-output task to Core 1 and raised its priority from 4 to 6. The audio-input task's existing priority/core arrangement is retained.
- Increased the radio stream's minimum pre-playback buffer from 32 KiB to 64 KiB; the maximum remains 384 KiB. This can reduce short network underruns at the cost of some additional startup buffering.
- Enabled `CONFIG_I2S_ISR_IRAM_SAFE=y` in ESP32-S3 defaults for the project's ESP-IDF I2S driver configuration.
- Bluetooth is not initialized during normal board startup in this board path; BLUFI is initialized only when the Wi-Fi provisioning flow requests it. This preserves existing Bluetooth-assisted Wi-Fi provisioning instead of globally disabling a dependency it may need.

Validation performed: ZIP integrity, source-level assertions for the changed task/buffer/configuration, and checks that existing radio and map control symbols remain. A full ESP-IDF/GitHub Actions build and on-device stress test were not available in this environment; run the project's GitHub Actions workflow before flashing.
