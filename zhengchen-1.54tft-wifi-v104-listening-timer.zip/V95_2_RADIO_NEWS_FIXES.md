# v95-2 — radio controls, Argus locations and spoken news

Changes relative to v95-1:

- Radio stop MCP tool has an explicit Russian instruction and returns a spoken confirmation.
- Station changes are serialized in a worker task so LVGL/touch/MCP callbacks do not block while old stream threads stop. Only the latest pending station request is retained.
- Radio HTTP reads use a bounded timeout and the downloader exits immediately after a stop request instead of attempting another reconnect.
- Stopping radio during an active assistant turn no longer asks the application to tear down that voice turn.
- The one-shot Argus query includes Crimea, Anapa, Temryuk, the Sea of Azov and northern Sea of Azov locations; recognized threat-type events are included and resolved/expired statuses are ignored.
- Added the one-shot `self.news.get_main_news` tool for `https://news.yandex.ru/index.rss`, returning up to three RSS items for spoken reading and short conversational commentary after each.

The existing GitHub Actions workflow is unchanged. Archive/source checks only were performed; a full ESP-IDF build and hardware test have not been run.
