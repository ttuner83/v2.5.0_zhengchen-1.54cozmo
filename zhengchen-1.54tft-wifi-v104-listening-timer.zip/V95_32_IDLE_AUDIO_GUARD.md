# v95-32 idle/audio guard

- Idle display-off timeout now requires `CanEnterSleepMode()`, which rejects sleep while the protocol audio channel remains open or the audio service is busy.
- While audio/network response work is still active, the idle countdown is refreshed. The full configured timeout starts after the response has finished, instead of expiring during assistant speech.
- Wi-Fi power-save policy now treats an open audio channel or busy audio service as active work, keeping `WIFI_PS_NONE` until the response tail has drained.
- The existing maximum battery saving behavior remains enabled after a genuinely idle timeout.
