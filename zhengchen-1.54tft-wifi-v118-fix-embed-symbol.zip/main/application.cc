#include "application.h"

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
#include "boards/taiji-pi-s3/taiji_web_radio.h"
#endif
#include "assets.h"
#include "assets/lang_config.h"
#include "audio_codec.h"
#include "board.h"
#include "display.h"
#include "mcp_server.h"
#include "mqtt_protocol.h"
#include "settings.h"
#include "system_info.h"
#include "text_glyph_payload.h"
#include "websocket_protocol.h"

#include <driver/gpio.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <esp_wifi.h>
#include <arpa/inet.h>
#include <cJSON.h>
#include <cstring>
#include <limits>

#define TAG "Application"

// Embedded 2.55-second local reminder fanfare (assets/common/reminder.ogg).
extern "C" const uint8_t reminder_ogg_start[] asm("_binary_assets_common_reminder_ogg_start");
extern "C" const uint8_t reminder_ogg_end[] asm("_binary_assets_common_reminder_ogg_end");

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
static bool IsRadioStopVoiceCommand(const std::string& text) {
    // STT normally emits lowercase text; include common capitalization variants too.
    // STT sends a transcript, not a command intent. Match explicit stop phrases
    // locally so stopping playback never depends on the cloud LLM calling MCP.
    static const char* phrases[] = {
        "выключи радио", "Выключи радио", "ВЫКЛЮЧИ РАДИО", "Выключи Радио",
        "выключи, пожалуйста, радио", "выключи радио пожалуйста", "радио выключи",
        "выруби радио", "Выруби радио", "ВЫРУБИ РАДИО",
        "отключи радио", "Отключи радио", "ОТКЛЮЧИ РАДИО",
        "останови радио", "Останови радио", "ОСТАНОВИ РАДИО",
        "останови радиостанцию", "останови музыку", "прекрати радио",
        "хватит радио", "Хватит радио", "ХВАТИТ РАДИО",
        "радио, выключи", "Радио выключи", "Радио, выключи",
        "стоп радио", "Стоп радио", "СТОП РАДИО", "радио стоп",
        "выключи музыку", "Выключи музыку", "отключи музыку", "Отключи музыку"
    };
    for (const char* phrase : phrases) {
        if (text.find(phrase) != std::string::npos) return true;
    }
    return false;
}
#endif

Application::Application() : notify_player_(audio_service_) {
    event_group_ = xEventGroupCreate();

#if CONFIG_USE_DEVICE_AEC && CONFIG_USE_SERVER_AEC
#error "CONFIG_USE_DEVICE_AEC and CONFIG_USE_SERVER_AEC cannot be enabled at the same time"
#elif CONFIG_USE_DEVICE_AEC
    aec_mode_ = kAecOnDeviceSide;
#elif CONFIG_USE_SERVER_AEC
    aec_mode_ = kAecOnServerSide;
#else
    aec_mode_ = kAecOff;
#endif

    esp_timer_create_args_t clock_timer_args = {.callback =
                                                    [](void* arg) {
                                                        Application* app = (Application*)arg;
                                                        xEventGroupSetBits(app->event_group_,
                                                                           MAIN_EVENT_CLOCK_TICK);
                                                    },
                                                .arg = this,
                                                .dispatch_method = ESP_TIMER_TASK,
                                                .name = "clock_timer",
                                                .skip_unhandled_events = true};
    esp_timer_create(&clock_timer_args, &clock_timer_handle_);

    // <ttuner83> One-shot voice reminder timer; it does not alter normal idle sleep.
    esp_timer_create_args_t reminder_args = {
        .callback = &Application::VoiceReminderTimerCallback,
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "voice_reminder",
        .skip_unhandled_events = true,
    };
    esp_timer_create(&reminder_args, &voice_reminder_timer_);

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    esp_timer_create_args_t radio_grace_args = {
        .callback = &Application::RadioVoiceGraceTimerCallback,
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "radio_voice_grace",
        .skip_unhandled_events = true,
    };
    esp_timer_create(&radio_grace_args, &radio_voice_grace_timer_);
#endif
}

Application::~Application() {
    notify_player_.Stop();
    if (voice_reminder_timer_ != nullptr) {
        esp_timer_stop(voice_reminder_timer_);
        esp_timer_delete(voice_reminder_timer_);
    }
    if (clock_timer_handle_ != nullptr) {
        esp_timer_stop(clock_timer_handle_);
        esp_timer_delete(clock_timer_handle_);
    }
    if (radio_voice_grace_timer_ != nullptr) {
        esp_timer_stop(radio_voice_grace_timer_);
        esp_timer_delete(radio_voice_grace_timer_);
    }
    vEventGroupDelete(event_group_);
}

bool Application::SetDeviceState(DeviceState state) {
    const DeviceState previous = state_machine_.GetState();
    const bool changed = state_machine_.TransitionTo(state);
    if (changed && state != previous) {
        if (state == kDeviceStateIdle) {
            idle_since_us_ = esp_timer_get_time();
        } else {
            idle_since_us_ = 0;
            if (idle_display_off_) {
                idle_display_off_ = false;
                auto& board = Board::GetInstance();
                auto display = board.GetDisplay();
                if (display) display->SetPowerSaveMode(false);
                if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
                board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
                esp_err_t wifi_err = esp_wifi_set_ps(WIFI_PS_NONE);
                if (wifi_err != ESP_OK) ESP_LOGW(TAG, "Could not restore Wi-Fi performance mode: %s", esp_err_to_name(wifi_err));
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
                TaijiWebRadio::UpdateWifiPowerSave();
#endif
                ESP_LOGI(TAG, "Idle screen wake: display/backlight restored");
            }
        }
    }
    return changed;
}

void Application::Initialize() {
    auto& board = Board::GetInstance();
    SetDeviceState(kDeviceStateStarting);

    // Setup the display
    auto display = board.GetDisplay();
    display->SetupUI();
    // Print board name/version info
    display->SetChatMessage("system", SystemInfo::GetUserAgent().c_str());

    // Setup the audio service
    auto codec = board.GetAudioCodec();
    audio_service_.Initialize(codec);
    audio_service_.Start();
    ESP_LOGI(TAG, "After board/audio init");
    SystemInfo::PrintHeapStats();

    AudioServiceCallbacks callbacks;
    callbacks.on_send_queue_available = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_SEND_AUDIO);
    };
    callbacks.on_wake_word_detected = [this](const std::string& wake_word) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_WAKE_WORD_DETECTED);
    };
    callbacks.on_vad_change = [this](bool speaking) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_VAD_CHANGE);
    };
    callbacks.on_playback_drained = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_PLAYBACK_DRAINED);
    };
    callbacks.on_playback_progress = [this](uint32_t playback_id, uint32_t media_position_ms) {
        notify_player_.OnPlaybackProgress(playback_id, media_position_ms);
    };
    audio_service_.SetCallbacks(callbacks);

    // Add state change listeners
    state_machine_.AddStateChangeListener([this](DeviceState old_state, DeviceState new_state) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_STATE_CHANGED);
    });

    // Start the clock timer to update the status bar
    esp_timer_start_periodic(clock_timer_handle_, 1000000);

    // Add MCP common tools (only once during initialization)
    auto& mcp_server = McpServer::GetInstance();
    mcp_server.AddCommonTools();
    mcp_server.AddUserOnlyTools();

    // Set network event callback for UI updates and network state handling
    board.SetNetworkEventCallback([this](NetworkEvent event, const std::string& data) {
        auto display = Board::GetInstance().GetDisplay();

        switch (event) {
            case NetworkEvent::Scanning:
                display->ShowNotification(Lang::Strings::SCANNING_WIFI, 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::Connecting: {
                if (data.empty()) {
                    // Cellular network - registering without carrier info yet
                    display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                } else {
                    // WiFi or cellular with carrier info
                    std::string msg = Lang::Strings::CONNECT_TO;
                    msg += data;
                    msg += "...";
                    display->ShowNotification(msg.c_str(), 30000);
                }
                break;
            }
            case NetworkEvent::Connected: {
                std::string msg = Lang::Strings::CONNECTED_TO;
                msg += data;
                display->ShowNotification(msg.c_str(), 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_CONNECTED);
                break;
            }
            case NetworkEvent::Disconnected:
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::WifiConfigModeEnter:
                // WiFi config mode enter is handled by WifiBoard internally
                break;
            case NetworkEvent::WifiConfigModeExit:
                // WiFi config mode exit is handled by WifiBoard internally
                break;
            // Cellular modem specific events
            case NetworkEvent::ModemDetecting:
                display->SetStatus(Lang::Strings::DETECTING_MODULE);
                break;
            case NetworkEvent::ModemErrorNoSim:
                Alert(Lang::Strings::ERROR, Lang::Strings::PIN_ERROR, "warning",
                      Lang::Sounds::OGG_ERR_PIN);
                break;
            case NetworkEvent::ModemErrorRegDenied:
                Alert(Lang::Strings::ERROR, Lang::Strings::REG_ERROR, "warning",
                      Lang::Sounds::OGG_ERR_REG);
                break;
            case NetworkEvent::ModemErrorInitFailed:
                Alert(Lang::Strings::ERROR, Lang::Strings::MODEM_INIT_ERROR, "warning",
                      Lang::Sounds::OGG_EXCLAMATION);
                break;
            case NetworkEvent::ModemErrorTimeout:
                display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                break;
        }
    });

    // Start network asynchronously
    board.StartNetwork();

    // Update the status bar immediately to show the network state
    display->UpdateStatusBar(true);
}

void Application::Run() {
    // Set the priority of the main task to 10
    vTaskPrioritySet(nullptr, 10);

    const EventBits_t ALL_EVENTS =
        MAIN_EVENT_SCHEDULE | MAIN_EVENT_SEND_AUDIO | MAIN_EVENT_WAKE_WORD_DETECTED |
        MAIN_EVENT_VAD_CHANGE | MAIN_EVENT_CLOCK_TICK | MAIN_EVENT_ERROR |
        MAIN_EVENT_NETWORK_CONNECTED | MAIN_EVENT_NETWORK_DISCONNECTED | MAIN_EVENT_TOGGLE_CHAT |
        MAIN_EVENT_START_LISTENING | MAIN_EVENT_STOP_LISTENING | MAIN_EVENT_ACTIVATION_DONE |
        MAIN_EVENT_STATE_CHANGED | MAIN_EVENT_PLAYBACK_DRAINED;

    while (true) {
        auto bits = xEventGroupWaitBits(event_group_, ALL_EVENTS, pdTRUE, pdFALSE, portMAX_DELAY);

        if (bits & MAIN_EVENT_ERROR) {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
            }
            SetDeviceState(kDeviceStateIdle);
            Alert(Lang::Strings::ERROR, last_error_message_.c_str(), "cancel",
                  Lang::Sounds::OGG_EXCLAMATION);
        }

        if (bits & MAIN_EVENT_NETWORK_CONNECTED) {
            HandleNetworkConnectedEvent();
        }

        if (bits & MAIN_EVENT_NETWORK_DISCONNECTED) {
            HandleNetworkDisconnectedEvent();
        }

        if (bits & MAIN_EVENT_ACTIVATION_DONE) {
            HandleActivationDoneEvent();
        }

        if (bits & MAIN_EVENT_STATE_CHANGED) {
            HandleStateChangedEvent();
        }

        if (bits & MAIN_EVENT_PLAYBACK_DRAINED) {
            if (audio_service_.IsPlaybackIdle()) {
                notify_player_.OnPlaybackDrained();
            }
            // Deferred listening start (auto mode): the playback queue has
            // drained, so it is now safe to enable voice processing.
            if (pending_listening_start_ && GetDeviceState() == kDeviceStateListening &&
                audio_service_.IsPlaybackIdle()) {
                pending_listening_start_ = false;
                StartListeningAudio();
            }
        }

        if (bits & MAIN_EVENT_TOGGLE_CHAT) {
            HandleToggleChatEvent();
        }

        if (bits & MAIN_EVENT_START_LISTENING) {
            HandleStartListeningEvent();
        }

        if (bits & MAIN_EVENT_STOP_LISTENING) {
            HandleStopListeningEvent();
        }

        if (bits & MAIN_EVENT_SEND_AUDIO) {
            while (auto packet = audio_service_.PopPacketFromSendQueue()) {
                if (protocol_ && !protocol_->SendAudio(std::move(packet))) {
                    // Drop the remaining packets. Leaving them in the queue would
                    // stall the Opus codec task (it waits for queue space), which in
                    // turn deadlocks the whole audio input pipeline, as no new
                    // MAIN_EVENT_SEND_AUDIO event would ever be triggered again.
                    while (audio_service_.PopPacketFromSendQueue())
                        ;
                    break;
                }
            }
        }

        if (bits & MAIN_EVENT_WAKE_WORD_DETECTED) {
            HandleWakeWordDetectedEvent();
        }

        if (bits & MAIN_EVENT_VAD_CHANGE) {
            if (GetDeviceState() == kDeviceStateListening) {
                auto led = Board::GetInstance().GetLed();
                led->OnStateChanged();
            }
        }

        if (bits & MAIN_EVENT_SCHEDULE) {
            std::unique_lock<std::mutex> lock(mutex_);
            auto tasks = std::move(main_tasks_);
            lock.unlock();
            for (auto& task : tasks) {
                task();
            }
        }

        if (bits & MAIN_EVENT_CLOCK_TICK) {
            clock_ticks_++;
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
            // Bound each continuous listening window independently from the idle/sleep timer.
            if (GetDeviceState() == kDeviceStateListening) {
                if (listening_since_us_ == 0) listening_since_us_ = esp_timer_get_time();
                const int listen_timeout_seconds = TaijiWebRadio::GetListeningTimeoutSeconds();
                if (esp_timer_get_time() - listening_since_us_ >= static_cast<int64_t>(listen_timeout_seconds) * 1000000LL) {
                    ESP_LOGI(TAG, "Listening timeout (%d s): stop listening", listen_timeout_seconds);
                    if (protocol_) protocol_->SendStopListening();
                    listening_since_us_ = 0;
                    SetDeviceState(kDeviceStateIdle);
                }
            } else {
                listening_since_us_ = 0;
            }
#endif
            auto& board = Board::GetInstance();
            auto display = board.GetDisplay();
            display->UpdateStatusBar();
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
            if (GetDeviceState() == kDeviceStateIdle && !idle_display_off_ && idle_since_us_ > 0 &&
                !TaijiWebRadio::IsAnyRadioActive()) {
                const int timeout_seconds = TaijiWebRadio::GetIdleTimeoutSeconds();
                // The state machine can return to IDLE before the assistant's final
                // audio packets have drained. Never dim the display or enter deep
                // Wi-Fi modem sleep while the protocol/audio pipeline is still busy.
                // Restart the countdown while busy so the full timeout starts only
                // after the response and audio channel have actually finished.
                if (!CanEnterSleepMode()) {
                    idle_since_us_ = esp_timer_get_time();
                } else if (esp_timer_get_time() - idle_since_us_ >= static_cast<int64_t>(timeout_seconds) * 1000000LL) {
                    display->SetPowerSaveMode(true);
                    if (auto backlight = board.GetBacklight()) backlight->TurnOff();
                    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
                    esp_err_t wifi_err = esp_wifi_set_ps(WIFI_PS_MAX_MODEM);
                    if (wifi_err != ESP_OK) ESP_LOGW(TAG, "Could not set maximum Wi-Fi modem sleep: %s", esp_err_to_name(wifi_err));
                    idle_display_off_ = true;
                    ESP_LOGI(TAG, "Idle timeout (%d s): display off, maximum power saving", timeout_seconds);
                }
            }
#endif

            // Print debug info every 10 seconds
            if (clock_ticks_ % 10 == 0) {
                SystemInfo::PrintHeapStats();
                // SystemInfo::PrintTaskList();
                // SystemInfo::PrintTaskCpuUsage(pdMS_TO_TICKS(1000));
            }
        }
    }
}

void Application::HandleNetworkConnectedEvent() {
    ESP_LOGI(TAG, "Network connected");
    auto state = GetDeviceState();

    if (state == kDeviceStateStarting || state == kDeviceStateWifiConfiguring) {
        // Network is ready, start activation
        SetDeviceState(kDeviceStateActivating);
        if (activation_task_handle_ != nullptr) {
            ESP_LOGW(TAG, "Activation task already running");
            return;
        }

        xTaskCreate(
            [](void* arg) {
                Application* app = static_cast<Application*>(arg);
                app->ActivationTask();
                app->activation_task_handle_ = nullptr;
                vTaskDelete(NULL);
            },
            "activation", 4096 * 2, this, 2, &activation_task_handle_);
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleNetworkDisconnectedEvent() {
    // Close current conversation when network disconnected
    auto state = GetDeviceState();
    if (state == kDeviceStateNotifying) {
        StopNotification();
    }
    if (state == kDeviceStateConnecting || state == kDeviceStateListening ||
        state == kDeviceStateSpeaking) {
        ESP_LOGI(TAG, "Closing audio channel due to network disconnection");
        protocol_->CloseAudioChannel();
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleActivationDoneEvent() {
    ESP_LOGI(TAG, "Activation done");

    SystemInfo::PrintHeapStats();
    SetDeviceState(kDeviceStateIdle);

    has_server_time_ = ota_->HasServerTime();

    // Protocol start may have already raised MAIN_EVENT_ERROR. Do not replace
    // that alert with the "ready" UI/sound — the main loop can process both
    // events back-to-back because the activation task is lower priority.
    const bool has_error = !last_error_message_.empty();
    if (!has_error) {
        auto display = Board::GetInstance().GetDisplay();
        std::string message = std::string(Lang::Strings::VERSION) + ota_->GetCurrentVersion();
        display->ShowNotification(message.c_str());
        display->SetChatMessage("system", "");
    }

    // Release OTA object after activation is complete
    ota_.reset();
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

    if (!has_error) {
        Schedule([this]() {
            // Play the success sound to indicate the device is ready
            audio_service_.PlaySound(Lang::Sounds::OGG_SUCCESS);
        });
    }
}

void Application::ActivationTask() {
    // Create OTA object for activation process
    ota_ = std::make_unique<Ota>();

    // Check for new assets version
    CheckAssetsVersion();

    // Check for new firmware version
    CheckNewVersion();

    // Initialize the protocol
    InitializeProtocol();

    // Signal completion to main loop
    xEventGroupSetBits(event_group_, MAIN_EVENT_ACTIVATION_DONE);
}

void Application::CheckAssetsVersion() {
    // Only allow CheckAssetsVersion to be called once
    if (assets_version_checked_) {
        return;
    }
    assets_version_checked_ = true;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto& assets = Assets::GetInstance();

    if (!assets.partition_valid()) {
        ESP_LOGW(TAG, "Assets partition is disabled for board %s", BOARD_NAME);
        return;
    }

    Settings settings("assets", true);
    // Check if there is a new assets need to be downloaded
    std::string download_url = settings.GetString("download_url");

    if (!download_url.empty()) {
        settings.EraseKey("download_url");

        char message[256];
        snprintf(message, sizeof(message), Lang::Strings::FOUND_NEW_ASSETS, download_url.c_str());
        Alert(Lang::Strings::LOADING_ASSETS, message, "cloud_download", Lang::Sounds::OGG_UPGRADE);

        // Wait for the audio service to be idle for 3 seconds
        vTaskDelay(pdMS_TO_TICKS(3000));
        SetDeviceState(kDeviceStateUpgrading);
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        display->SetChatMessage("system", Lang::Strings::PLEASE_WAIT);

        bool success =
            assets.Download(download_url, [this, display](int progress, size_t speed) -> void {
                char buffer[32];
                snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
                Schedule([display, message = std::string(buffer)]() {
                    display->SetChatMessage("system", message.c_str());
                });
            });

        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        vTaskDelay(pdMS_TO_TICKS(1000));

        if (!success) {
            Alert(Lang::Strings::ERROR, Lang::Strings::DOWNLOAD_ASSETS_FAILED, "cancel",
                  Lang::Sounds::OGG_EXCLAMATION);
            vTaskDelay(pdMS_TO_TICKS(2000));
            SetDeviceState(kDeviceStateActivating);
            return;
        }
    }

    // Apply assets
    assets.Apply();
    display->SetChatMessage("system", "");
    display->SetEmotion("robot_2");
}

void Application::CheckNewVersion() {
    const int MAX_RETRY = 10;
    int retry_count = 0;
    int retry_delay = 10;  // Initial retry delay in seconds

    auto& board = Board::GetInstance();
    while (true) {
        auto display = board.GetDisplay();
        display->SetStatus(Lang::Strings::CHECKING_NEW_VERSION);

        auto check = ota_->CheckVersion();
        if (!check) {
            retry_count++;
            if (retry_count >= MAX_RETRY) {
                ESP_LOGE(TAG, "Too many retries, exit version check");
                return;
            }

            const auto& err = check.error();
            char error_message[160];
            int error_message_length =
                snprintf(error_message, sizeof(error_message), "%s", err.ToString().c_str());
            if (error_message_length < 0 ||
                error_message_length >= static_cast<int>(sizeof(error_message))) {
                snprintf(error_message, sizeof(error_message), "%s", err.Message());
            }

            char buffer[320];
            int alert_message_length =
                snprintf(buffer, sizeof(buffer), Lang::Strings::CHECK_NEW_VERSION_FAILED,
                         retry_delay, error_message);
            if (alert_message_length < 0 ||
                alert_message_length >= static_cast<int>(sizeof(buffer))) {
                snprintf(buffer, sizeof(buffer), "%s", err.Message());
            }
            Alert(Lang::Strings::ERROR, buffer, "cloud_off", Lang::Sounds::OGG_EXCLAMATION);

            ESP_LOGW(TAG, "Check new version failed, retry in %d seconds (%d/%d)", retry_delay,
                     retry_count, MAX_RETRY);
            for (int i = 0; i < retry_delay; i++) {
                vTaskDelay(pdMS_TO_TICKS(1000));
                if (GetDeviceState() == kDeviceStateIdle) {
                    break;
                }
            }
            retry_delay *= 2;  // Double the retry delay
            continue;
        }
        retry_count = 0;
        retry_delay = 10;  // Reset retry delay

        if (ota_->HasNewVersion()) {
            if (UpgradeFirmware(ota_->GetFirmwareUrl(), ota_->GetFirmwareVersion())) {
                return;  // This line will never be reached after reboot
            }
            // If upgrade failed, continue to normal operation
        }

        // No new version, mark the current version as valid
        ota_->MarkCurrentVersionValid();
        if (!ota_->HasActivationCode() && !ota_->HasActivationChallenge()) {
            // Exit the loop if done checking new version
            break;
        }

        display->SetStatus(Lang::Strings::ACTIVATION);
        // Activation code is shown to the user and waiting for the user to input
        if (ota_->HasActivationCode()) {
            ShowActivationCode(ota_->GetActivationCode(), ota_->GetActivationMessage());
        }

        // This will block the loop until the activation is done or timeout
        for (int i = 0; i < 10; ++i) {
            ESP_LOGI(TAG, "Activating... %d/%d", i + 1, 10);
            esp_err_t err = ota_->Activate();
            if (err == ESP_OK) {
                break;
            } else if (err == ESP_ERR_TIMEOUT) {
                vTaskDelay(pdMS_TO_TICKS(3000));
            } else {
                vTaskDelay(pdMS_TO_TICKS(10000));
            }
            if (GetDeviceState() == kDeviceStateIdle) {
                break;
            }
        }
    }
}

void Application::InitializeProtocol() {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto codec = board.GetAudioCodec();

    display->SetStatus(Lang::Strings::LOADING_PROTOCOL);

    if (ota_->HasMqttConfig()) {
        protocol_ = std::make_unique<MqttProtocol>();
    } else if (ota_->HasWebsocketConfig()) {
        protocol_ = std::make_unique<WebsocketProtocol>();
    } else {
        ESP_LOGW(TAG, "No protocol specified in the OTA config, using MQTT");
        protocol_ = std::make_unique<MqttProtocol>();
    }

    protocol_->OnConnected([this]() { DismissAlert(); });

    protocol_->OnNetworkError([this](const std::string& message) {
        last_error_message_ = message;
        xEventGroupSetBits(event_group_, MAIN_EVENT_ERROR);
    });

    protocol_->OnIncomingAudio([this](std::unique_ptr<AudioStreamPacket> packet) {
        if (GetDeviceState() == kDeviceStateSpeaking) {
            audio_service_.PushPacketToDecodeQueue(std::move(packet));
        }
    });

    protocol_->OnAudioChannelOpened([this, codec, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        if (protocol_->server_sample_rate() != codec->output_sample_rate()) {
            ESP_LOGW(TAG,
                     "Server sample rate %d does not match device output sample rate %d, "
                     "resampling may cause distortion",
                     protocol_->server_sample_rate(), codec->output_sample_rate());
        }
    });

    protocol_->OnAudioChannelClosed([this, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        Schedule([this]() {
            auto display = Board::GetInstance().GetDisplay();
            display->SetChatMessage("system", "");
            SetDeviceState(kDeviceStateIdle);
        });
    });

    protocol_->OnIncomingJson([this, display](const cJSON* root) {
        // Parse JSON data
        auto type = cJSON_GetObjectItem(root, "type");
        if (!cJSON_IsString(type)) {
            ESP_LOGW(TAG, "Incoming JSON message has no type");
            return;
        }
        if (strcmp(type->valuestring, "notify") == 0) {
            auto audio_url = cJSON_GetObjectItem(root, "audio_url");
            if (!cJSON_IsString(audio_url) || audio_url->valuestring[0] == '\0') {
                ESP_LOGW(TAG, "Notify message requires audio_url");
                return;
            }

            std::vector<NotifySubtitle> subtitles;
            auto subtitles_json = cJSON_GetObjectItem(root, "subtitles");
            if (subtitles_json != nullptr && !cJSON_IsArray(subtitles_json)) {
                ESP_LOGW(TAG, "Notify subtitles must be an array");
                return;
            }
            if (cJSON_IsArray(subtitles_json)) {
                cJSON* item = nullptr;
                cJSON_ArrayForEach (item, subtitles_json) {
                    auto start_ms = cJSON_GetObjectItem(item, "start_ms");
                    auto text = cJSON_GetObjectItem(item, "text");
                    if (!cJSON_IsNumber(start_ms) || start_ms->valuedouble < 0 ||
                        start_ms->valuedouble > std::numeric_limits<uint32_t>::max() ||
                        !cJSON_IsString(text)) {
                        ESP_LOGW(TAG, "Ignoring invalid notify subtitle");
                        continue;
                    }
                    subtitles.push_back({.start_ms = static_cast<uint32_t>(start_ms->valuedouble),
                                         .text = text->valuestring});
                }
            }

            Schedule([this, url = std::string(audio_url->valuestring),
                      subtitles = std::move(subtitles)]() mutable {
                StartNotification(std::move(url), std::move(subtitles));
            });
        } else if (strcmp(type->valuestring, "tts") == 0) {
            auto state = cJSON_GetObjectItem(root, "state");
            if (!cJSON_IsString(state)) {
                return;
            }
            if (strcmp(state->valuestring, "start") == 0) {
                Schedule([this]() {
                    aborted_ = false;
                    SetDeviceState(kDeviceStateSpeaking);
                });
            } else if (strcmp(state->valuestring, "stop") == 0) {
                Schedule([this]() {
                    if (GetDeviceState() == kDeviceStateSpeaking) {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
                        if (TaijiWebRadio::IsAnyRadioActive()) {
                            radio_voice_processing_grace_ = true;
                            TaijiWebRadio::SetAssistantDuck(true);
                            if (protocol_) protocol_->SendStopListening();
                            SetDeviceState(kDeviceStateIdle);
                            return;
                        }
#endif
                        if (listening_mode_ == kListeningModeManualStop) SetDeviceState(kDeviceStateIdle);
                        else SetDeviceState(kDeviceStateListening);
                    }
                });
            } else if (strcmp(state->valuestring, "sentence_start") == 0) {
                auto text = cJSON_GetObjectItem(root, "text");
                if (cJSON_IsString(text)) {
                    std::vector<TextGlyph> glyphs;
                    uint8_t bpp = 0;
                    if (!TextGlyphPayload::Parse(root, glyphs, bpp)) {
                        glyphs.clear();
                    }
                    ESP_LOGI(TAG, "<< %s", text->valuestring);
                    Schedule([display, message = std::string(text->valuestring),
                              glyphs = std::move(glyphs), bpp]() {
                        display->AddTextGlyphs(glyphs, bpp);
                        display->SetChatMessage("assistant", message.c_str());
                    });
                }
            }
        } else if (strcmp(type->valuestring, "stt") == 0) {
            auto text = cJSON_GetObjectItem(root, "text");
            if (cJSON_IsString(text)) {
                std::vector<TextGlyph> glyphs;
                uint8_t bpp = 0;
                if (!TextGlyphPayload::Parse(root, glyphs, bpp)) {
                    glyphs.clear();
                }
                ESP_LOGI(TAG, ">> %s", text->valuestring);
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
                // Do not depend on the cloud model deciding to call MCP for this
                // safety-critical local control: stop the radio as soon as STT
                // recognizes the explicit command, on a worker so the protocol
                // receive callback and main event loop are not blocked.
                if (IsRadioStopVoiceCommand(text->valuestring)) {
                    ESP_LOGI(TAG, "Recognized local radio-stop command from STT: %s", text->valuestring);
                    BaseType_t task_ok = xTaskCreate(
                        [](void*) {
                            const bool stopped = TaijiWebRadio::StopActiveRadioFromVoice();
                            ESP_LOGI(TAG, "Local radio-stop result: %s", stopped ? "stopped" : "not stopped");
                            vTaskDelete(nullptr);
                        }, "voice_radio_stop", 3072, nullptr, 7, nullptr);
                    if (task_ok != pdPASS) {
                        ESP_LOGW(TAG, "Could not create local radio-stop task");
                    }
                }
#endif
                Schedule([display, message = std::string(text->valuestring),
                          glyphs = std::move(glyphs), bpp]() {
                    display->AddTextGlyphs(glyphs, bpp);
                    display->SetChatMessage("user", message.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "llm") == 0) {
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(emotion)) {
                Schedule([display, emotion_str = std::string(emotion->valuestring)]() {
                    display->SetEmotion(emotion_str.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "mcp") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            if (cJSON_IsObject(payload)) {
                McpServer::GetInstance().ParseMessage(payload);
            }
        } else if (strcmp(type->valuestring, "system") == 0) {
            auto command = cJSON_GetObjectItem(root, "command");
            if (cJSON_IsString(command)) {
                ESP_LOGI(TAG, "System command: %s", command->valuestring);
                if (strcmp(command->valuestring, "reboot") == 0) {
                    // Do a reboot if user requests a OTA update
                    Schedule([this]() { Reboot(); });
                } else {
                    ESP_LOGW(TAG, "Unknown system command: %s", command->valuestring);
                }
            }
        } else if (strcmp(type->valuestring, "alert") == 0) {
            auto status = cJSON_GetObjectItem(root, "status");
            auto message = cJSON_GetObjectItem(root, "message");
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(status) && cJSON_IsString(message) && cJSON_IsString(emotion)) {
                Alert(status->valuestring, message->valuestring, emotion->valuestring,
                      Lang::Sounds::OGG_VIBRATION);
            } else {
                ESP_LOGW(TAG, "Alert command requires status, message and emotion");
            }
#if CONFIG_RECEIVE_CUSTOM_MESSAGE
        } else if (strcmp(type->valuestring, "custom") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            ESP_LOGI(TAG, "Received custom message: %s", cJSON_PrintUnformatted(root));
            if (cJSON_IsObject(payload)) {
                Schedule(
                    [this, display, payload_str = std::string(cJSON_PrintUnformatted(payload))]() {
                        display->SetChatMessage("system", payload_str.c_str());
                    });
            } else {
                ESP_LOGW(TAG, "Invalid custom message format: missing payload");
            }
#endif
        } else {
            ESP_LOGW(TAG, "Unknown message type: %s", type->valuestring);
        }
    });

    protocol_->Start();
}

void Application::ShowActivationCode(const std::string& code, const std::string& message) {
    struct digit_sound {
        char digit;
        const std::string_view& sound;
    };
    static const std::array<digit_sound, 10> digit_sounds{
        {digit_sound{'0', Lang::Sounds::OGG_0}, digit_sound{'1', Lang::Sounds::OGG_1},
         digit_sound{'2', Lang::Sounds::OGG_2}, digit_sound{'3', Lang::Sounds::OGG_3},
         digit_sound{'4', Lang::Sounds::OGG_4}, digit_sound{'5', Lang::Sounds::OGG_5},
         digit_sound{'6', Lang::Sounds::OGG_6}, digit_sound{'7', Lang::Sounds::OGG_7},
         digit_sound{'8', Lang::Sounds::OGG_8}, digit_sound{'9', Lang::Sounds::OGG_9}}};

    // This sentence uses 9KB of SRAM, so we need to wait for it to finish
    Alert(Lang::Strings::ACTIVATION, message.c_str(), "link", Lang::Sounds::OGG_ACTIVATION);

    for (const auto& digit : code) {
        auto it = std::find_if(digit_sounds.begin(), digit_sounds.end(),
                               [digit](const digit_sound& ds) { return ds.digit == digit; });
        if (it != digit_sounds.end()) {
            audio_service_.PlaySound(it->sound);
        }
    }
}

void Application::Alert(const char* status, const char* message, const char* emotion,
                        const std::string_view& sound) {
    ESP_LOGW(TAG, "Alert [%s] %s: %s", emotion, status, message);
    auto display = Board::GetInstance().GetDisplay();
    display->SetStatus(status);
    display->SetEmotion(emotion);
    display->SetChatMessage("system", message);
    if (!sound.empty()) {
        audio_service_.PlaySound(sound);
    }
}

void Application::DismissAlert() {
    last_error_message_.clear();
    if (GetDeviceState() == kDeviceStateIdle) {
        auto display = Board::GetInstance().GetDisplay();
        display->SetStatus(Lang::Strings::STANDBY);
        display->SetEmotion("neutral");
        display->SetChatMessage("system", "");
    }
}

void Application::ToggleChatState() { xEventGroupSetBits(event_group_, MAIN_EVENT_TOGGLE_CHAT); }

void Application::StartListening() { xEventGroupSetBits(event_group_, MAIN_EVENT_START_LISTENING); }

void Application::StopListening() { xEventGroupSetBits(event_group_, MAIN_EVENT_STOP_LISTENING); }

void Application::EnterRadioSilentIdle(bool assistant_started_radio) {
    Schedule([this, assistant_started_radio]() {
        radio_silent_mode_ = true;
        radio_voice_processing_grace_ = assistant_started_radio;
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
            if (assistant_started_radio) {
                esp_timer_start_once(radio_voice_grace_timer_, 3 * 1000 * 1000);
            }
        }

        audio_service_.ResetDecoder();
        const auto state = GetDeviceState();
        if (state == kDeviceStateSpeaking || state == kDeviceStateListening) {
            while (audio_service_.PopPacketFromSendQueue()) {
            }
            SetDeviceState(kDeviceStateIdle);
        }
        // Music playback is silent: disable the heavy voice pipeline and keep only
        // wake-word detection active. The wake word can still open a brief control turn.
        if (!assistant_started_radio) {
            audio_service_.EnableVoiceProcessing(false);
        }
        audio_service_.EnableWakeWordDetection(true);
    });
}

void Application::RadioVoiceGraceTimerCallback(void* arg) {
    auto* app = static_cast<Application*>(arg);
    if (app != nullptr) {
        app->Schedule([app]() { app->FinishRadioVoiceGrace(); });
    }
}

void Application::FinishRadioVoiceGrace() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (!radio_voice_processing_grace_) return;
    if (!TaijiWebRadio::IsAnyRadioActive()) {
        radio_voice_processing_grace_ = false;
        radio_voice_session_seen_ = false;
        return;
    }
    const auto state = GetDeviceState();
    if (state != kDeviceStateIdle) {
        // Never turn off AFE while connecting, listening or speaking.
        if (radio_voice_grace_timer_ != nullptr) esp_timer_start_once(radio_voice_grace_timer_, 3 * 1000 * 1000);
        return;
    }
    if (!radio_voice_session_seen_) {
        // Wake/activation can spend several seconds in Idle before the cloud
        // session starts. Keep voice processing available for a 12-second
        // startup window instead of expiring the old 3-second timer too early.
        const int64_t elapsed = esp_timer_get_time() - radio_voice_activation_started_us_;
        if (elapsed < 12 * 1000 * 1000) {
            if (radio_voice_grace_timer_ != nullptr) esp_timer_start_once(radio_voice_grace_timer_, 1000 * 1000);
            return;
        }
    }
    radio_voice_processing_grace_ = false;
    radio_voice_session_seen_ = false;
    audio_service_.EnableVoiceProcessing(false);
    audio_service_.EnableWakeWordDetection(true);
    TaijiWebRadio::SetAssistantDuck(false);
#endif
}

void Application::ExitRadioSilentIdle() {
    Schedule([this]() {
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
        }
        radio_voice_processing_grace_ = false;
        if (!radio_silent_mode_) {
            return;
        }
        radio_silent_mode_ = false;
        if (GetDeviceState() == kDeviceStateIdle) {
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(true);
        }
    });
}

void Application::ResetIdleDisplayTimer() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    Schedule([this]() {
        idle_since_us_ = esp_timer_get_time();
        idle_display_off_ = false;
        auto& board = Board::GetInstance();
        if (auto display = board.GetDisplay()) display->SetPowerSaveMode(false);
        if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        ESP_LOGI(TAG, "Idle display timer restarted after leaving music player");
    });
#endif
}

void Application::HandleToggleChatEvent() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // A tap/wake word during radio playback starts a short voice-control session;
    // the stream remains active but its PCM output is ducked.
    if (TaijiWebRadio::IsAnyRadioActive()) {
        TaijiWebRadio::SetAssistantDuck(true);
        radio_voice_processing_grace_ = true;
        radio_voice_session_seen_ = false;
        radio_voice_activation_started_us_ = esp_timer_get_time();
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
            // Give the assistant enough time to activate, hear and process the
            // first command. The 3-second quiet timeout starts after the turn.
            esp_timer_start_once(radio_voice_grace_timer_, 12 * 1000 * 1000);
        }
    }
#endif
    radio_silent_mode_ = false;
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        ListeningMode mode = GetDefaultListeningMode();
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this, mode]() { ContinueOpenAudioChannel(mode); });
            return;
        }
        SetListeningMode(mode);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
    } else if (state == kDeviceStateListening) {
        protocol_->CloseAudioChannel();
    }
}

void Application::ContinueOpenAudioChannel(ListeningMode mode) {
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    // Switch to performance mode before connecting to reduce latency
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            // Return to idle so the device is not stuck in the connecting
            // state (not every failure path reports a network error)
            SetDeviceState(kDeviceStateIdle);
            return;
        }
    }

    SetListeningMode(mode);
}

void Application::HandleStartListeningEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this]() { ContinueOpenAudioChannel(kListeningModeManualStop); });
            return;
        }
        SetListeningMode(kListeningModeManualStop);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
        SetListeningMode(kListeningModeManualStop);
    }
}

void Application::HandleStopListeningEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    } else if (state == kDeviceStateListening) {
        if (protocol_) {
            protocol_->SendStopListening();
        }
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleWakeWordDetectedEvent() {
    if (!protocol_) {
        return;
    }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (TaijiWebRadio::IsAnyRadioActive()) {
        // Duck the radio immediately on wake detection, before opening the cloud
        // session, so the single PDM microphone can hear the user's command.
        TaijiWebRadio::SetAssistantDuck(true);
        radio_voice_processing_grace_ = true;
        radio_voice_session_seen_ = false;
        radio_voice_activation_started_us_ = esp_timer_get_time();
        radio_silent_mode_ = false;
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
            esp_timer_start_once(radio_voice_grace_timer_, 12 * 1000 * 1000);
        }
    }
#endif

    auto state = GetDeviceState();
    auto wake_word = audio_service_.GetLastWakeWord();
    ESP_LOGI(TAG, "Wake word detected: %s (state: %d)", wake_word.c_str(), (int)state);

    if (state == kDeviceStateIdle) {
        BeginWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateNotifying) {
        StopNotification();
        BeginWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateSpeaking || state == kDeviceStateListening) {
        AbortSpeaking(kAbortReasonWakeWordDetected);
        // Clear send queue to avoid sending residues to server
        while (audio_service_.PopPacketFromSendQueue())
            ;

        if (state == kDeviceStateListening) {
            protocol_->SendStartListening(GetDefaultListeningMode());
            audio_service_.ResetDecoder();
            audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
            // Re-enable wake word detection as it was stopped by the detection itself
            audio_service_.EnableWakeWordDetection(true);
        } else {
            // Play popup sound and start listening again
            play_popup_on_listening_ = true;
            SetListeningMode(GetDefaultListeningMode());
        }
    } else if (state == kDeviceStateActivating) {
        // Restart the activation check if the wake word is detected during activation
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::BeginWakeWordInvoke(const std::string& wake_word) {
    // Must run in the main task with the device in idle state
    audio_service_.EncodeWakeWord();
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (TaijiWebRadio::IsAnyRadioActive()) {
        // Duck radio immediately, but do not start the high-priority AFE/input
        // pipeline before the MQTT audio channel is open. On the Taiji board this
        // can starve the main/MQTT tasks and leave the state stuck at Connecting.
        // Voice processing is enabled by StartListeningAudio() after the server
        // channel is ready and the state has moved to Listening.
        TaijiWebRadio::SetAssistantDuck(true);
        audio_service_.EnableWakeWordDetection(true);
    }
#endif

    // Always pass through the connecting state, even if the audio channel is
    // already opened. ContinueWakeWordInvoke() rejects any other state, so
    // skipping this transition would silently drop the wake word invocation.
    if (!SetDeviceState(kDeviceStateConnecting)) {
        // Wake word detection was stopped by the detection itself; restore it
        // so the device does not become unresponsive to wake words.
        audio_service_.EnableWakeWordDetection(true);
        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        // Schedule to let the state change be processed first (UI update),
        // then continue with OpenAudioChannel which may block for ~1 second
        Schedule([this, wake_word]() { ContinueWakeWordInvoke(wake_word); });
        return;
    }
    // Channel already opened, continue directly
    ContinueWakeWordInvoke(wake_word);
}

void Application::ContinueWakeWordInvoke(const std::string& wake_word) {
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    // Switch to performance mode before connecting to reduce latency
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

    if (!protocol_->IsAudioChannelOpened()) {
        ESP_LOGI(TAG, "Opening audio channel for wake-word session");
        if (!protocol_->OpenAudioChannel()) {
            ESP_LOGE(TAG, "Could not open audio channel for wake-word session; returning to idle");
            // Return to idle so the device is not stuck in the connecting
            // state (not every failure path reports a network error), and
            // wake word detection is re-enabled by the idle state handler.
            SetDeviceState(kDeviceStateIdle);
            return;
        }
        ESP_LOGI(TAG, "Audio channel opened for wake-word session");
    } else {
        ESP_LOGI(TAG, "Reusing open audio channel for wake-word session");
    }

    ESP_LOGI(TAG, "Wake word detected: %s", wake_word.c_str());
#if CONFIG_SEND_WAKE_WORD_DATA
    // Encode and send the wake word data to the server
    while (auto packet = audio_service_.PopWakeWordPacket()) {
        protocol_->SendAudio(std::move(packet));
    }
    // Set the chat state to wake word detected
    protocol_->SendWakeWordDetected(wake_word);
    SetListeningMode(GetDefaultListeningMode());
#else
    // Set flag to play popup sound after state changes to listening
    // (PlaySound here would be cleared by ResetDecoder in EnableVoiceProcessing)
    play_popup_on_listening_ = true;
    SetListeningMode(GetDefaultListeningMode());
#endif
}

void Application::HandleStateChangedEvent() {
    DeviceState new_state = state_machine_.GetState();
    clock_ticks_ = 0;
    // Any state change invalidates a pending deferred listening start;
    // the Listening case below re-arms it when needed.
    pending_listening_start_ = false;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto led = board.GetLed();
    led->OnStateChanged();

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // Wi-Fi stays awake while the voice assistant is active and returns to
    // modem-sleep once the conversation is over. Radio playback has priority
    // and keeps WIFI_PS_NONE even while the application is idle.
    TaijiWebRadio::UpdateWifiPowerSave();
#endif

    switch (new_state) {
        case kDeviceStateUnknown:
        case kDeviceStateIdle: {
            // Keep a just-raised network error visible. SetDeviceState(idle)
            // queues STATE_CHANGED after Alert(), and the idle handler would
            // otherwise wipe the status, emotion, and chat message.
            if (last_error_message_.empty()) {
                display->SetStatus(Lang::Strings::STANDBY);
                display->ClearChatMessages();  // Clear messages first
                display->SetEmotion(
                    "neutral");  // Then set emotion (wechat mode checks child count)
            }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
            const bool radio_active = TaijiWebRadio::IsAnyRadioActive();
            if (radio_active) {
                radio_silent_mode_ = true;
                if (!radio_voice_processing_grace_) {
                    audio_service_.EnableVoiceProcessing(false);
                }
                audio_service_.EnableWakeWordDetection(true);
            } else
#endif
            {
                audio_service_.EnableVoiceProcessing(false);
                audio_service_.EnableWakeWordDetection(!radio_silent_mode_);
            }
            break;
        }
        case kDeviceStateConnecting:
            display->SetStatus(Lang::Strings::CONNECTING);
            display->SetEmotion("neutral");
            display->SetChatMessage("system", "");
            break;
        case kDeviceStateListening:
            display->SetStatus(Lang::Strings::LISTENING);
            display->SetEmotion("neutral");

            // Make sure the audio processor is running
            if (play_popup_on_listening_ || !audio_service_.IsAudioProcessorRunning()) {
                // For auto mode, wait for the playback queue to drain before enabling
                // voice processing. This prevents audio truncation when STOP arrives
                // late due to network jitter. Instead of blocking the main loop here,
                // defer the start until MAIN_EVENT_PLAYBACK_DRAINED arrives.
                if (listening_mode_ == kListeningModeAutoStop && !audio_service_.IsPlaybackIdle()) {
                    pending_listening_start_ = true;
                } else {
                    StartListeningAudio();
                }
            } else {
                ConfigureWakeWordForListening();
            }
            break;
        case kDeviceStateSpeaking:
            display->SetStatus(Lang::Strings::SPEAKING);

            if (listening_mode_ != kListeningModeRealtime) {
                audio_service_.EnableVoiceProcessing(false);
                // Only AFE wake word can be detected in speaking mode
                audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
            }
            audio_service_.ResetDecoder();
            break;
        case kDeviceStateNotifying:
            display->SetStatus(Lang::Strings::SPEAKING);
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
            break;
        case kDeviceStateWifiConfiguring:
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(false);
            break;
        default:
            // Do nothing
            break;
    }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (TaijiWebRadio::IsAnyRadioActive()) {
        if (new_state == kDeviceStateConnecting || new_state == kDeviceStateListening ||
            new_state == kDeviceStateSpeaking) {
            TaijiWebRadio::SetAssistantDuck(true);
            radio_voice_processing_grace_ = true;
            radio_voice_session_seen_ = true;
            if (radio_voice_grace_timer_ != nullptr) esp_timer_stop(radio_voice_grace_timer_);
        } else if (new_state == kDeviceStateIdle && radio_voice_processing_grace_) {
            if (radio_voice_grace_timer_ != nullptr) {
                esp_timer_stop(radio_voice_grace_timer_);
                esp_timer_start_once(radio_voice_grace_timer_, 3 * 1000 * 1000);
            }
        }
    }
#endif
}

void Application::StartListeningAudio() {
    // Runs in the main loop, either directly from HandleStateChangedEvent or
    // deferred via MAIN_EVENT_PLAYBACK_DRAINED once the playback queue drains.
    if (GetDeviceState() != kDeviceStateListening) {
        ESP_LOGW(TAG, "StartListeningAudio skipped: state is %d", (int)GetDeviceState());
        return;
    }

    ESP_LOGI(TAG, "Starting microphone capture, listening mode=%s",
             listening_mode_ == kListeningModeRealtime ? "realtime" :
             (listening_mode_ == kListeningModeAutoStop ? "auto_stop" : "manual_stop"));
    // Send the start listening command
    protocol_->SendStartListening(listening_mode_);
    audio_service_.EnableVoiceProcessing(true);

    ConfigureWakeWordForListening();

    // Play popup sound after ResetDecoder (in EnableVoiceProcessing) has been called
    if (play_popup_on_listening_) {
        play_popup_on_listening_ = false;
        audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
    }
}

void Application::ConfigureWakeWordForListening() {
#ifdef CONFIG_WAKE_WORD_DETECTION_IN_LISTENING
    // Enable wake word detection in listening mode (configured via Kconfig)
    audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
#else
    // Disable wake word detection in listening mode
    audio_service_.EnableWakeWordDetection(false);
#endif
}

void Application::StartNotification(std::string audio_url, std::vector<NotifySubtitle> subtitles) {
    if (GetDeviceState() != kDeviceStateIdle || notify_player_.IsBusy()) {
        ESP_LOGW(TAG, "Ignoring notify message while device is busy");
        return;
    }

    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.EnableVoiceProcessing(false);
    audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
    audio_service_.ReleaseWakeWordResources();
    while (audio_service_.PopPacketFromSendQueue()) {
        // Discard microphone audio left over from a previous conversation.
    }

    if (!SetDeviceState(kDeviceStateNotifying)) {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        return;
    }

    audio_service_.ResetDecoder();
    uint32_t playback_id = ++notification_playback_id_;
    if (playback_id == 0) {
        playback_id = ++notification_playback_id_;
    }
    audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);

    bool started = notify_player_.Start(
        std::move(audio_url), std::move(subtitles), playback_id,
        [this](uint32_t id, const std::string& text) {
            Schedule([this, id, text]() {
                if (GetDeviceState() == kDeviceStateNotifying && notification_playback_id_ == id) {
                    Board::GetInstance().GetDisplay()->SetChatMessage("assistant", text.c_str());
                }
            });
        },
        [this](uint32_t id, bool success) {
            Schedule([this, id, success]() { HandleNotificationFinished(id, success); });
        });

    if (!started) {
        ESP_LOGE(TAG, "Failed to start notification playback");
        StopNotification();
    }
}

void Application::StopNotification() {
    notify_player_.Stop();
    audio_service_.ResetDecoder();
    auto& board = Board::GetInstance();
    board.GetDisplay()->SetChatMessage("assistant", "");
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
    if (GetDeviceState() == kDeviceStateNotifying) {
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleNotificationFinished(uint32_t playback_id, bool success) {
    if (GetDeviceState() != kDeviceStateNotifying || notification_playback_id_ != playback_id) {
        return;
    }
    ESP_LOGI(TAG, "Notification playback %lu %s", static_cast<unsigned long>(playback_id),
             success ? "completed" : "failed");
    StopNotification();
}

void Application::Schedule(std::function<void()>&& callback) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        main_tasks_.push_back(std::move(callback));
    }
    xEventGroupSetBits(event_group_, MAIN_EVENT_SCHEDULE);
}

void Application::AbortSpeaking(AbortReason reason) {
    ESP_LOGI(TAG, "Abort speaking");
    aborted_ = true;
    if (protocol_) {
        protocol_->SendAbortSpeaking(reason);
    }
}

void Application::SetListeningMode(ListeningMode mode) {
    listening_mode_ = mode;
    SetDeviceState(kDeviceStateListening);
}

ListeningMode Application::GetDefaultListeningMode() const {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // During radio voice control, keep the conversation in realtime mode.
    // AutoStop is unsuitable here: after the assistant's greeting it can return
    // straight to Idle, leaving the user with no listening window for the command.
    if (TaijiWebRadio::IsAnyRadioActive() && radio_voice_processing_grace_) {
        ESP_LOGI(TAG, "Radio voice session: selecting REALTIME listening mode");
        return kListeningModeRealtime;
    }
#endif
    return aec_mode_ == kAecOff ? kListeningModeAutoStop : kListeningModeRealtime;
}

void Application::Reboot() {
    ESP_LOGI(TAG, "Rebooting...");
    if (GetDeviceState() == kDeviceStateNotifying) {
        StopNotification();
    }
    // Disconnect the audio channel
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        protocol_->CloseAudioChannel();
    }
    protocol_.reset();
    audio_service_.Stop();

    vTaskDelay(pdMS_TO_TICKS(1000));
    esp_restart();
}

bool Application::UpgradeFirmware(const std::string& url, const std::string& version) {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();

    std::string upgrade_url = url;
    std::string version_info = version.empty() ? "(Manual upgrade)" : version;

    if (GetDeviceState() == kDeviceStateNotifying) {
        StopNotification();
    }

    // Close audio channel if it's open
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        ESP_LOGI(TAG, "Closing audio channel before firmware upgrade");
        protocol_->CloseAudioChannel();
    }
    ESP_LOGI(TAG, "Starting firmware upgrade from URL: %s", upgrade_url.c_str());

    Alert(Lang::Strings::OTA_UPGRADE, Lang::Strings::UPGRADING, "download",
          Lang::Sounds::OGG_UPGRADE);
    vTaskDelay(pdMS_TO_TICKS(3000));

    SetDeviceState(kDeviceStateUpgrading);

    std::string message = std::string(Lang::Strings::NEW_VERSION) + version_info;
    display->SetChatMessage("system", message.c_str());

    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.Stop();
    vTaskDelay(pdMS_TO_TICKS(1000));

    bool upgrade_success = Ota::Upgrade(upgrade_url, [this, display](int progress, size_t speed) {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
        Schedule([display, message = std::string(buffer)]() {
            display->SetChatMessage("system", message.c_str());
        });
    });

    if (!upgrade_success) {
        // Upgrade failed, restart audio service and continue running
        ESP_LOGE(TAG,
                 "Firmware upgrade failed, restarting audio service and continuing operation...");
        audio_service_.Start();                              // Restart audio service
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);  // Restore power save level
        Alert(Lang::Strings::ERROR, Lang::Strings::UPGRADE_FAILED, "cancel",
              Lang::Sounds::OGG_EXCLAMATION);
        vTaskDelay(pdMS_TO_TICKS(3000));
        return false;
    } else {
        // Upgrade success, reboot immediately
        ESP_LOGI(TAG, "Firmware upgrade successful, rebooting...");
        display->SetChatMessage("system", "Upgrade successful, rebooting...");
        vTaskDelay(pdMS_TO_TICKS(1000));  // Brief pause to show message
        Reboot();
        return true;
    }
}

void Application::WakeWordInvoke(const std::string& wake_word) {
    if (!protocol_) {
        return;
    }

    auto state = GetDeviceState();

    if (state == kDeviceStateIdle) {
        // May be called from outside the main task (e.g. board button
        // callbacks), so schedule the invocation instead of running it here
        Schedule([this, wake_word]() {
            if (GetDeviceState() == kDeviceStateIdle) {
                BeginWakeWordInvoke(wake_word);
            }
        });
    } else if (state == kDeviceStateNotifying) {
        Schedule([this, wake_word]() {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
                BeginWakeWordInvoke(wake_word);
            }
        });
    } else if (state == kDeviceStateSpeaking) {
        Schedule([this]() { AbortSpeaking(kAbortReasonNone); });
    } else if (state == kDeviceStateListening) {
        Schedule([this]() {
            if (protocol_) {
                protocol_->CloseAudioChannel();
            }
        });
    }
}

// <ttuner83> Schedule a single in-RAM reminder without changing the normal sleep policy.
bool Application::SetVoiceReminder(int minutes, const std::string& message) {
    if (minutes < 1 || minutes > 1440 || message.empty() || voice_reminder_timer_ == nullptr) return false;
    {
        std::lock_guard<std::mutex> lock(reminder_mutex_);
        voice_reminder_text_ = message;
    }
    esp_timer_stop(voice_reminder_timer_);
    const esp_err_t err = esp_timer_start_once(voice_reminder_timer_, static_cast<uint64_t>(minutes) * 60ULL * 1000000ULL);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Cannot start voice reminder: %s", esp_err_to_name(err));
        return false;
    }
    ESP_LOGI(TAG, "One-shot voice reminder set for %d minutes", minutes);
    return true;
}

void Application::VoiceReminderTimerCallback(void* arg) {
    auto* app = static_cast<Application*>(arg);
    if (app) app->Schedule([app]() { app->FireVoiceReminder(); });
}

void Application::FireVoiceReminder() {
    std::string reminder;
    {
        std::lock_guard<std::mutex> lock(reminder_mutex_);
        reminder.swap(voice_reminder_text_); // one-shot: consume before delivery
    }
    if (reminder.empty()) return;

    auto& board = Board::GetInstance();
    // The reminder callback may run while the display is off and Wi-Fi is in
    // maximum modem sleep. Restore full performance and restart the idle
    // countdown before asking the assistant to speak. Keep an awake grace
    // period in case the server needs several seconds to start its TTS stream.
    const int64_t now_us = esp_timer_get_time();
    reminder_awake_until_us_ = now_us + 30LL * 1000000LL;
    idle_since_us_ = now_us;
    if (idle_display_off_) {
        idle_display_off_ = false;
        auto display = board.GetDisplay();
        if (display) display->SetPowerSaveMode(false);
        if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
    }
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    const esp_err_t wifi_err = esp_wifi_set_ps(WIFI_PS_NONE);
    if (wifi_err != ESP_OK) {
        ESP_LOGW(TAG, "Reminder: could not restore Wi-Fi performance mode: %s", esp_err_to_name(wifi_err));
    }
    ESP_LOGI(TAG, "Reminder fired: display and Wi-Fi restored; sleep held for 30 seconds");

    // Play a local 2.55-second trumpet-like fanfare. No server request or TTS.
    const std::string_view reminder_sound(
        reinterpret_cast<const char*>(reminder_ogg_start),
        static_cast<size_t>(reminder_ogg_end - reminder_ogg_start));
    audio_service_.PlaySound(reminder_sound);
    Alert("Напоминание", reminder.c_str(), "neutral");
    ESP_LOGI(TAG, "Reminder fired; played local 2.55-second fanfare");
}

bool Application::CanEnterSleepMode() {
    // A reminder is a foreground event even though the device state is IDLE
    // until the server starts speaking. Do not let the idle power-save path
    // switch the display/Wi-Fi off during that hand-off.
    if (reminder_awake_until_us_ > 0) {
        if (esp_timer_get_time() < reminder_awake_until_us_) {
            return false;
        }
        reminder_awake_until_us_ = 0;
        idle_since_us_ = esp_timer_get_time();
        ESP_LOGI(TAG, "Reminder awake grace period ended; normal idle sleep resumed");
    }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // Music/radio playback must not be interrupted by the generic sleep timer.
    // IsAnyRadioActive also covers the visible music-player session between tracks.
    if (TaijiWebRadio::IsAnyRadioActive()) {
        return false;
    }
#endif
    if (GetDeviceState() != kDeviceStateIdle) {
        return false;
    }

    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        return false;
    }

    if (!audio_service_.IsIdle()) {
        return false;
    }

    // Now it is safe to enter sleep mode
    return true;
}

void Application::RegisterMcpBroadcastCallback(std::function<void(const std::string&)> callback) {
    mcp_broadcast_callback_ = std::move(callback);
}

void Application::SendMcpMessage(const std::string& payload) {
    // Always schedule to run in main task for thread safety
    Schedule([this, payload]() {
        if (protocol_) {
            protocol_->SendMcpMessage(payload);
        }
        if (mcp_broadcast_callback_) {
            mcp_broadcast_callback_(payload);
        }
    });
}

void Application::SetAecMode(AecMode mode) {
    aec_mode_ = mode;
    Schedule([this]() {
        auto& board = Board::GetInstance();
        auto display = board.GetDisplay();
        switch (aec_mode_) {
            case kAecOff:
                audio_service_.EnableDeviceAec(false);
                display->ShowNotification(Lang::Strings::RTC_MODE_OFF);
                break;
            case kAecOnServerSide:
                audio_service_.EnableDeviceAec(false);
                display->ShowNotification(Lang::Strings::RTC_MODE_ON);
                break;
            case kAecOnDeviceSide:
                audio_service_.EnableDeviceAec(true);
                display->ShowNotification(Lang::Strings::RTC_MODE_ON);
                break;
        }

        // If the AEC mode is changed, close the audio channel
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
    });
}

void Application::PlaySound(const std::string_view& sound) { audio_service_.PlaySound(sound); }

void Application::ResetProtocol() {
    Schedule([this]() {
        if (GetDeviceState() == kDeviceStateNotifying) {
            StopNotification();
        }
        // Close audio channel if opened
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
        // Reset protocol
        protocol_.reset();
    });
}
