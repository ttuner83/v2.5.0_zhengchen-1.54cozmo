#include "drone_map.h"
#include "mcp_server.h"
#include "settings.h"
#include <cJSON.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <strings.h>
#include <cstdint>
#include <cstdio>
#include <ctime>
#include <set>
#include <string>
#include <utility>
#include <vector>

#define TAG "ArgusVoice"

namespace {
constexpr const char* kArgusUrl = "https://argusmap.online/api/live";
constexpr size_t kMaxResponseBytes = 512 * 1024;
struct MapPoint { const char* name; int x; int y; };
// Pixel anchors for map333.png (360x360). Points not labelled on the image are approximate.
constexpr MapPoint kMapPoints[] = {
    {"Армянск",72,111}, {"Красноперекопск",91,137}, {"Джанкой",151,148},
    {"Раздольное",48,155}, {"Раздольном",48,155}, {"Стерегущее",31,151}, {"Стерегущем",31,151},
    {"Гвардейское",116,207}, {"Гвардейском",116,207}, {"Гвардейского",116,207}, {"Гвардейскому",116,207},
    {"Черноморское",22,176}, {"Евпатория",73,201},
    {"Саки",91,207}, {"Саках",91,207}, {"Саков",91,207}, {"Молочное",66,194}, {"Молочном",66,194}, {"Молочного",66,194}, {"Molochne",66,194}, {"Molochnoe",66,194}, {"Simferopol",127,228}, {"Симферополь",127,228}, {"Бахчисарай",95,244},
    {"Севастополь",73,262}, {"Ялта",128,278}, {"Алушта",151,265},
    {"Белогорск",178,222}, {"Старый Крым",207,220}, {"Судак",187,246},
    {"Коктебель",215,226}, {"Феодосия",235,210}, {"Чауда",222,246},
    {"Кировское",204,201}, {"Яркое Поле",213,198}, {"Ярком Поле",213,198}, {"Яркого Поля",213,198}, {"Владиславовка",224,204}, {"Владиславовке",224,204}, {"Владиславовки",224,204}, {"Щёлкино",263,157}, {"Ленино",261,190},
    {"Керчь",294,184}, {"Керченский пролив",319,201}, {"переправ",311,213},
    // Taman peninsula locations are approximate because they sit outside the Crimea artwork.
    {"Темрюк",319,284}, {"Темрюке",319,284}, {"Темрюка",319,284},
    {"Темрюкский район",316,294}, {"Темрюкского района",316,294}, {"Темрюкском районе",316,294},
    {"Temryuk",319,284}, {"Temryuk district",316,294},
    {"Анапа",326,309}, {"Анапе",326,309}, {"Анапу",326,309},
    {"Арабатская стрелка",179,127}, {"Арабатской стрелки",179,127}, {"Сиваш",120,105},
    {"Азовское море",211,80}, {"Азовское море",278,72}, {"Азовское море",337,85},
    // Northern Sea of Azov and adjacent coast, included in spoken reports too.
    {"Геническ",177,69}, {"Геническе",177,69}, {"Геническа",177,69},
    {"Кирилловка",218,55}, {"Кирилловке",218,55}, {"Кирилловки",218,55},
    {"Мелитополь",204,48}, {"Мелитополе",204,48}, {"Мелитополя",204,48},
    {"Бердянск",246,40}, {"Бердянске",246,40}, {"Бердянска",246,40},
    {"Приморск",235,48}, {"Приморске",235,48}, {"Приморска",235,48},
    {"Мариуполь",284,29}, {"Мариуполе",284,29}, {"Мариуполя",284,29},
    {"Новоазовск",316,31}, {"Новоазовске",316,31}, {"Новоазовска",316,31},
    {"Ейск",329,52}, {"Ейске",329,52}, {"Ейска",329,52},
    {"Приморско-Ахтарск",337,66}, {"Приморско-Ахтарске",337,66},
    {"Таганрог",342,34}, {"Таганроге",342,34}, {"Ростов-на-Дону",337,13}, {"Ростове-на-Дону",337,13},
    {"Henichesk",177,69}, {"Kyrylivka",218,55}, {"Melitopol",204,48},
    {"Berdiansk",246,40}, {"Mariupol",284,29}, {"Novoazovsk",316,31}, {"Yeysk",329,52},
    {"Тарханкут",20,190}, {"Ленинский район",254,214}, {"Феодосийский залив",247,196},
    {"порт",239,207}, {"Портовое",39,164}, {"Портовом",39,164},
    {"Armyansk",72,111}, {"Krasnoperekopsk",91,137}, {"Dzhankoy",151,148},
    {"Steregushchee",31,151}, {"Portovoe",39,164}, {"Gvardeyskoye",116,207},
    {"Razdolnoe",48,155}, {"Chornomorske",22,176}, {"Yevpatoriya",73,201},
    {"Saki",91,207}, {"Simferopol",127,228}, {"Bakhchisarai",95,244},
    {"Sevastopol",73,262}, {"Yalta",128,278}, {"Alushta",151,265},
    {"Belogorsk",178,222}, {"Stary Krym",207,220}, {"Sudak",187,246},
    {"Koktebel",215,226}, {"Feodosia",235,210}, {"Chauda",222,246},
    {"Kirovsky",204,201}, {"Kirovske",204,201}, {"Shcholkine",263,157},
    {"Lenino",261,190}, {"Kerch",294,184}, {"Kerch Strait",319,201},
    {"ferry",311,213}, {"Arabat Spit",179,127}, {"Sivash",120,105},
    {"Azov Sea",278,72}, {"Tarkhankut",20,190}, {"Leninsky",254,214},
    {"Feodosia port",239,207}, {"port of Feodosia",239,207}
};

std::string LowerUtf8(std::string value) {
    std::string out;
    out.reserve(value.size());
    for (size_t i = 0; i < value.size();) {
        const unsigned char c = static_cast<unsigned char>(value[i]);
        if (c < 0x80) {
            out.push_back(static_cast<char>(std::tolower(c)));
            ++i;
        } else if (i + 1 < value.size() && c == 0xD0) {
            const unsigned char d = static_cast<unsigned char>(value[i + 1]);
            if (d >= 0x90 && d <= 0x9F) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d + 0x20)); }
            else if (d >= 0xA0 && d <= 0xAF) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(d - 0x20)); }
            else if (d == 0x81) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(0x91)); }
            else { out.push_back(value[i]); out.push_back(value[i + 1]); }
            i += 2;
        } else {
            out.push_back(value[i++]);
        }
    }
    return out;
}

bool ContainsNoCase(const std::string& text, const char* phrase) {
    if (!phrase || !*phrase) return false;
    return LowerUtf8(text).find(LowerUtf8(phrase)) != std::string::npos;
}

// Reduce Russian words to a conservative stem so that city names match common
// grammatical cases (e.g. Feodosia/Feodosii, Kerch/Kerchi, Arabatskoy strelki).
// This is intentionally token-based: it does not match arbitrary substrings.
std::string RussianStem(std::string word) {
    static const char* suffixes[] = {
        "иями", "ями", "ами", "иями", "иями", "ского", "цкого", "ному", "нему",
        "ыми", "ими", "ого", "его", "ому", "ему", "ией", "ией", "иях", "иях",
        "иям", "ием", "ией", "ская", "цкая", "ской", "цкой", "ские", "цкие",
        "иями", "ями", "ами", "ией", "ия", "ии", "ие", "ей", "ой", "ый", "ий",
        "ая", "яя", "ое", "ее", "ом", "ем", "ам", "ям", "ах", "ях", "ы", "и",
        "а", "я", "ь", "й", "е", "у", "ю"
    };
    for (const char* suffix : suffixes) {
        const size_t n = strlen(suffix);
        if (word.size() > n + 2 && word.compare(word.size() - n, n, suffix) == 0) {
            word.resize(word.size() - n);
            break;
        }
    }
    return word;
}

struct WordToken { std::string word; size_t pos; };
std::vector<WordToken> TokenizeWords(const std::string& text) {
    std::vector<WordToken> out;
    size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        const bool word_char = (c >= 128) || std::isalnum(c);
        if (!word_char) { ++i; continue; }
        const size_t start = i;
        while (i < text.size()) {
            const unsigned char d = static_cast<unsigned char>(text[i]);
            if (!(d >= 128 || std::isalnum(d))) break;
            ++i;
        }
        out.push_back({text.substr(start, i - start), start});
    }
    return out;
}

size_t FindLocationPosition(const std::string& lowered_text, const char* raw_name) {
    if (!raw_name || !*raw_name) return std::string::npos;
    const std::string lowered_name = LowerUtf8(raw_name);
    // Latin transliterations are matched as complete phrases, case-insensitively.
    bool has_cyrillic = false;
    for (unsigned char c : lowered_name) if (c >= 0xD0) { has_cyrillic = true; break; }
    if (!has_cyrillic) return lowered_text.find(lowered_name);

    const auto text_words = TokenizeWords(lowered_text);
    const auto name_words = TokenizeWords(lowered_name);
    if (name_words.empty()) return std::string::npos;
    std::vector<std::string> roots;
    roots.reserve(name_words.size());
    for (const auto& word : name_words) roots.push_back(RussianStem(word.word));

    size_t best = std::string::npos;
    for (size_t i = 0; i < text_words.size(); ++i) {
        if (RussianStem(text_words[i].word) != roots[0]) continue;
        size_t cursor = i + 1;
        bool matched = true;
        for (size_t n = 1; n < roots.size(); ++n) {
            // Multi-word place names may have a short connective word between parts.
            size_t found = cursor;
            while (found < text_words.size() && found - cursor <= 2 && RussianStem(text_words[found].word) != roots[n]) ++found;
            if (found >= text_words.size() || found - cursor > 2) { matched = false; break; }
            cursor = found + 1;
        }
        if (matched && (best == std::string::npos || text_words[i].pos < best)) best = text_words[i].pos;
    }
    return best;
}

void AppendJsonStrings(const cJSON* item, std::string& out) {
    if (!item) return;
    if (cJSON_IsString(item) && item->valuestring) {
        if (!out.empty()) out.push_back(' ');
        out += item->valuestring;
        return;
    }
    if (cJSON_IsArray(item) || cJSON_IsObject(item)) {
        for (const cJSON* child = item->child; child; child = child->next) AppendJsonStrings(child, out);
    }
}

const char* JsonString(const cJSON* obj, const char* key) {
    const cJSON* v = cJSON_GetObjectItemCaseSensitive(obj, key);
    return cJSON_IsString(v) ? v->valuestring : nullptr;
}

bool HasDirectJsonKey(const char* json, size_t len, const char* key) {
    const size_t key_len = strlen(key);
    int depth = 0;
    bool in_string = false, escaped = false;
    for (size_t i = 0; i < len; ++i) {
        const char c = json[i];
        if (in_string) {
            if (escaped) { escaped = false; continue; }
            if (c == '\\') { escaped = true; continue; }
            if (c == '"') {
                in_string = false;
                if (depth == 1 && i >= key_len + 1 && json[i - key_len - 1] == '"' &&
                    memcmp(json + i - key_len, key, key_len) == 0) {
                    size_t j = i + 1;
                    while (j < len && (json[j] == ' ' || json[j] == '\t' || json[j] == '\r' || json[j] == '\n')) ++j;
                    if (j < len && json[j] == ':') return true;
                }
            }
            continue;
        }
        if (c == '"') in_string = true;
        else if (c == '{' || c == '[') ++depth;
        else if ((c == '}' || c == ']') && depth > 0) --depth;
    }
    return false;
}

bool IsUavThreatEvent(const cJSON* item) {
    const char* category = JsonString(item, "threatCategory");
    const char* type = JsonString(item, "threatType");
    const char* state = JsonString(item, "regionalStateKind");
    const char* status = JsonString(item, "status");
    auto eq = [](const char* a, const char* b) { return a && strcasecmp(a, b) == 0; };
    const bool uav = eq(category, "uav") || eq(category, "drone") || eq(category, "bpla") ||
                     eq(type, "uav") || eq(type, "drone") || eq(type, "bpla") || eq(type, "БПЛА");
    if (!uav) return false; // A place mention or air-alert alone is not a drone event.
    if (eq(status, "resolved") || eq(status, "ended") || eq(status, "inactive") ||
        eq(status, "cancelled") || eq(status, "canceled") || eq(status, "expired")) return false;
    if (status && !(eq(status, "air_alert") || eq(status, "threat") || eq(status, "active") ||
                    eq(status, "confirmed") || eq(status, "warning"))) return false;
    // Explicitly inactive regional states are rejected; confirmed presence and warnings remain.
    if (eq(state, "resolved") || eq(state, "inactive") || eq(state, "ended") || eq(state, "expired")) return false;
    return true;
}

void AppendRelevantEventText(const cJSON* item, std::string& out) {
    static const char* fields[] = {"label", "name", "title", "geoName", "targetLabel", "originLabel", "description", "message", "evidence"};
    for (const char* key : fields) {
        const cJSON* v = cJSON_GetObjectItemCaseSensitive(item, key);
        if (!v) continue;
        if (cJSON_IsString(v) && v->valuestring) {
            if (!out.empty()) out.push_back(' ');
            out += v->valuestring;
        } else if (cJSON_IsObject(v) || cJSON_IsArray(v)) {
            AppendJsonStrings(v, out);
        }
    }
}

struct ResponseBuffer { char* data = nullptr; size_t size = 0; size_t capacity = 0; bool overflow = false; std::string cookies; };
esp_err_t HttpEventHandler(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_HEADER && evt->user_data && evt->header_key && evt->header_value &&
        strcasecmp(evt->header_key, "Set-Cookie") == 0) {
        auto* r = static_cast<ResponseBuffer*>(evt->user_data);
        const std::string header(evt->header_value);
        const size_t semicolon = header.find(';');
        const std::string pair = header.substr(0, semicolon);
        const size_t eq = pair.find('=');
        if (eq != std::string::npos) {
            const std::string name = pair.substr(0, eq);
            // Replace an earlier value of the same cookie instead of sending duplicates.
            std::string updated;
            size_t pos = 0;
            while (pos < r->cookies.size()) {
                size_t end = r->cookies.find(';', pos);
                if (end == std::string::npos) end = r->cookies.size();
                std::string existing = r->cookies.substr(pos, end - pos);
                while (!existing.empty() && existing.front() == ' ') existing.erase(existing.begin());
                const size_t existing_eq = existing.find('=');
                if (existing_eq == std::string::npos || existing.substr(0, existing_eq) != name) {
                    if (!existing.empty()) { if (!updated.empty()) updated += "; "; updated += existing; }
                }
                pos = end + 1;
            }
            if (!updated.empty()) updated += "; ";
            updated += pair;
            r->cookies.swap(updated);
        }
    }
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* r = static_cast<ResponseBuffer*>(evt->user_data);
        const size_t n = static_cast<size_t>(evt->data_len);
        if (r->data && r->size + n < r->capacity) { memcpy(r->data + r->size, evt->data, n); r->size += n; r->data[r->size] = '\0'; }
        else r->overflow = true;
    }
    return ESP_OK;
}

// Voice queries cover the full map region: Crimea, Anapa, Temryuk, the Sea of Azov
// and its northern shore. Every map alias is allowed; duplicate aliases are collapsed
// by coordinates when possible and by canonical name in the spoken result.
bool IsCrimeaPoint(const MapPoint& p) {
    (void)p;
    return true;
}

std::string CanonicalName(const MapPoint& p) {
    // Prefer Russian names in the spoken response; map aliases share coordinates.
    for (const auto& c : kMapPoints) {
        if (c.x != p.x || c.y != p.y) continue;
        bool ascii = true;
        for (const unsigned char* q = reinterpret_cast<const unsigned char*>(c.name); *q; ++q) if (*q >= 0x80) { ascii = false; break; }
        if (!ascii && IsCrimeaPoint(c)) return c.name;
    }
    return p.name;
}

std::string QueryArgusLocations() {
    ResponseBuffer r; r.capacity = kMaxResponseBytes;
    r.data = static_cast<char*>(heap_caps_malloc(r.capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!r.data) return "Не удалось проверить данные Argus: недостаточно памяти.";
    r.data[0] = '\0';
    Settings settings("radio", false);
    std::string argus_url = settings.GetString("drone_url", "");
    if (argus_url.empty()) argus_url = kArgusUrl;
    // ArgusMap now requires a browser-like visit to its public map before /api/live.
    // Bootstrap the visitor session and retain every Set-Cookie pair for the API call.
    esp_http_client_config_t bootstrap_cfg = {};
    bootstrap_cfg.url = "https://argusmap.online/";
    bootstrap_cfg.timeout_ms = 7000;
    bootstrap_cfg.crt_bundle_attach = esp_crt_bundle_attach;
    bootstrap_cfg.event_handler = HttpEventHandler;
    bootstrap_cfg.user_data = &r;
    bootstrap_cfg.buffer_size = 2048;
    bootstrap_cfg.buffer_size_tx = 1024;
    auto bootstrap = esp_http_client_init(&bootstrap_cfg);
    if (!bootstrap) { heap_caps_free(r.data); return "Не удалось открыть карту Argus для инициализации."; }
    esp_http_client_set_method(bootstrap, HTTP_METHOD_GET);
    esp_http_client_set_header(bootstrap, "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8");
    esp_http_client_set_header(bootstrap, "Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7");
    esp_http_client_set_header(bootstrap, "Accept-Encoding", "identity");
    esp_http_client_set_header(bootstrap, "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36");
    const esp_err_t bootstrap_err = esp_http_client_perform(bootstrap);
    const int bootstrap_status = esp_http_client_get_status_code(bootstrap);
    esp_http_client_cleanup(bootstrap);
    ESP_LOGI(TAG, "Argus session bootstrap: err=%s status=%d cookies=%u",
             esp_err_to_name(bootstrap_err), bootstrap_status, (unsigned)r.cookies.size());
    if (bootstrap_err != ESP_OK || bootstrap_status < 200 || bootstrap_status >= 400) {
        ESP_LOGW(TAG, "Argus public map bootstrap failed");
        heap_caps_free(r.data);
        return "Не удалось инициализировать соединение с картой Argus.";
    }

    // The public app initializes its API access through /api/config. This request
    // also carries any cookies issued by the landing page and may refresh them.
    r.size = 0; r.overflow = false; r.data[0] = '\0';
    esp_http_client_config_t config_cfg = {};
    config_cfg.url = "https://argusmap.online/api/config";
    config_cfg.timeout_ms = 7000;
    config_cfg.crt_bundle_attach = esp_crt_bundle_attach;
    config_cfg.event_handler = HttpEventHandler;
    config_cfg.user_data = &r;
    config_cfg.buffer_size = 2048;
    config_cfg.buffer_size_tx = 1024;
    auto config_client = esp_http_client_init(&config_cfg);
    if (!config_client) { heap_caps_free(r.data); return "Не удалось получить конфигурацию карты Argus."; }
    esp_http_client_set_method(config_client, HTTP_METHOD_GET);
    esp_http_client_set_header(config_client, "Accept", "application/json, text/plain, */*");
    esp_http_client_set_header(config_client, "Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7");
    esp_http_client_set_header(config_client, "Accept-Encoding", "identity");
    esp_http_client_set_header(config_client, "Cache-Control", "no-cache");
    esp_http_client_set_header(config_client, "Pragma", "no-cache");
    esp_http_client_set_header(config_client, "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36");
    esp_http_client_set_header(config_client, "Referer", "https://argusmap.online/");
    esp_http_client_set_header(config_client, "Origin", "https://argusmap.online");
    if (!r.cookies.empty()) esp_http_client_set_header(config_client, "Cookie", r.cookies.c_str());
    const esp_err_t config_err = esp_http_client_perform(config_client);
    const int config_status = esp_http_client_get_status_code(config_client);
    esp_http_client_cleanup(config_client);
    ESP_LOGI(TAG, "Argus config bootstrap: err=%s status=%d cookies=%u bytes=%u",
             esp_err_to_name(config_err), config_status, (unsigned)r.cookies.size(), (unsigned)r.size);
    if (config_err != ESP_OK || config_status != 200 || r.overflow || r.size == 0 || !strstr(r.data, "\"ok\":true")) {
        ESP_LOGW(TAG, "Argus public config bootstrap failed");
        heap_caps_free(r.data);
        return "Не удалось инициализировать доступ к API карты Argus.";
    }

    // Reuse the response buffer for the live JSON snapshot.
    r.size = 0; r.overflow = false; r.data[0] = '\0';
    esp_http_client_config_t cfg = {};
    cfg.url = argus_url.c_str(); cfg.timeout_ms = 7000; cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.event_handler = HttpEventHandler; cfg.user_data = &r; cfg.buffer_size = 4096; cfg.buffer_size_tx = 1024;
    auto client = esp_http_client_init(&cfg);
    if (!client) { heap_caps_free(r.data); return "Не удалось подключиться к данным Argus."; }
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_http_client_set_header(client, "Accept", "application/json, text/plain, */*");
    esp_http_client_set_header(client, "Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7");
    esp_http_client_set_header(client, "Accept-Encoding", "identity");
    esp_http_client_set_header(client, "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36");
    esp_http_client_set_header(client, "Referer", "https://argusmap.online/");
    esp_http_client_set_header(client, "Origin", "https://argusmap.online");
    if (!r.cookies.empty()) esp_http_client_set_header(client, "Cookie", r.cookies.c_str());
    const esp_err_t err = esp_http_client_perform(client);
    const int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);
    if (err != ESP_OK || status != 200 || r.size == 0 || r.overflow) {
        ESP_LOGW(TAG, "Argus request failed: %s status=%d bytes=%u overflow=%d", esp_err_to_name(err), status, (unsigned)r.size, r.overflow);
        heap_caps_free(r.data); return "Сейчас не удалось получить данные Argus. Попробуй повторить запрос позже.";
    }

    std::set<std::string> locations;
    int accepted = 0;
    std::vector<const char*> starts; bool in_string = false, escaped = false;
    for (const char* q = r.data; *q; ++q) {
        if (in_string) { if (escaped) escaped = false; else if (*q == '\\') escaped = true; else if (*q == '"') in_string = false; continue; }
        if (*q == '"') in_string = true;
        else if (*q == '{') starts.push_back(q);
        else if (*q == '}' && !starts.empty()) {
            const char* start = starts.back(); starts.pop_back();
            size_t len = (size_t)(q - start + 1); if (len < 40 || len > 65536) continue;
            // Fast pre-filter before allocating/parsing nested objects. Only explicit UAV
            // threat records are parsed; airport/news/route objects are ignored.
            const size_t raw_len = len;
            if (!HasDirectJsonKey(start, raw_len, "threatCategory") &&
                !HasDirectJsonKey(start, raw_len, "threatType")) continue;
            cJSON* item = cJSON_ParseWithLength(start, len); if (!item) continue;
            if (!IsUavThreatEvent(item)) { cJSON_Delete(item); continue; }
            cJSON* expiry = cJSON_GetObjectItemCaseSensitive(item, "expiresAt");
            if (cJSON_IsString(expiry) && expiry->valuestring && strlen(expiry->valuestring) >= 20) {
                time_t now = time(nullptr);
                if (now > 1700000000) { struct tm utc = {}; gmtime_r(&now, &utc); char iso[24] = {}; strftime(iso, sizeof(iso), "%Y-%m-%dT%H:%M:%SZ", &utc); if (strncmp(expiry->valuestring, iso, 19) <= 0) { cJSON_Delete(item); continue; } }
            }
            // Only use event-specific display/evidence fields. Do not scan every nested
            // string: activeCauses, airport notices and linked metadata can mention cities
            // unrelated to the event's actual UAV location.
            std::string text; AppendRelevantEventText(item, text); const std::string lowered = LowerUtf8(text);
            std::vector<std::pair<size_t, const MapPoint*>> matches;
            for (const auto& p : kMapPoints) {
                size_t pos = FindLocationPosition(lowered, p.name);
                if (pos != std::string::npos) matches.push_back({pos, &p});
            }
            std::sort(matches.begin(), matches.end(), [](const auto& a, const auto& b) { if (a.first != b.first) return a.first < b.first; return strlen(a.second->name) > strlen(b.second->name); });
            std::set<std::pair<int,int>> seen_xy;
            bool contributed = false;
            for (const auto& m : matches) if (seen_xy.insert({m.second->x, m.second->y}).second) {
                locations.insert(CanonicalName(*m.second)); contributed = true;
            }
            auto add_coordinates = [&](const cJSON* pt) {
                if (!cJSON_IsObject(pt)) return;
                const cJSON* lat = cJSON_GetObjectItemCaseSensitive(pt, "lat");
                if (!cJSON_IsNumber(lat)) lat = cJSON_GetObjectItemCaseSensitive(pt, "latitude");
                const cJSON* lng = cJSON_GetObjectItemCaseSensitive(pt, "lng");
                if (!cJSON_IsNumber(lng)) lng = cJSON_GetObjectItemCaseSensitive(pt, "lon");
                if (!cJSON_IsNumber(lng)) lng = cJSON_GetObjectItemCaseSensitive(pt, "longitude");
                if (!cJSON_IsNumber(lat) || !cJSON_IsNumber(lng) || lat->valuedouble < 44.3 || lat->valuedouble > 46.0 || lng->valuedouble < 32.0 || lng->valuedouble > 36.9) return;
                const int x = 204 + static_cast<int>((lng->valuedouble - 35.2) * 48.0);
                const int y = 201 - static_cast<int>((lat->valuedouble - 45.2) * 65.0);
                const MapPoint* nearest = nullptr; int best = 24 * 24;
                for (const auto& p : kMapPoints) {
                    const int dx = p.x - x, dy = p.y - y, d = dx * dx + dy * dy;
                    if (d < best) { best = d; nearest = &p; }
                }
                if (nearest) { locations.insert(CanonicalName(*nearest)); contributed = true; }
            };
            add_coordinates(item);
            const char* arrays[] = {"points", "coordinates", "locations"};
            for (const char* key : arrays) {
                cJSON* arr = cJSON_GetObjectItemCaseSensitive(item, key);
                if (cJSON_IsArray(arr)) for (cJSON* pt = arr->child; pt; pt = pt->next) add_coordinates(pt);
                else if (cJSON_IsObject(arr)) add_coordinates(arr);
            }
            if (contributed) ++accepted;
            cJSON_Delete(item);
        }
    }
    ESP_LOGI(TAG, "Argus parsed bytes=%u accepted_location_objects=%d unique_locations=%u", (unsigned)r.size, accepted, (unsigned)locations.size());
    heap_caps_free(r.data);
    if (locations.empty()) return accepted == 0 ? "Небо чистое." : "Argus передаёт активные события, но не удалось определить их локации в пределах карты.";
    std::string answer = "По данным Argus, активные локации в пределах карты Крыма и Азовского региона: ";
    bool first = true; for (const auto& name : locations) { if (!first) answer += ", "; answer += name; first = false; }
    answer += "."; return answer;
}
std::string XmlDecodeAndStrip(std::string value) {
    const std::pair<const char*, const char*> entities[] = {
        {"&amp;", "&"}, {"&lt;", "<"}, {"&gt;", ">"}, {"&quot;", "\""}, {"&apos;", "'"}, {"&#39;", "'"}, {"&nbsp;", " "}
    };
    for (const auto& e : entities) {
        size_t pos = 0;
        while ((pos = value.find(e.first, pos)) != std::string::npos) { value.replace(pos, strlen(e.first), e.second); pos += strlen(e.second); }
    }
    std::string out; bool tag = false;
    for (char c : value) {
        if (c == '<') { tag = true; continue; }
        if (c == '>') { tag = false; continue; }
        if (!tag) out.push_back(c);
    }
    // Collapse whitespace to keep spoken output compact.
    std::string clean; bool space = false;
    for (unsigned char c : out) {
        if (std::isspace(c)) { space = !clean.empty(); continue; }
        if (space) clean.push_back(' ');
        clean.push_back(static_cast<char>(c)); space = false;
    }
    return clean;
}

std::string ExtractXmlTag(const std::string& item, const char* tag) {
    const std::string open = std::string("<") + tag + ">";
    const std::string close = std::string("</") + tag + ">";
    size_t a = item.find(open);
    if (a == std::string::npos) {
        // RSS feeds sometimes add attributes to the tag.
        a = item.find(std::string("<") + tag);
        if (a == std::string::npos) return {};
        a = item.find('>', a);
        if (a == std::string::npos) return {};
        ++a;
    } else a += open.size();
    size_t b = item.find(close, a);
    if (b == std::string::npos) return {};
    std::string value = item.substr(a, b - a);
    const size_t cdata = value.find("<![CDATA[");
    if (cdata != std::string::npos) {
        const size_t end = value.find("]]>", cdata + 9);
        if (end != std::string::npos) value = value.substr(cdata + 9, end - (cdata + 9));
    }
    return XmlDecodeAndStrip(value);
}

static std::string NewsTitleId(const std::string& title) {
    // Stable FNV-1a hash keeps the persistent NVS history compact.
    uint64_t h = 14695981039346656037ULL;
    for (unsigned char c : title) { h ^= c; h *= 1099511628211ULL; }
    char out[17]; std::snprintf(out, sizeof(out), "%016llx", static_cast<unsigned long long>(h));
    return std::string(out);
}

std::string QueryYandexMainNews() {
    struct Feed { std::string url; std::string source; };
    struct NewsItem { std::string id, title, desc, source; };
    std::vector<Feed> feeds;
    Settings settings("radio", true);
    const char* labels[] = {"RSS источник 1", "RSS источник 2", "RSS источник 3"};
    for (int i = 1; i <= 3; ++i) {
        const std::string url = settings.GetString("rss" + std::to_string(i), "");
        if (!url.empty()) feeds.push_back({url, labels[i - 1]});
    }
    if (feeds.empty()) {
        feeds.push_back({"https://ria.ru/export/rss2/index.xml", "РИА Новости"});
        feeds.push_back({"https://lenta.ru/rss", "Лента.ру"});
    }

    // Keep a compact rolling history across requests and reboots. This prevents
    // the newest RSS entries from being read over and over on every invocation.
    std::set<std::string> seen;
    std::vector<std::string> seen_order;
    std::string saved = settings.GetString("news_seen", "");
    size_t from = 0;
    while (from < saved.size()) {
        size_t comma = saved.find(',', from);
        std::string id = saved.substr(from, comma == std::string::npos ? std::string::npos : comma - from);
        if (id.size() == 16 && !seen.count(id)) { seen.insert(id); seen_order.push_back(id); }
        if (comma == std::string::npos) break;
        from = comma + 1;
    }

    std::vector<NewsItem> selected;
    std::set<std::string> selected_ids;
    for (const auto& feed : feeds) {
        if (selected.size() >= 3) break;
        ResponseBuffer r;
        r.capacity = 64 * 1024;
        r.data = static_cast<char*>(heap_caps_malloc(r.capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        if (!r.data) { ESP_LOGW(TAG, "RSS: not enough memory for %s", feed.url.c_str()); continue; }
        r.data[0] = '\0';
        esp_http_client_config_t cfg = {};
        cfg.url = feed.url.c_str();
        cfg.timeout_ms = 4500;
        cfg.crt_bundle_attach = esp_crt_bundle_attach;
        cfg.event_handler = HttpEventHandler;
        cfg.user_data = &r;
        cfg.buffer_size = 4096;
        cfg.buffer_size_tx = 1024;
        auto client = esp_http_client_init(&cfg);
        if (!client) {
            ESP_LOGW(TAG, "RSS init failed for %s", feed.url.c_str());
            heap_caps_free(r.data);
            continue;
        }
        esp_http_client_set_method(client, HTTP_METHOD_GET);
        esp_http_client_set_header(client, "User-Agent", "Mozilla/5.0 (compatible; TaijiPi/2.5)");
        esp_http_client_set_header(client, "Accept", "application/rss+xml, application/xml, text/xml, */*;q=0.8");
        esp_http_client_set_header(client, "Accept-Encoding", "identity");
        const esp_err_t err = esp_http_client_perform(client);
        const int status = esp_http_client_get_status_code(client);
        const int content_length = esp_http_client_get_content_length(client);
        esp_http_client_cleanup(client);
        ESP_LOGI(TAG, "RSS fetch source=%s err=%s status=%d bytes=%u content_length=%d overflow=%d",
                 feed.source.c_str(), esp_err_to_name(err), status, (unsigned)r.size, content_length, r.overflow);
        if (err != ESP_OK || status != 200 || r.size == 0 || r.overflow) {
            heap_caps_free(r.data);
            continue;
        }
        std::string xml(r.data, r.size);
        heap_caps_free(r.data);

        size_t pos = 0;
        while (selected.size() < 3) {
            size_t a = xml.find("<item", pos);
            if (a == std::string::npos) break;
            a = xml.find('>', a);
            if (a == std::string::npos) break;
            ++a;
            size_t b = xml.find("</item>", a);
            if (b == std::string::npos) break;
            const std::string item = xml.substr(a, b - a);
            std::string title = ExtractXmlTag(item, "title");
            std::string desc = ExtractXmlTag(item, "description");
            if (!title.empty()) {
                const std::string id = NewsTitleId(title);
                if (!seen.count(id) && !selected_ids.count(id)) {
                    if (desc.size() > 300) desc.resize(300);
                    selected.push_back({id, title, desc, feed.source});
                    selected_ids.insert(id);
                }
            }
            pos = b + 7;
        }
        if (selected.size() < 3) {
            ESP_LOGI(TAG, "RSS source %s had no more unseen items; checking next feed", feed.source.c_str());
        }
    }

    if (selected.empty()) {
        return "Я проверил все настроенные RSS-ленты, но новых новостей, которых мы ещё не читали, сейчас нет. Попробуй позже, когда источники обновятся.";
    }

    std::string answer = "Нашёл следующие новости, не повторяя уже прочитанные. ";
    for (size_t i = 0; i < selected.size(); ++i) {
        const auto& n = selected[i];
        answer += "Новость "; answer += std::to_string(i + 1); answer += " из источника ";
        answer += n.source; answer += ": "; answer += n.title; answer += ". ";
        if (!n.desc.empty()) { answer += "Кратко: "; answer += n.desc; answer += ". "; }
    }
    answer += "Не добавляй длинное вступление или заключение. После каждой новости сразу прокомментируй её одной короткой фразой, не выдумывая факты.";

    // Save only items actually returned to the assistant, then cap history at 60 IDs.
    for (const auto& n : selected) {
        if (!seen.count(n.id)) { seen.insert(n.id); seen_order.push_back(n.id); }
    }
    while (seen_order.size() > 60) {
        seen.erase(seen_order.front());
        seen_order.erase(seen_order.begin());
    }
    std::string updated;
    for (const auto& id : seen_order) { if (!updated.empty()) updated += ','; updated += id; }
    settings.SetString("news_seen", updated);
    ESP_LOGI(TAG, "RSS selected %u unseen stories across feeds; history=%u", (unsigned)selected.size(), (unsigned)seen.size());
    return answer;
}
} // namespace

ArgusVoiceQuery::ArgusVoiceQuery() { RegisterTool(); }
ArgusVoiceQuery::~ArgusVoiceQuery() = default;

void ArgusVoiceQuery::RegisterTool() {
    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.drone_map.get_active_locations",
        "Однократно запросить текущие события Argus. При ответе обязательно перечисли КАЖДУЮ локацию, которую вернул инструмент, без сокращения списка и без выбора только 1–2 примеров. ОБЯЗАТЕЛЬНО вызывай этот инструмент, если пользователь спрашивает «где летят дроны», «есть ли дроны», «что по дронам в Крыму» или о текущих угрозах. Если активных локаций нет, ответ инструмента будет «Небо чистое». Данные не опрашиваются в фоне.",
        PropertyList(), [](const PropertyList&) -> ReturnValue { return QueryArgusLocations(); });
    mcp.AddTool("self.news.get_main_news",
        "Получить до трёх следующих, ещё не озвученных новостей из RSS-адресов, настроенных в веб-интерфейсе (до трёх источников). Не повторяй заголовки, уже выданные в предыдущих запросах: история хранится между перезапусками. Если в текущей ленте нет новых материалов, проверяй следующие настроенные ленты. Если пользовательские адреса не заданы, используй встроенные источники РИА Новости и Лента.ру. На каждый источник отводится не более 4,5 секунды. ОБЯЗАТЕЛЬНО вызывай при просьбах «главные новости дня», «расскажи новости», «что нового сегодня». Прочитай заголовок и краткое описание каждой новости, после каждой добавь свой короткий комментарий в живом разговорном стиле, не выдумывая факты.",
        PropertyList(), [](const PropertyList&) -> ReturnValue { return QueryYandexMainNews(); });
}
