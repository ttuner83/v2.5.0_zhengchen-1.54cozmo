#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "zhengchen_lcd_display.h"
#include "system_reset.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "power_save_timer.h"
#include "led/single_led.h"
#include "assets/lang_config.h"
#include "power_manager.h"
#include "taiji_web_radio.h"
#include "features/drone_map/drone_map.h"
#include "mcp_server.h"

#include <esp_log.h>
#include <esp_http_client.h>
#include <esp_crt_bundle.h>
#include <cJSON.h>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <string>
#include <map>
#include <mdns.h>
#include <esp_lcd_panel_vendor.h>

#include <driver/rtc_io.h>
#include <esp_sleep.h>

// <<ttuner83>> Lightweight HTTP helpers for jokes and live CBR exchange rates.
namespace {
struct VoiceHttpBuffer { std::string body; size_t limit = 18000; };
static esp_err_t VoiceHttpEvent(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* b = static_cast<VoiceHttpBuffer*>(evt->user_data);
        if (b->body.size() + static_cast<size_t>(evt->data_len) <= b->limit)
            b->body.append(static_cast<const char*>(evt->data), evt->data_len);
    }
    return ESP_OK;
}
static bool VoiceHttpGet(const char* url, std::string& body, size_t limit = 18000) {
    VoiceHttpBuffer buffer; buffer.limit = limit;
    esp_http_client_config_t cfg = {};
    cfg.url = url; cfg.event_handler = VoiceHttpEvent; cfg.user_data = &buffer;
    cfg.crt_bundle_attach = esp_crt_bundle_attach; cfg.timeout_ms = 10000;
    cfg.buffer_size = 2048; cfg.buffer_size_tx = 1024;
    cfg.disable_auto_redirect = false; cfg.max_redirection_count = 3;
    auto client = esp_http_client_init(&cfg); if (!client) return false;
    esp_http_client_set_header(client, "User-Agent", "Xiaozhi-ESP32/2.5.0 (+voice features)");
    esp_http_client_set_header(client, "Accept", "application/json, application/xml, text/xml, */*");
    esp_http_client_set_header(client, "Accept-Encoding", "identity");
    const auto err = esp_http_client_perform(client);
    const int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client); body.swap(buffer.body);
    return err == ESP_OK && status >= 200 && status < 300 && !body.empty();
}
static std::string TrimText(std::string v) {
    while (!v.empty() && (v.front() == ' ' || v.front() == '\r' || v.front() == '\n' || v.front() == '\t')) v.erase(v.begin());
    while (!v.empty() && (v.back() == ' ' || v.back() == '\r' || v.back() == '\n' || v.back() == '\t')) v.pop_back();
    return v;
}
static std::string XmlTag(const std::string& block, const char* tag) {
    const std::string a = std::string("<") + tag + ">", z = std::string("</") + tag + ">";
    auto p = block.find(a); if (p == std::string::npos) return {}; p += a.size();
    auto e = block.find(z, p); return e == std::string::npos ? std::string() : TrimText(block.substr(p, e-p));
}
static std::string FetchRandomJoke() {
    // <<ttuner83>> Official rzhunemogu.ru JSON API (documented endpoint).
    // CType=1 means ordinary jokes; response schema: {"content":"..."}.
    std::string response;
    if (!VoiceHttpGet("https://rzhunemogu.ru/api/randjson?CType=1", response, 9000))
        return "Сайт РжуНеМогу сейчас не ответил. Попробуй попросить анекдот немного позже.";

    cJSON* root = cJSON_Parse(response.c_str());
    if (!root)
        return "Сайт анекдотов прислал ответ в неизвестном формате.";

    cJSON* item = cJSON_GetObjectItemCaseSensitive(root, "content");
    std::string joke = cJSON_IsString(item) && item->valuestring ? item->valuestring : "";
    cJSON_Delete(root);

    if (joke.empty())
        return "В ответе сайта не оказалось текста анекдота.";
    return "Анекдот с сайта РжуНеМогу. " + joke + " Источник: rzhunemogu.ru.";
}

static bool FetchCbrRates(std::map<std::string, double>& rates, std::string& date) {
    std::string xml; if (!VoiceHttpGet("https://www.cbr.ru/scripts/XML_daily.asp", xml, 24000)) return false;
    auto d = xml.find("Date=\""); if (d != std::string::npos) { d += 6; auto e = xml.find('\"', d); if (e != std::string::npos) date = xml.substr(d, e-d); }
    rates.clear(); rates["RUB"] = 1.0;
    size_t pos = 0;
    while ((pos = xml.find("<Valute", pos)) != std::string::npos) {
        auto end = xml.find("</Valute>", pos); if (end == std::string::npos) break;
        const std::string block = xml.substr(pos, end-pos); pos = end + 9;
        const auto code = XmlTag(block, "CharCode");
        const auto nominal = XmlTag(block, "Nominal"); const auto value = XmlTag(block, "Value");
        if (code.empty() || nominal.empty() || value.empty()) continue;
        char* p1 = nullptr; char* p2 = nullptr;
        const double n = strtod(nominal.c_str(), &p1);
        std::string normalized = value; for (char& c : normalized) if (c == ',') c = '.';
        const double v = strtod(normalized.c_str(), &p2);
        if (n > 0 && v > 0 && p1 && *p1 == 0 && p2 && *p2 == 0) rates[code] = v / n;
    }
    return rates.size() > 3 && rates.count("USD") && rates.count("EUR");
}
static std::string GetCurrencyRatesText() {
    std::map<std::string, double> r; std::string date;
    if (!FetchCbrRates(r, date)) return "Не удалось получить официальный курс Банка России. Проверь интернет-соединение.";
    char out[512];
    snprintf(out, sizeof(out), "Официальные курсы Банка России на %s: один доллар США — %.4f рубля, один евро — %.4f рубля, один китайский юань — %.4f рубля. Это справочные курсы ЦБ.",
        date.c_str(), r["USD"], r["EUR"], r.count("CNY") ? r["CNY"] : 0.0);
    return out;
}
static std::string ConvertCurrency(const std::string& amount_text, const std::string& from, const std::string& to) {
    std::string normalized_amount = amount_text;
    for (char& c : normalized_amount) if (c == ',') c = '.';
    char* end = nullptr; const double amount = strtod(normalized_amount.c_str(), &end);
    if (!end || end == normalized_amount.c_str() || *end != 0 || !std::isfinite(amount) || amount <= 0 || amount > 1.0e12) return "Укажи корректную положительную сумму.";
    std::map<std::string, double> r; std::string date;
    if (!FetchCbrRates(r, date)) return "Не удалось получить курс Банка России для конвертации.";
    if (!r.count(from) || !r.count(to)) return "Неизвестный код валюты. Используй ISO-коды, например RUB, USD, EUR или CNY.";
    const double result = amount * r[from] / r[to]; char out[256];
    snprintf(out, sizeof(out), "По официальному курсу Банка России на %s: %.2f %s — примерно %.2f %s. Комиссии банков и обменников не учтены.",
        date.c_str(), amount, from.c_str(), result, to.c_str());
    return out;
}
} // namespace

#define TAG "ZHENGCHEN_1_54TFT_WIFI"

class ZHENGCHEN_1_54TFT_WIFI : public WifiBoard {
private:
    Button boot_button_;
    Button volume_up_button_;
    Button volume_down_button_;
    ZHENGCHEN_LcdDisplay* display_;
    PowerSaveTimer* power_save_timer_;
    PowerManager* power_manager_;
    // Shared radio/music/web-settings and voice tools ported from the Taiji v95 firmware.
    TaijiWebRadio web_radio_;
    ArgusVoiceQuery argus_voice_query_;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;

    void InitializePowerManager() {
        power_manager_ = new PowerManager(GPIO_NUM_9);
        power_manager_->OnTemperatureChanged([this](float chip_temp) {
            display_->UpdateHighTempWarning(chip_temp);
        });

        power_manager_->OnChargingStatusChanged([this](bool is_charging) {
            if (is_charging) {
                power_save_timer_->SetEnabled(false);
                ESP_LOGI("PowerManager", "Charging started");
            } else {
                power_save_timer_->SetEnabled(true);
                ESP_LOGI("PowerManager", "Charging stopped");
            }
        });
    
    }

    // <<ttuner83>> Display dimming and idle power-save behavior.
    void InitializePowerSaveTimer() {
        rtc_gpio_init(GPIO_NUM_2);
        rtc_gpio_set_direction(GPIO_NUM_2, RTC_GPIO_MODE_OUTPUT_ONLY);
        rtc_gpio_set_level(GPIO_NUM_2, 1);

        power_save_timer_ = new PowerSaveTimer(-1, 60, 300);
        power_save_timer_->OnEnterSleepMode([this]() {
            GetDisplay()->SetPowerSaveMode(true);
            GetBacklight()->SetBrightness(1);
        });
        power_save_timer_->OnExitSleepMode([this]() {
            GetDisplay()->SetPowerSaveMode(false);
            GetBacklight()->RestoreBrightness();
        });
        power_save_timer_->SetEnabled(true);
    }

    void InitializeSpi() {
        spi_bus_config_t buscfg = {};
        buscfg.mosi_io_num = DISPLAY_SDA;
        buscfg.miso_io_num = GPIO_NUM_NC;
        buscfg.sclk_io_num = DISPLAY_SCL;
        buscfg.quadwp_io_num = GPIO_NUM_NC;
        buscfg.quadhd_io_num = GPIO_NUM_NC;
        buscfg.max_transfer_sz = DISPLAY_WIDTH * DISPLAY_HEIGHT * sizeof(uint16_t);
        ESP_ERROR_CHECK(spi_bus_initialize(SPI3_HOST, &buscfg, SPI_DMA_CH_AUTO));
    }

    // <<ttuner83>> Physical BOOT/volume controls: radio/player actions and assistant handoff.
    void InitializeButtons() {
        
        boot_button_.OnClick([this]() {
            power_save_timer_->WakeUp();
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            TaijiWebRadio::StopActiveRadioFromVoice();
            app.ToggleChatState();
        });

        // 设置开机按钮的长按事件（直接进入配网模式）
        boot_button_.OnLongPress([this]() {
            // 唤醒电源保存定时器
            power_save_timer_->WakeUp();
            // 获取应用程序实例
            auto& app = Application::GetInstance();
            
            // 进入配网模式
            app.SetDeviceState(kDeviceStateWifiConfiguring);
            
            // 重置WiFi配置以确保进入配网模式
            EnterWifiConfigMode();
        });

        volume_up_button_.OnClick([this]() {
            power_save_timer_->WakeUp();
            if (web_radio_.HandlePhysicalButton(true, false)) return;
            auto codec = GetAudioCodec();
            auto volume = codec->output_volume() + 10;
            if (volume > 100) {
                volume = 100;
            }
            codec->SetOutputVolume(volume);
            GetDisplay()->ShowNotification(Lang::Strings::VOLUME + std::to_string(volume/10));
        });

        volume_up_button_.OnLongPress([this]() {
            power_save_timer_->WakeUp();
            if (web_radio_.HandlePhysicalButton(true, true)) return;
            auto codec = GetAudioCodec();
            int volume = codec->output_volume() + 5;
            if (volume > 100) volume = 100;
            codec->SetOutputVolume(volume);
            GetDisplay()->ShowNotification(Lang::Strings::VOLUME + std::to_string(volume / 10));
        });

        volume_down_button_.OnClick([this]() {
            power_save_timer_->WakeUp();
            if (web_radio_.HandlePhysicalButton(false, false)) return;
            auto codec = GetAudioCodec();
            auto volume = codec->output_volume() - 10;
            if (volume < 0) {
                volume = 0;
            }
            codec->SetOutputVolume(volume);
            GetDisplay()->ShowNotification(Lang::Strings::VOLUME + std::to_string(volume/10));
        });

        volume_down_button_.OnLongPress([this]() {
            power_save_timer_->WakeUp();
            if (web_radio_.HandlePhysicalButton(false, true)) return;
            auto codec = GetAudioCodec();
            int volume = codec->output_volume() - 5;
            if (volume < 0) volume = 0;
            codec->SetOutputVolume(volume);
            GetDisplay()->ShowNotification(Lang::Strings::VOLUME + std::to_string(volume / 10));
        });
    }

    void InitializeSt7789Display() {
        ESP_LOGD(TAG, "Install panel IO");
        esp_lcd_panel_io_spi_config_t io_config = {};
        io_config.cs_gpio_num = DISPLAY_CS;
        io_config.dc_gpio_num = DISPLAY_DC;
        io_config.spi_mode = 3;
        io_config.pclk_hz = 80 * 1000 * 1000;
        io_config.trans_queue_depth = 10;
        io_config.lcd_cmd_bits = 8;
        io_config.lcd_param_bits = 8;
        ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi(SPI3_HOST, &io_config, &panel_io_));

        ESP_LOGD(TAG, "Install LCD driver");
        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = DISPLAY_RES;
        panel_config.rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB;
        panel_config.bits_per_pixel = 16;
        ESP_ERROR_CHECK(esp_lcd_new_panel_st7789(panel_io_, &panel_config, &panel_));
        ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_));
        ESP_ERROR_CHECK(esp_lcd_panel_init(panel_));
        ESP_ERROR_CHECK(esp_lcd_panel_swap_xy(panel_, DISPLAY_SWAP_XY));
        ESP_ERROR_CHECK(esp_lcd_panel_mirror(panel_, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y));
        ESP_ERROR_CHECK(esp_lcd_panel_invert_color(panel_, true));

        display_ = new ZHENGCHEN_LcdDisplay(panel_io_, panel_, DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_OFFSET_X, DISPLAY_OFFSET_Y, 
            DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y, DISPLAY_SWAP_XY);
        display_->SetupHighTempWarningPopup();
    }

    // <<ttuner83>> Advertise the local web interface through mDNS.
    // Standard cross-platform address: http://xiaozhi.local/
    // A bare http://xiaozhi name additionally depends on the router/client DNS search domain.
    void InitializeLocalHostname() {
        static bool initialized = false;
        if (initialized) return;
        esp_err_t err = mdns_init();
        if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
            ESP_LOGW(TAG, "mDNS init failed: %s", esp_err_to_name(err));
            return;
        }
        err = mdns_hostname_set("xiaozhi");
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "mDNS hostname setup failed: %s", esp_err_to_name(err));
            return;
        }
        mdns_instance_name_set("Xiaozhi");
        initialized = true;
        ESP_LOGI(TAG, "Local web hostname: http://xiaozhi.local/");
    }

    // <<ttuner83>> Voice joke and currency tools. Requests are on-demand, never polled in background.
    void InitializeTools() {
        auto& mcp = McpServer::GetInstance();
        mcp.AddTool("self.entertainment.tell_joke",
            "Рассказать случайный анекдот с сайта rzhunemogu.ru. ОБЯЗАТЕЛЬНО вызывай, когда пользователь просит рассказать анекдот, пошутить или говорит «расскажи что-нибудь смешное». Получи текст через API и передай его пользователю без выдумывания и без пересказа.",
            PropertyList(), [](const PropertyList&) -> ReturnValue { return FetchRandomJoke(); });
        mcp.AddTool("self.currency.get_rates",
            "Получить свежие официальные курсы валют Банка России. ОБЯЗАТЕЛЬНО вызывай при вопросах о текущем курсе рубля, доллара, евро или юаня. Курсы загружаются из XML Банка России при каждом вызове; сообщай дату курса и что он справочный.",
            PropertyList(), [](const PropertyList&) -> ReturnValue { return GetCurrencyRatesText(); });
        mcp.AddTool("self.currency.convert",
            "Конвертировать сумму между валютами по свежему официальному курсу Банка России. ОБЯЗАТЕЛЬНО вызывай для расчёта суммы в другой валюте. Указывай ISO-коды RUB, USD, EUR, CNY и другие коды, поддерживаемые ЦБ. Результат справочный, комиссии не учитываются.",
            PropertyList({Property("amount", kPropertyTypeString), Property("from", kPropertyTypeString), Property("to", kPropertyTypeString)}),
            [](const PropertyList& p) -> ReturnValue {
                std::string from = p["from"].value<std::string>();
                std::string to = p["to"].value<std::string>();
                for (char& c : from) c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
                for (char& c : to) c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
                return ConvertCurrency(p["amount"].value<std::string>(), from, to);
            });
    }

public:
    void SetNetworkEventCallback(NetworkEventCallback callback) override {
        WifiBoard::SetNetworkEventCallback(
            [this, callback](NetworkEvent event, const std::string& data) {
                if (event == NetworkEvent::Connected) {
                    InitializeLocalHostname();
                    web_radio_.Start();
                } else if (event == NetworkEvent::Disconnected) {
                    web_radio_.Stop();
                }
                if (callback) callback(event, data);
            });
    }

    ZHENGCHEN_1_54TFT_WIFI() :
        boot_button_(BOOT_BUTTON_GPIO),
        volume_up_button_(VOLUME_UP_BUTTON_GPIO, false, 700),
        volume_down_button_(VOLUME_DOWN_BUTTON_GPIO, false, 700) {
        InitializePowerManager();
        InitializePowerSaveTimer();
        InitializeSpi();
        InitializeButtons();
        InitializeSt7789Display();  
        InitializeTools();
        GetBacklight()->RestoreBrightness();
    }

    // 获取音频编解码器
    virtual AudioCodec* GetAudioCodec() override {
        // 静态实例化NoAudioCodecSimplex类
        static NoAudioCodecSimplex audio_codec(AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_SPK_GPIO_BCLK, AUDIO_I2S_SPK_GPIO_LRCK, AUDIO_I2S_SPK_GPIO_DOUT, AUDIO_I2S_MIC_GPIO_SCK, AUDIO_I2S_MIC_GPIO_WS, AUDIO_I2S_MIC_GPIO_DIN);
        // 返回音频编解码器
        return &audio_codec;
    }

    virtual Display* GetDisplay() override {
        return display_;
    }
    
    virtual Backlight* GetBacklight() override {
        static PwmBacklight backlight(DISPLAY_BACKLIGHT_PIN, DISPLAY_BACKLIGHT_OUTPUT_INVERT);
        return &backlight;
    }

    virtual bool GetBatteryLevel(int& level, bool& charging, bool& discharging) override {
        static bool last_discharging = false;
        charging = power_manager_->IsCharging();
        discharging = power_manager_->IsDischarging();
        if (discharging != last_discharging) {
            power_save_timer_->SetEnabled(discharging);
            last_discharging = discharging;
        }
        level = std::max<uint32_t>(power_manager_->GetBatteryLevel(), 20);
        return true;
    }

    virtual bool GetTemperature(float& esp32temp)  override {
        esp32temp = power_manager_->GetTemperature();
        return true;
    }

    virtual void SetPowerSaveLevel(PowerSaveLevel level) override {
        if (level != PowerSaveLevel::LOW_POWER) {
            power_save_timer_->WakeUp();
        }
        WifiBoard::SetPowerSaveLevel(level);
    }
};

DECLARE_BOARD(ZHENGCHEN_1_54TFT_WIFI);
