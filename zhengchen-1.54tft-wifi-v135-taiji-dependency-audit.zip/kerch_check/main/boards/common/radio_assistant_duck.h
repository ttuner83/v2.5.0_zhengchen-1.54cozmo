#ifndef RADIO_ASSISTANT_DUCK_H
#define RADIO_ASSISTANT_DUCK_H

// Board-neutral bridge for the shared radio/music audio pipeline.
// The Taiji and Zhengchen boards each own a separate radio implementation;
// shared audio code must call the implementation selected by Kconfig rather
// than hard-linking the Taiji class on every board.
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
#include "boards/taiji-pi-s3/taiji_web_radio.h"
inline bool IsRadioAssistantDuckActive() {
    return TaijiWebRadio::IsAssistantDuckActive();
}
inline void SetRadioAssistantDuck(bool enabled) {
    TaijiWebRadio::SetAssistantDuck(enabled);
}
#elif CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
#include "boards/zhengchen/1.54tft-wifi/zhengchen_web_radio.h"
inline bool IsRadioAssistantDuckActive() {
    return ZhengchenWebRadio::IsAssistantDuckActive();
}
inline void SetRadioAssistantDuck(bool enabled) {
    ZhengchenWebRadio::SetAssistantDuck(enabled);
}
#else
// Other boards do not have this optional web-radio ducking service.
inline bool IsRadioAssistantDuckActive() { return false; }
inline void SetRadioAssistantDuck(bool) {}
#endif

#endif  // RADIO_ASSISTANT_DUCK_H
