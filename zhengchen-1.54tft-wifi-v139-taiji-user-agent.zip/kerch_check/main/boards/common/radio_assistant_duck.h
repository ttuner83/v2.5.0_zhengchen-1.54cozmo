#ifndef RADIO_ASSISTANT_DUCK_H
#define RADIO_ASSISTANT_DUCK_H

#include "boards/common/radio_service.h"

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
inline bool IsRadioAssistantDuckActive() {
    return ActiveWebRadio::IsAssistantDuckActive();
}
inline void SetRadioAssistantDuck(bool enabled) {
    ActiveWebRadio::SetAssistantDuck(enabled);
}
#else
// Other boards do not have this optional web-radio ducking service.
inline bool IsRadioAssistantDuckActive() { return false; }
inline void SetRadioAssistantDuck(bool) {}
#endif

#endif  // RADIO_ASSISTANT_DUCK_H
