#ifndef RADIO_SERVICE_H
#define RADIO_SERVICE_H

// Select the radio implementation owned by the configured board.
// Common application code uses ActiveWebRadio and does not depend on Taiji names.
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
#include "boards/taiji-pi-s3/taiji_web_radio.h"
using ActiveWebRadio = TaijiWebRadio;
#elif CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
#include "boards/zhengchen/1.54tft-wifi/zhengchen_web_radio.h"
using ActiveWebRadio = ZhengchenWebRadio;
#endif

#endif  // RADIO_SERVICE_H
