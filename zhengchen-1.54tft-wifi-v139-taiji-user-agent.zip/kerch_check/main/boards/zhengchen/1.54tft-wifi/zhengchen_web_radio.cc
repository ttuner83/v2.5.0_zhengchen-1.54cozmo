#include "zhengchen_web_radio.h"
#include "esp32_music.h"
#include "radio_face_image.h"

#include "application.h"
#include "board.h"
#include "settings.h"
#include "mcp_server.h"
#include "display/display.h"
#include "display/lvgl_display/lvgl_font.h"

#include <algorithm>
#include <cstring>
#include <atomic>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <new>

#include <cJSON.h>
#include <esp_http_client.h>
#include <esp_crt_bundle.h>
#include <esp_wifi.h>
#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <wifi_manager.h>

#define TAG "ZhengchenWebRadio"
#define MAX_STATIONS 8

namespace {
struct ApiHttpBuffer { std::string body; };

static esp_err_t ApiHttpEvent(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* buffer = static_cast<ApiHttpBuffer*>(evt->user_data);
        if (buffer->body.size() + static_cast<size_t>(evt->data_len) <= 48 * 1024)
            buffer->body.append(static_cast<const char*>(evt->data), evt->data_len);
    }
    return ESP_OK;
}

static bool ApiHttpGet(const char* url, bool https, std::string& body, int& status) {
    ApiHttpBuffer buffer;
    esp_http_client_config_t cfg = {};
    cfg.url = url;
    cfg.timeout_ms = 12000;
    cfg.event_handler = ApiHttpEvent;
    cfg.user_data = &buffer;
    cfg.buffer_size = 4096;
    cfg.buffer_size_tx = 1024;
    if (https) cfg.crt_bundle_attach = esp_crt_bundle_attach;
    auto client = esp_http_client_init(&cfg);
    if (!client) return false;
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_http_client_set_header(client, "User-Agent", "Xiaozhi-ESP32/2.5");
    esp_http_client_set_header(client, "Accept", "application/xml, application/json, text/plain, */*");
    const esp_err_t err = esp_http_client_perform(client);
    status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);
    body.swap(buffer.body);
    return err == ESP_OK && status >= 200 && status < 300 && !body.empty();
}

static std::string XmlTag(const std::string& block, const char* tag) {
    const std::string open = std::string("<") + tag + ">";
    const std::string close = std::string("</") + tag + ">";
    size_t a = block.find(open);
    if (a == std::string::npos) return {};
    a += open.size();
    size_t b = block.find(close, a);
    return b == std::string::npos ? std::string() : block.substr(a, b - a);
}

struct CbrRate { std::string code, name, date; double per_unit = 0.0; int nominal = 1; };
static bool LoadCbrRates(std::vector<CbrRate>& rates) {
    std::string xml; int status = 0;
    if (!ApiHttpGet("https://www.cbr.ru/scripts/XML_daily.asp", true, xml, status)) return false;
    std::string rate_date;
    const size_t date_pos = xml.find("Date=\"");
    if (date_pos != std::string::npos) {
        const size_t date_start = date_pos + 6;
        const size_t date_end = xml.find('\"', date_start);
        if (date_end != std::string::npos) rate_date = xml.substr(date_start, date_end - date_start);
    }
    size_t pos = 0;
    while ((pos = xml.find("<Valute", pos)) != std::string::npos) {
        size_t end = xml.find("</Valute>", pos);
        if (end == std::string::npos) break;
        end += 9;
        std::string item = xml.substr(pos, end - pos);
        CbrRate r;
        r.date = rate_date;
        r.code = XmlTag(item, "CharCode");
        r.name = XmlTag(item, "Name");
        // ESP-IDF builds this component with C++ exceptions disabled.
        // Use the C conversion routines, which report parse failure without throwing.
        const std::string nominal_text = XmlTag(item, "Nominal");
        char* nominal_end = nullptr;
        const long nominal_value = std::strtol(nominal_text.c_str(), &nominal_end, 10);
        r.nominal = (nominal_end != nominal_text.c_str() && *nominal_end == '\0' && nominal_value > 0)
            ? static_cast<int>(std::min<long>(nominal_value, 1000000L)) : 1;

        std::string value = XmlTag(item, "Value");
        std::replace(value.begin(), value.end(), ',', '.');
        char* value_end = nullptr;
        const double parsed_value = std::strtod(value.c_str(), &value_end);
        r.per_unit = (value_end != value.c_str() && *value_end == '\0' && parsed_value > 0.0)
            ? parsed_value / r.nominal : 0.0;
        if (!r.code.empty() && r.per_unit > 0.0) rates.push_back(r);
        pos = end;
    }
    rates.push_back({"RUB", "Российский рубль", rate_date, 1.0, 1});
    return rates.size() > 1;
}

static std::string NormalizeCurrencyCode(std::string code) {
    // Keep Russian aliases case-insensitive without depending on locale-aware toupper.
    if (code == "рубль" || code == "рубли" || code == "руб" || code == "российский рубль" || code == "RUR") return "RUB";
    if (code == "доллар" || code == "доллары" || code == "доллар сша" || code == "американский доллар") return "USD";
    if (code == "евро") return "EUR";
    if (code == "юань" || code == "юани" || code == "китайский юань") return "CNY";
    if (code == "фунт" || code == "фунт стерлингов" || code == "британский фунт") return "GBP";
    if (code == "тенге" || code == "казахстанский тенге") return "KZT";
    if (code == "белорусский рубль" || code == "белорусские рубли") return "BYN";
    if (code == "турецкая лира" || code == "лира" || code == "лиры") return "TRY";
    for (char& c : code) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    if (code == "RUR") return "RUB";
    return code;
}

static const CbrRate* FindCbrRate(const std::vector<CbrRate>& rates, const std::string& raw) {
    const std::string code = NormalizeCurrencyCode(raw);
    for (const auto& r : rates) if (r.code == code) return &r;
    return nullptr;
}

static std::string GetRandomJoke() {
    std::string body; int status = 0;
    if (!ApiHttpGet("https://rzhunemogu.ru/api/randjson?CType=1", true, body, status))
        return "Не удалось получить анекдот: сервис сейчас недоступен. Попробуй ещё раз позже.";
    // The API may include raw control characters in the JSON response.
    body.erase(std::remove_if(body.begin(), body.end(), [](unsigned char c) {
        return c == '\f' || c == '\n' || c == '\r' || c == '\t' || c == '\v';
    }), body.end());
    cJSON* root = cJSON_Parse(body.c_str());
    if (!root) return "Сервис анекдотов вернул ответ, который не удалось разобрать.";
    cJSON* content = cJSON_GetObjectItemCaseSensitive(root, "content");
    std::string joke = cJSON_IsString(content) && content->valuestring ? content->valuestring : "";
    cJSON_Delete(root);
    if (joke.empty()) return "Сервис анекдотов не прислал текст анекдота.";
    return joke;
}
}
// Keep Wi-Fi awake while either the radio or the voice assistant is active.
// In idle state, return to modem-sleep so the device can wait for the wake word
// with lower Wi-Fi power consumption.
int ZhengchenWebRadio::GetListeningTimeoutSeconds() {
    Settings st("radio", false);
    int seconds = atoi(st.GetString("listen_seconds", "15").c_str());
    if (seconds < 1) seconds = 1;
    if (seconds > 3600) seconds = 3600;
    return seconds;
}

int ZhengchenWebRadio::GetIdleTimeoutSeconds() {
    Settings st("radio", false);
    int seconds = atoi(st.GetString("idle_seconds", "15").c_str());
    if (seconds < 1) seconds = 1;
    if (seconds > 3600) seconds = 3600;
    return seconds;
}

void ZhengchenWebRadio::UpdateWifiPowerSave() {
    const bool radio_active = instance_ != nullptr && instance_->IsRadioActive();
    const auto state = Application::GetInstance().GetDeviceState();
    // Only the idle state is allowed to use Wi-Fi modem-sleep. All other
    // application states keep Wi-Fi awake because they may involve network
    // activity or audio playback/recording.
    // The state machine may become IDLE before the final assistant audio packets
    // and protocol channel have drained. Treat that tail as active work too.
    const bool assistant_active = state != kDeviceStateIdle ||
        !Application::GetInstance().CanEnterSleepMode();

    const wifi_ps_type_t target = (radio_active || assistant_active)
        ? WIFI_PS_NONE
        : WIFI_PS_MIN_MODEM;

    static wifi_ps_type_t last_mode = WIFI_PS_MAX_MODEM;
    if (target != last_mode) {
        esp_err_t err = esp_wifi_set_ps(target);
        if (err == ESP_OK) {
            last_mode = target;
            ESP_LOGI(TAG, "Wi-Fi power save: %s",
                     target == WIFI_PS_NONE ? "NONE" : "MIN_MODEM");
        } else {
            ESP_LOGW(TAG, "Failed to set Wi-Fi power save mode %d: %s",
                     (int)target, esp_err_to_name(err));
        }
    }
}

// Wikipedia reference: bounded HTTP responses to protect ESP32-S3 RAM.
struct WikiHttpBuffer { std::string body; size_t limit = 12000; };
static esp_err_t WikiHttpEvent(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* b = static_cast<WikiHttpBuffer*>(evt->user_data);
        if (b->body.size() + static_cast<size_t>(evt->data_len) <= b->limit)
            b->body.append(static_cast<const char*>(evt->data), evt->data_len);
    }
    return ESP_OK;
}
static std::string WikiUrlEncode(const std::string& in) {
    static const char hex[] = "0123456789ABCDEF"; std::string out;
    for (unsigned char c : in) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c=='-' || c=='_' || c=='.' || c=='~') out += (char)c;
        else if (c == ' ') out += "%20";
        else { out += '%'; out += hex[c >> 4]; out += hex[c & 15]; }
    }
    return out;
}
static bool WikiGet(const std::string& url, std::string& body, size_t max_size=12000) {
    WikiHttpBuffer buffer; buffer.limit=max_size;
    esp_http_client_config_t cfg = {};
    cfg.url=url.c_str(); cfg.event_handler=WikiHttpEvent; cfg.user_data=&buffer;
    cfg.crt_bundle_attach=esp_crt_bundle_attach; // Required: verify Wikipedia TLS certificate.
    cfg.timeout_ms=9000; cfg.buffer_size=2048; cfg.buffer_size_tx=1024;
    cfg.disable_auto_redirect=false; cfg.max_redirection_count=3;
    esp_http_client_handle_t client=esp_http_client_init(&cfg);
    if (!client) return false;
    esp_http_client_set_header(client,"User-Agent","XiaozhiZhengchenRadio/1.0 (Wikipedia reference)");
    esp_http_client_set_header(client,"Accept","application/json");
    esp_err_t err=esp_http_client_perform(client);
    int status=esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client); body.swap(buffer.body);
    return err==ESP_OK && status>=200 && status<300 && !body.empty();
}
static std::string WikiSummary(const std::string& query) {
    if (query.empty()) return "Назовите тему или термин для поиска в Википедии.";
    std::string body;
    const std::string search_url="https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch="+WikiUrlEncode(query)+"&srlimit=1&format=json&utf8=1";
    if (!WikiGet(search_url,body,10000)) return "Не удалось подключиться к русской Википедии. Проверьте интернет-соединение.";
    cJSON* root=cJSON_Parse(body.c_str()); if (!root) return "Википедия вернула некорректный ответ.";
    cJSON* query_obj=cJSON_GetObjectItem(root,"query"); cJSON* results=query_obj?cJSON_GetObjectItem(query_obj,"search"):nullptr;
    cJSON* first=(results && cJSON_IsArray(results))?cJSON_GetArrayItem(results,0):nullptr;
    cJSON* title=first?cJSON_GetObjectItem(first,"title"):nullptr;
    std::string article=(cJSON_IsString(title)&&title->valuestring)?title->valuestring:""; cJSON_Delete(root);
    if (article.empty()) return "В русской Википедии не нашлось подходящей статьи по запросу: "+query;
    const std::string extract_url="https://ru.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&exchars=1800&redirects=1&titles="+WikiUrlEncode(article)+"&format=json&utf8=1";
    if (!WikiGet(extract_url,body,12000)) return "Нашёл статью «"+article+"», но не удалось загрузить её краткое содержание.";
    root=cJSON_Parse(body.c_str()); if (!root) return "Нашёл статью «"+article+"», но ответ с описанием не удалось разобрать.";
    query_obj=cJSON_GetObjectItem(root,"query"); cJSON* pages=query_obj?cJSON_GetObjectItem(query_obj,"pages"):nullptr;
    cJSON* page=(pages && cJSON_IsObject(pages))?pages->child:nullptr; cJSON* extract=page?cJSON_GetObjectItem(page,"extract"):nullptr;
    std::string summary=(cJSON_IsString(extract)&&extract->valuestring)?extract->valuestring:""; cJSON_Delete(root);
    if (summary.empty()) return "Статья «"+article+"» найдена, но краткое описание отсутствует.";
    // Keep TTS response concise and avoid reading excessive text.
    const std::string lower_query = query;
    const bool wants_detail = lower_query.find("подробнее") != std::string::npos || lower_query.find("совсем подробно") != std::string::npos || lower_query.find("подробно") != std::string::npos;
    const size_t summary_limit = wants_detail ? 1700 : 650;
    if (summary.size()>summary_limit) {
        summary.resize(summary_limit);
        while (!summary.empty() && (static_cast<unsigned char>(summary.back()) & 0xC0) == 0x80) summary.pop_back();
        if (!summary.empty()) {
            const unsigned char last = static_cast<unsigned char>(summary.back());
            if ((last & 0xE0) == 0xC0 || (last & 0xF0) == 0xE0 || (last & 0xF8) == 0xF0) summary.pop_back();
        }
    }
    return "По данным русской Википедии. Статья: "+article+". "+summary;
}

ZhengchenWebRadio* ZhengchenWebRadio::instance_ = nullptr;
static std::atomic<bool> g_radio_assistant_duck{false};

bool ZhengchenWebRadio::IsRadioActive() const {
    // Keep the device awake for the whole music-player session, including the
    // short gap between network download completion and the final decoded PCM.
    // The player screen remains open until the user explicitly returns to the assistant.
    return radio_.IsPlaying() || radio_.IsDownloading() || music_ui_visible_ ||
           music_search_active_.load() ||
           (music_player_ && (music_player_->IsPlaying() || music_player_->IsDownloading()));
}

bool ZhengchenWebRadio::IsAnyRadioActive() {
    return instance_ != nullptr && instance_->IsRadioActive();
}

bool ZhengchenWebRadio::StopActiveRadioFromVoice() {
    auto* radio = instance_;
    if (radio == nullptr) return false;
    bool stopped = false;
    if (radio->radio_.IsPlaying() || radio->radio_.IsDownloading()) {
        ESP_LOGI(TAG, "Local voice command: stopping Internet radio");
        stopped = radio->StopPlayback() || stopped;
    }
    if (radio->music_player_ && (radio->music_player_->IsPlaying() || radio->music_player_->IsDownloading() ||
                                  radio->music_ui_visible_ || radio->playlist_active_.load() || radio->music_search_active_.load())) {
        ESP_LOGI(TAG, "Wake-word/BOOT: cancelling playlist/search and stopping music before assistant takeover");
        radio->playlist_active_.store(false);
        radio->playlist_generation_.fetch_add(1);
        radio->playlist_current_index_.store(-1);
        radio->pending_music_history_index_.store(-2);
        radio->music_player_->StopStreaming();
        auto& audio = Application::GetInstance().GetAudioService();
        audio.ResetDecoder();
        for (int wait_ms = 0; wait_ms < 250 && !audio.IsPlaybackIdle(); wait_ms += 5)
            vTaskDelay(pdMS_TO_TICKS(5));
        radio->ShowMusicUi(false);
        radio->music_search_active_.store(false);
        radio->UpdateWifiPowerSave();
        stopped = true;
    }
    return stopped;
}

void ZhengchenWebRadio::SetAssistantDuck(bool enabled) { g_radio_assistant_duck.store(enabled); }
bool ZhengchenWebRadio::IsAssistantDuckActive() { return g_radio_assistant_duck.load(); }


static const char kHtml[] = R"HTML(
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zhengchen Radio</title>
<style>
body{font-family:Arial,sans-serif;max-width:760px;margin:20px auto;padding:0 12px;background:#f4f4f4;color:#222}
h2{margin-bottom:8px}.card{background:#fff;padding:14px;margin:10px 0;border-radius:10px}
input,select,button{font-size:16px;padding:9px;margin:4px 0;box-sizing:border-box}
input{width:100%}button{cursor:pointer}.row{display:flex;gap:8px;flex-wrap:wrap}.row button{flex:1}
small{color:#666;word-break:break-all}.playing{font-weight:bold}
</style></head><body>
<h2>Zhengchen 1.54 TFT WiFi — Internet Radio</h2>
<div class="card"><div id="list">Загрузка...</div></div>
<div class="card"><b>Добавить / изменить станцию</b>
<input id="slot" type="number" min="0" max="7" value="0" placeholder="Номер 0..7">
<input id="name" placeholder="Название станции">
<input id="url" placeholder="http://... или https://...">
<select id="type"><option value="mp3">MP3</option><option value="aac">AAC</option><option value="ogg">OGG/Opus</option><option value="wav">WAV</option></select>
<div class="row"><button onclick="save()">Сохранить</button><button onclick="stop()">Стоп</button></div>
</div>
<div class="card"><b>Настройки энергосбережения и источников</b>
<label>Таймер прослушивания (секунды)</label><input id="listenSeconds" type="number" min="1" max="3600" value="15">
<label>Выключать дисплей после ожидания (секунды)</label><input id="idleSeconds" type="number" min="1" max="3600" value="15">
<label>RSS новости — адрес 1</label><input id="rss1" placeholder="https://...">
<label>RSS новости — адрес 2</label><input id="rss2" placeholder="https://...">
<label>RSS новости — адрес 3</label><input id="rss3" placeholder="https://...">
<label>Адрес парсера дронов</label><input id="droneUrl" placeholder="https://...">
<label>Базовая громкость радио, % (200 = усиление ×2)</label><input id="radioBaseGain" type="number" min="100" max="400" value="200">
<label>Текущая громкость радио, %</label><input id="radioCurrentVolume" type="number" min="0" max="100" value="40">
<label>Громкость помощника, % (не влияет на MP3-плеер)</label><input id="assistantVolume" type="number" min="0" max="100" value="70">
<button onclick="saveConfig()">Сохранить настройки</button><small id="configStatus"></small>
</div>
<script>
async function loadConfig(){try{let c=await(await fetch('/api/config')).json();document.getElementById('listenSeconds').value=c.listen_seconds||15;document.getElementById('idleSeconds').value=c.idle_seconds||15;document.getElementById('rss1').value=c.rss1||'';document.getElementById('rss2').value=c.rss2||'';document.getElementById('rss3').value=c.rss3||'';document.getElementById('droneUrl').value=c.drone_url||'';document.getElementById('radioBaseGain').value=c.radio_base_gain_pct||200;document.getElementById('radioCurrentVolume').value=c.radio_volume||40;document.getElementById('assistantVolume').value=c.assistant_volume||70;}catch(e){document.getElementById('configStatus').textContent='Не удалось загрузить настройки';}}
async function saveConfig(){let c={listen_seconds:+document.getElementById('listenSeconds').value,idle_seconds:+document.getElementById('idleSeconds').value,rss1:document.getElementById('rss1').value,rss2:document.getElementById('rss2').value,rss3:document.getElementById('rss3').value,drone_url:document.getElementById('droneUrl').value,radio_base_gain_pct:+document.getElementById('radioBaseGain').value,radio_volume:+document.getElementById('radioCurrentVolume').value,assistant_volume:+document.getElementById('assistantVolume').value};let r=await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});document.getElementById('configStatus').textContent=r.ok?'Сохранено':'Ошибка сохранения';}
async function load(){
 let r=await fetch('/api/radios'); let a=await r.json();
 let h='';
 a.forEach((x,i)=>{if(!x.url)return;
 h+=`<div class="card"><b>${i}: ${esc(x.name||'Без названия')}</b><br><small>${esc(x.url)} [${esc(x.type||'mp3')}]</small>
 <div class="row"><button onclick="play(${i})">▶ Играть</button><button onclick="edit(${i})">Изменить</button><button onclick="del(${i})">Удалить</button></div></div>`});
 document.getElementById('list').innerHTML=h||'Станций пока нет';
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function save(){
 let o={slot:+slot.value,name:name.value,url:url.value,type:type.value};
 await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});
 load();
}
async function play(i){await fetch('/api/play?slot='+i);load()}
async function stop(){await fetch('/api/stop')}
async function del(i){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:i,delete:true})});load()}
async function edit(i){
 let a=await (await fetch('/api/radios')).json(),x=a[i];
 slot.value=i;name.value=x.name||'';url.value=x.url||'';type.value=x.type||'mp3';
}
load();loadConfig();
</script></body></html>
)HTML";

static bool ReadBody(httpd_req_t* req, std::string& body) {
    if (req->content_len <= 0 || req->content_len > 4096) {
        return false;
    }
    body.resize(req->content_len);
    size_t received = 0;
    while (received < body.size()) {
        int ret = httpd_req_recv(req, body.data() + received, body.size() - received);
        if (ret <= 0) {
            return false;
        }
        received += ret;
    }
    return true;
}

// Normalize UTF-8 Russian station names for voice matching: ignore punctuation/spacing,
// fold ASCII and Cyrillic uppercase, and treat ё/е as equivalent.
static std::string NormalizeStationName(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (size_t i = 0; i < input.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(input[i]);
        if (c == 0xD0 && i + 1 < input.size()) {
            unsigned char n = static_cast<unsigned char>(input[i + 1]);
            if (n >= 0x90 && n <= 0xAF) n = static_cast<unsigned char>(n + 0x20); // А-Я -> а-я
            if (n == 0x81) { // Ё -> ё, then fold ё to е below
                out += "е";
                ++i;
                continue;
            }
            out.push_back(static_cast<char>(c));
            out.push_back(static_cast<char>(n));
            ++i;
            continue;
        }
        if (c == 0xD1 && i + 1 < input.size()) {
            unsigned char n = static_cast<unsigned char>(input[i + 1]);
            if (n == 0x91) { out += "е"; ++i; continue; } // ё -> е
            out.push_back(static_cast<char>(c));
            out.push_back(static_cast<char>(n));
            ++i;
            continue;
        }
        if (c < 0x80) {
            if (std::isalnum(c)) out.push_back(static_cast<char>(std::tolower(c)));
            continue;
        }
        out.push_back(static_cast<char>(c));
    }
    return out;
}

// <<ttuner83>> Radio web UI, station storage, music player and voice-control integration.
ZhengchenWebRadio::ZhengchenWebRadio() {
    instance_ = this;
    radio_.Initialize();
    music_player_ = std::make_unique<Esp32Music>();

    LoadStations();

    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.currency.get_rates",
        "Получи актуальные официальные курсы основных валют Центрального банка России на сегодня. Используй, когда спрашивают курс доллара, евро, юаня или другие курсы валют. Источник — официальный XML_daily.asp ЦБ РФ; сообщай дату ответа сервиса, если она присутствует, и не выдумывай курсы.",
        PropertyList(), [](const PropertyList&) -> ReturnValue {
            std::vector<CbrRate> rates;
            if (!LoadCbrRates(rates)) return std::string("Не удалось получить курсы Центрального банка России. Проверь подключение к интернету и попробуй позже.");
            std::string out = "Официальные курсы ЦБ РФ, пересчитанные на одну единицу валюты: ";
            int shown = 0;
            for (const char* code : {"USD", "EUR", "CNY", "GBP", "KZT", "BYN", "TRY"}) {
                const auto* r = FindCbrRate(rates, code);
                if (!r) continue;
                char value[32]; snprintf(value, sizeof(value), "%.4f", r->per_unit);
                if (shown++) out += "; ";
                out += std::string(code) + " — " + value + " руб.";
            }
            if (!rates.empty() && !rates.front().date.empty()) out += ". Дата курсов ЦБ РФ: " + rates.front().date + ".";
            out += " Это основные популярные валюты; для конвертации другой валюты используй её ISO-код.";
            return out;
        });
    mcp.AddTool("self.currency.convert",
        "Конвертируй сумму между валютами по последним официальным курсам ЦБ РФ. ОБЯЗАТЕЛЬНО используй этот инструмент для просьб вроде «сколько 100 долларов в рублях», «переведи 5000 рублей в евро», «сколько будет 20 евро в юанях». Передай сумму, исходную валюту и целевую валюту кодами ISO (USD, EUR, RUB, CNY, GBP, KZT, BYN, TRY и т.д.) либо распространёнными русскими названиями. Расчёт: сумма умножается на курс исходной валюты к рублю и делится на курс целевой валюты к рублю.",
        PropertyList({Property("amount", kPropertyTypeString), Property("from", kPropertyTypeString), Property("to", kPropertyTypeString)}),
        [](const PropertyList& properties) -> ReturnValue {
            const std::string amount_text = properties["amount"].value<std::string>();
            char* amount_end = nullptr;
            const double amount = std::strtod(amount_text.c_str(), &amount_end);
            const std::string from = properties["from"].value<std::string>();
            const std::string to = properties["to"].value<std::string>();
            if (amount_end == amount_text.c_str() || !amount_end || *amount_end != '\0' || !(amount >= 0.0) || amount > 1.0e12 || from.empty() || to.empty()) return std::string("Укажи корректную сумму и обе валюты.");
            std::vector<CbrRate> rates;
            if (!LoadCbrRates(rates)) return std::string("Не удалось получить актуальные курсы ЦБ РФ. Конвертация не выполнена.");
            const auto* a = FindCbrRate(rates, from);
            const auto* b = FindCbrRate(rates, to);
            if (!a || !b) return std::string("Не распознал одну из валют. Используй код ISO, например USD, EUR, RUB или CNY.");
            const double result = amount * a->per_unit / b->per_unit;
            char number[64]; snprintf(number, sizeof(number), "%.2f", result);
            char input[64]; snprintf(input, sizeof(input), "%.2f", amount);
            return std::string(input) + " " + a->code + " = " + number + " " + b->code + " по официальным курсам ЦБ РФ.";
        });
    mcp.AddTool("self.jokes.random",
        "Расскажи случайный анекдот. ОБЯЗАТЕЛЬНО вызывай при просьбах «расскажи анекдот», «скажи шутку», «рассмеши меня», «ещё анекдот». Получи свежий текст через API rzhunemogu.ru и верни его для озвучивания штатным голосом. Не сочиняй анекдот, если API недоступен — сообщи об ошибке.",
        PropertyList(), [](const PropertyList&) -> ReturnValue { return GetRandomJoke(); });
    mcp.AddTool("self.wikipedia.search",
        "Найди справочную информацию в русской Википедии и озвучь краткое содержание статьи. Используй для вопросов вида «что такое ...», «расскажи о ...», «найди в Википедии ...», когда нужен энциклопедический факт или описание. Передай короткую тему поиска в параметре query. Это справочный источник, не источник оперативных новостей.",
        PropertyList({Property("query", kPropertyTypeString)}),
        [](const PropertyList& properties) -> ReturnValue {
            const std::string query=properties["query"].value<std::string>();
            ESP_LOGI(TAG, "Wikipedia lookup requested (query length=%u)", (unsigned)query.size());
            return WikiSummary(query);
        });
    mcp.AddTool("self.network.get_ip",
        "Report the current local Wi-Fi IP address and web radio interface URL. Use for requests such as: 'Скажи свой IP', 'Какой у тебя IP-адрес?', 'Назови адрес веб-интерфейса в локальной сети'.",
        PropertyList(),
        [](const PropertyList&) -> ReturnValue {
            auto& wifi = WifiManager::GetInstance();
            std::string ip = wifi.GetIpAddress();
            if (ip.empty()) return std::string("Wi-Fi не подключён, локальный IP пока неизвестен.");
            return std::string("Локальный IP устройства: ") + ip + ". Веб-интерфейс радио: http://" + ip + "/";
        });
    auto music_search_handler = [this](const PropertyList& properties) -> ReturnValue {
        const std::string song = properties["song_name"].value<std::string>();
        const std::string artist = properties["artist_name"].value<std::string>();
        ESP_LOGI(TAG, "Music search tool invoked: song='%s', artist='%s'", song.c_str(), artist.c_str());
        if ((song.empty() && artist.empty()) || !music_player_) return std::string("нет такой");
        // A new single-track request supersedes any playlist/search already in flight.
        playlist_active_.store(false);
        playlist_generation_.fetch_add(1);
        playlist_current_index_.store(-1);
        pending_music_history_index_.store(-2);
        if (!PlayMusicSearch(song, artist, true, 0)) {
            if (music_player_ && music_player_->HadOnlySmallTracks())
                return std::string("Не нашлось песни больше 1 МБ.");
            return std::string("нет такой");
        }
        // Do not narrate search steps or announce a successful match; start playback silently.
        return std::string("");
    };
    mcp.AddTool("self.music.play_playlist",
        "Включи плейлист из нескольких песен по порядку. Передай playlist как строки, по одной на строку, формат каждой строки: исполнитель|название песни. Сначала ищется и запускается только первая песня; следующая ищется лишь после полного завершения предыдущей. Не ищи песни во время воспроизведения.",
        PropertyList({Property("playlist", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            const std::string playlist = properties["playlist"].value<std::string>();
            if (!StartPlaylist(playlist)) return std::string("Не удалось запустить плейлист.");
            return std::string("");
        });
    const PropertyList music_search_properties({Property("song_name", kPropertyTypeString), Property("artist_name", kPropertyTypeString, "")});
    mcp.AddTool("self.music.play_song",
        "ОБЯЗАТЕЛЬНО вызови этот инструмент при любой просьбе найти/включить музыку; не говори, что уже искал, пока реально не вызвал инструмент. Поиск может занимать 30 секунд и дольше — дождись результата. Ищи молча, при успехе ничего не комментируй. Если пользователь просит «любую песню [исполнитель/группа]», передай song_name пустой строкой, artist_name — имя исполнителя; это полноценный запрос на любую песню группы, не проси название композиции. Если название песни известно, передай его в song_name и исполнителя в artist_name. Сохраняй язык/написание, явно заданные пользователем. Устройство проверяет несколько вариантов и пропускает известные файлы размером 1 МБ или меньше; если все варианты слишком малы, сообщи только, что не нашлось песни больше 1 МБ. Если результат не найден, скажи только «нет такой». Не сообщай пользователю о шагах поиска или найденном треке. Источник — публичный Meting API (NetEase).",
        music_search_properties, music_search_handler);
mcp.AddTool("self.music.set_volume", "Установи только независимую громкость музыкального плеера от 0 до 100%. Не меняй громкость помощника и радио.",
        PropertyList({Property("volume", kPropertyTypeInteger, 100, 0, 100)}),
        [](const PropertyList& p) -> ReturnValue { Esp32Music::SetVolume(p["volume"].value<int>()); return std::string(""); });
    mcp.AddTool("self.music.get_volume", "Получить независимую громкость музыкального плеера.", PropertyList(),
        [](const PropertyList&) -> ReturnValue { return Esp32Music::GetVolume(); });
    // Confirm a known-small file only after the user explicitly agrees.
    mcp.AddTool("self.music.confirm_short_song",
        "Вызывай только после явного согласия пользователя включить найденную неполную песню размером меньше 1 МБ. Не вызывай при сомнении или отказе.",
        PropertyList(), [this](const PropertyList&) -> ReturnValue {
            if (!ConfirmShortSongPlayback()) return std::string("Не удалось запустить сохранённый короткий вариант песни.");
            return std::string("");
        });
// Не регистрируем короткий alias search_music: это имя уже занято другим MCP-инструментом.
    mcp.AddTool("self.music.stop", "Останови воспроизведение музыки.", PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            playlist_active_.store(false);
            playlist_generation_.fetch_add(1);
            playlist_current_index_.store(-1);
            pending_music_history_index_.store(-2);
            if (music_player_) music_player_->StopStreaming();
            UpdateMusicUi();
            return std::string("Воспроизведение музыки остановлено.");
        });
    mcp.AddTool("self.radio.play",
        "Start the selected saved Internet radio station. Use for requests such as: 'Включи радио', 'Запусти радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return PlaySelected(); });
    mcp.AddTool("self.radio.play_station",
        "Start a saved Internet radio station by number. The user-visible station numbers start at 1. Use for requests such as: 'Включи станцию 4', 'Запусти станцию номер 4'.",
        PropertyList({Property("station", kPropertyTypeInteger, 1, 1, MAX_STATIONS)}),
        [this](const PropertyList& properties) -> ReturnValue {
            return PlayStation(properties["station"].value<int>());
        });
    mcp.AddTool("self.radio.play_station_by_name",
        "Включи радиостанцию по её названию из текущего списка веб-интерфейса. Используй для фраз «включи радио Европа Плюс», «включи радио Рок Арсенал», «поставь радио [название]». Название бери из слов пользователя и передавай целиком; не выбирай номер станции по памяти — устройство само сопоставит имя с актуальными станциями, сохранёнными в веб-интерфейсе. Если совпадения нет, сообщи об этом и предложи проверить название в веб-интерфейсе.",
        PropertyList({Property("name", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            const std::string name = properties["name"].value<std::string>();
            const bool ok = PlayStationByName(name);
            return ok ? ReturnValue(std::string("Включаю радиостанцию: ") + name)
                      : ReturnValue(std::string("Не нашёл станцию «") + name + "» среди настроенных в веб-интерфейсе.");
        });
    mcp.AddTool("self.radio.next",
        "Switch to the next configured Internet radio station and start it. Use for requests such as: 'Следующая радиостанция', 'Переключи радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return NextStation(); });
    mcp.AddTool("self.radio.stop",
        "Вызови self.radio.stop при любой просьбе выключить или остановить интернет-радио/музыку: «выключи радио», «выруби радио», «отключи радио», «останови радио», «хватит радио», «стоп радио», «выключи музыку». Не отвечай только словами — выполни инструмент. Он останавливает поток и не меняет громкость помощника.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            const bool stopped = StopPlayback();
            return stopped ? ReturnValue(std::string("Радио выключено.")) : ReturnValue(std::string("Не удалось штатно остановить радио."));
        });
    mcp.AddTool("self.radio.get_volume",
        "Get ONLY the independent Internet radio volume (0-100%). This is separate from self.audio_speaker.set_volume. Use for radio volume requests such as 'громкость радио', 'радио громче' or 'радио тише'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return radio_.GetVolume(); });
    mcp.AddTool("self.radio.set_volume",
        "Set ONLY the independent Internet radio volume from 0 to 100%. NEVER use self.audio_speaker.set_volume for this. Use this tool when the user says 'громкость радио 30%', 'радио 30%', 'громкость радио', 'сделай радио тише' or 'сделай радио громче'. This must not change the voice assistant volume.",
        PropertyList({Property("volume", kPropertyTypeInteger, 40, 0, 100)}),
        [this](const PropertyList& properties) -> ReturnValue {
            radio_.SetVolume(properties["volume"].value<int>());
            if (radio_ui_visible_) {
                auto display = Board::GetInstance().GetDisplay();
                if (display) {
                    DisplayLockGuard lock(display);
                    if (lock) UpdateRadioStationLabel();
                }
            }
            return true;
        });
}

ZhengchenWebRadio::~ZhengchenWebRadio() {
    Stop();
    if (silent_standby_timer_) {
        esp_timer_delete(silent_standby_timer_);
        silent_standby_timer_ = nullptr;
    }
    if (radio_button_flash_timer_) { lv_timer_delete(radio_button_flash_timer_); radio_button_flash_timer_ = nullptr; }
    if (instance_ == this) {
        instance_ = nullptr;
    }
}

void ZhengchenWebRadio::LoadStations() {
    stations_.clear();
    stations_.resize(MAX_STATIONS);
    Settings settings("radio", false);
    struct Preset { const char* name; const char* url; const char* type; };
    static const Preset presets[MAX_STATIONS] = {
        {"Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "mp3"},
        {"Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med", "mp3"},
        {"Кассета Диско", "https://casseta-disco.ru:1090/stream", "mp3"},
        {"Рок Атака", "https://listen7.myradio24.com/rockataka", "mp3"},
        {"Максимус Рок", "https://maximusrockfm.stream.laut.fm/maximusrockfm", "mp3"},
        {"Рок Арсенал", "https://online.rockarsenal.ru/rockwotalk?5423", "mp3"},
        {"Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "mp3"},
        {"Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "mp3"},
    };
    for (int i = 0; i < MAX_STATIONS; ++i) {
        std::string key = "r" + std::to_string(i);
        std::string value = settings.GetString(key, "");
        if (value.empty()) {
            stations_[i].name = presets[i].name;
            stations_[i].url = presets[i].url;
            stations_[i].type = presets[i].type;
            continue;
        }
        cJSON* obj = cJSON_Parse(value.c_str());
        if (!obj) {
            continue;
        }
        auto get = [&](const char* key) -> std::string {
            cJSON* item = cJSON_GetObjectItemCaseSensitive(obj, key);
            return cJSON_IsString(item) ? item->valuestring : "";
        };
        stations_[i].name = get("name");
        if (stations_[i].name.empty()) {
            stations_[i].name = settings.GetString("n" + std::to_string(i), "");
        }
        stations_[i].url = get("url");
        stations_[i].type = get("type");
        if (stations_[i].type.empty()) {
            stations_[i].type = "mp3";
        }
        cJSON_Delete(obj);
    }

    // Migrate only the old built-in defaults saved by earlier firmware.
    // User-customized stations are left untouched.
    struct Migration { int slot; const char* old_name; const char* old_url; const char* new_name; const char* new_url; };
    static const Migration migrations[] = {
        {0, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3"},
        {1, "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {1, "Рок Классик", "https://strm112.1.fm/rockclassics_mobile_mp3", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {1, "Рок Классик", "https://strm112.1.fm/crock_mobile_mp3", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {1, "STAR FM Classic", "https://stream.starfm.de/classic/mp3-128/stream.starfm.de/", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {2, "Радио Рекорд", "http://online.radiorecord.ru:8102/sd90_128", "Кассета Диско", "https://casseta-disco.ru:1090/stream"},
        {6, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3"},
        {7, "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128"},
    };
    for (const auto& m : migrations) {
        if (stations_[m.slot].name == m.old_name && stations_[m.slot].url == m.old_url) {
            Station station;
            station.name = m.new_name;
            station.url = m.new_url;
            station.type = "mp3";
            SaveStation(m.slot, station);
        }
    }
}

void ZhengchenWebRadio::SaveStation(int slot, const Station& station) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    cJSON* obj = cJSON_CreateObject();
    cJSON_AddStringToObject(obj, "name", station.name.c_str());
    cJSON_AddStringToObject(obj, "url", station.url.c_str());
    cJSON_AddStringToObject(obj, "type", station.type.c_str());
    char* text = cJSON_PrintUnformatted(obj);
    Settings settings("radio", true);
    settings.SetString("r" + std::to_string(slot), text ? text : "");
    settings.SetString("n" + std::to_string(slot), station.name);
    if (text) {
        cJSON_free(text);
    }
    cJSON_Delete(obj);
    stations_[slot] = station;
}

void ZhengchenWebRadio::ClearStation(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    Settings settings("radio", true);
    settings.EraseKey("r" + std::to_string(slot));
    settings.EraseKey("n" + std::to_string(slot));
    stations_[slot] = Station{};
}

void ZhengchenWebRadio::Start() {
    if (server_) {
        return;
    }

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 12;
    config.stack_size = 8192;

    if (httpd_start(&server_, &config) != ESP_OK) {
        server_ = nullptr;
        ESP_LOGE(TAG, "Failed to start HTTP server");
        return;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = RootHandler, .user_ctx = this};
    httpd_uri_t get = {.uri = "/api/radios", .method = HTTP_GET, .handler = StationsGetHandler, .user_ctx = this};
    httpd_uri_t post = {.uri = "/api/radios", .method = HTTP_POST, .handler = StationsPostHandler, .user_ctx = this};
    httpd_uri_t play = {.uri = "/api/play", .method = HTTP_GET, .handler = PlayHandler, .user_ctx = this};
    httpd_uri_t stop = {.uri = "/api/stop", .method = HTTP_GET, .handler = StopHandler, .user_ctx = this};
    httpd_uri_t cfgget = {.uri = "/api/config", .method = HTTP_GET, .handler = ConfigGetHandler, .user_ctx = this};
    httpd_uri_t cfgpost = {.uri = "/api/config", .method = HTTP_POST, .handler = ConfigPostHandler, .user_ctx = this};

    httpd_register_uri_handler(server_, &root);
    httpd_register_uri_handler(server_, &get);
    httpd_register_uri_handler(server_, &post);
    httpd_register_uri_handler(server_, &play);
    httpd_register_uri_handler(server_, &stop);
    httpd_register_uri_handler(server_, &cfgget);
    httpd_register_uri_handler(server_, &cfgpost);

    ESP_LOGI(TAG, "Local radio server started");
}

bool ZhengchenWebRadio::PlaySelected() {
    int slot = current_slot_;
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        slot = -1;
        for (int i = 0; i < MAX_STATIONS; ++i) {
            if (!stations_[i].url.empty()) {
                slot = i;
                break;
            }
        }
    }
    if (slot < 0) {
        return false;
    }
    StartRadio(slot);
    return true;
}

bool ZhengchenWebRadio::PlayStation(int station_number) {
    const int slot = station_number - 1;
    if (station_number < 1 || station_number > MAX_STATIONS ||
        stations_[slot].url.empty()) {
        ESP_LOGW(TAG, "Station number %d is not configured", station_number);
        return false;
    }
    StartRadio(slot);
    return true;
}

bool ZhengchenWebRadio::PlayStationByName(const std::string& spoken_name) {
    const std::string query = NormalizeStationName(spoken_name);
    if (query.empty()) return false;

    int best_slot = -1;
    int best_score = -1;
    for (int i = 0; i < MAX_STATIONS; ++i) {
        if (stations_[i].url.empty() || stations_[i].name.empty()) continue;
        const std::string name = NormalizeStationName(stations_[i].name);
        if (name.empty()) continue;

        int score = -1;
        if (query == name) score = 10000 + static_cast<int>(name.size());
        else if (query.find(name) != std::string::npos) score = 5000 + static_cast<int>(name.size());
        else if (name.find(query) != std::string::npos && query.size() >= 4)
            score = 3000 + static_cast<int>(query.size());
        else {
            // Conservative token-overlap fallback for minor recognition errors.
            // It is used only if at least two three-character fragments match.
            if (name.size() >= 5 && query.size() >= 5) {
                size_t common = 0;
                for (size_t p = 0; p + 2 < name.size(); ++p) {
                    if (query.find(name.substr(p, 3)) != std::string::npos) common += 3;
                }
                if (common >= 6) score = static_cast<int>(common);
            }
        }
        if (score > best_score) { best_score = score; best_slot = i; }
    }

    // Require a reasonably strong match; ambiguous or partial requests must not switch randomly.
    if (best_slot < 0 || best_score < 6) {
        ESP_LOGW(TAG, "No configured station matches spoken name: %s", spoken_name.c_str());
        return false;
    }
    ESP_LOGI(TAG, "Voice station match '%s' -> slot %d '%s'", spoken_name.c_str(),
             best_slot + 1, stations_[best_slot].name.c_str());
    StartRadio(best_slot);
    return true;
}

bool ZhengchenWebRadio::NextStation() {
    int start = current_slot_;
    if (start < 0 || start >= MAX_STATIONS) {
        start = -1;
    }
    for (int n = 1; n <= MAX_STATIONS; ++n) {
        int slot = (start + n) % MAX_STATIONS;
        if (!stations_[slot].url.empty()) {
            StartRadio(slot);
            return true;
        }
    }
    return false;
}

bool ZhengchenWebRadio::StopPlayback() {
    StopRadio();
    return true;
}

void ZhengchenWebRadio::Stop() {
    StopRadio();
    if (music_player_) music_player_->StopStreaming();
    if (music_ui_visible_) ShowMusicUi(false);
    if (server_) {
        httpd_stop(server_);
        server_ = nullptr;
    }
}

esp_err_t ZhengchenWebRadio::RootHandler(httpd_req_t* req) {
    return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandleRoot(req);
}
esp_err_t ZhengchenWebRadio::StationsGetHandler(httpd_req_t* req) {
    return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandleStationsGet(req);
}
esp_err_t ZhengchenWebRadio::StationsPostHandler(httpd_req_t* req) {
    return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandleStationsPost(req);
}
esp_err_t ZhengchenWebRadio::PlayHandler(httpd_req_t* req) {
    return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandlePlay(req);
}
esp_err_t ZhengchenWebRadio::StopHandler(httpd_req_t* req) {
    return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandleStop(req);
}

esp_err_t ZhengchenWebRadio::ConfigGetHandler(httpd_req_t* req) { return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandleConfigGet(req); }
esp_err_t ZhengchenWebRadio::ConfigPostHandler(httpd_req_t* req) { return static_cast<ZhengchenWebRadio*>(req->user_ctx)->HandleConfigPost(req); }

esp_err_t ZhengchenWebRadio::HandleConfigGet(httpd_req_t* req) {
    Settings st("radio", false);
    cJSON* o = cJSON_CreateObject();
    if (!o) { httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory"); return ESP_OK; }
    cJSON_AddNumberToObject(o, "listen_seconds", atoi(st.GetString("listen_seconds", "15").c_str()));
    cJSON_AddNumberToObject(o, "idle_seconds", atoi(st.GetString("idle_seconds", "15").c_str()));
    cJSON_AddStringToObject(o, "rss1", st.GetString("rss1", "").c_str());
    cJSON_AddStringToObject(o, "rss2", st.GetString("rss2", "").c_str());
    cJSON_AddStringToObject(o, "rss3", st.GetString("rss3", "").c_str());
    cJSON_AddStringToObject(o, "drone_url", st.GetString("drone_url", "").c_str());
    cJSON_AddNumberToObject(o, "radio_base_gain_pct", atoi(st.GetString("base_gain_pct", "200").c_str()));
    cJSON_AddNumberToObject(o, "radio_volume", atoi(st.GetString("volume", "40").c_str()));
    auto codec = Board::GetInstance().GetAudioCodec();
    cJSON_AddNumberToObject(o, "assistant_volume", codec ? codec->output_volume() : 70);
    char* out = cJSON_PrintUnformatted(o); cJSON_Delete(o);
    httpd_resp_set_type(req, "application/json");
    esp_err_t e = httpd_resp_send(req, out ? out : "{}", HTTPD_RESP_USE_STRLEN);
    if (out) cJSON_free(out);
    return e;
}

esp_err_t ZhengchenWebRadio::HandleConfigPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) { httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body"); return ESP_OK; }
    cJSON* o = cJSON_Parse(body.c_str());
    if (!o) { httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON"); return ESP_OK; }
    cJSON* listen_sec = cJSON_GetObjectItem(o, "listen_seconds");
    int listen_n = cJSON_IsNumber(listen_sec) ? listen_sec->valueint : 15;
    if (listen_n < 1) listen_n = 1;
    if (listen_n > 3600) listen_n = 3600;
    cJSON* sec = cJSON_GetObjectItem(o, "idle_seconds");
    int n = cJSON_IsNumber(sec) ? sec->valueint : 15;
    if (n < 1) n = 1;
    if (n > 3600) n = 3600;
    Settings st("radio", true); st.SetString("listen_seconds", std::to_string(listen_n)); st.SetString("idle_seconds", std::to_string(n));
    cJSON* bg = cJSON_GetObjectItem(o, "radio_base_gain_pct"); int bgp = cJSON_IsNumber(bg) ? bg->valueint : 200; if (bgp < 100) bgp = 100; if (bgp > 400) bgp = 400; st.SetString("base_gain_pct", std::to_string(bgp));
    cJSON* rv = cJSON_GetObjectItem(o, "radio_volume"); if (cJSON_IsNumber(rv)) { int v=rv->valueint; if(v<0)v=0; if(v>100)v=100; st.SetString("volume", std::to_string(v)); radio_.SetVolume(v); }
    cJSON* av = cJSON_GetObjectItem(o, "assistant_volume"); if (cJSON_IsNumber(av)) { int v=av->valueint; if(v<0)v=0; if(v>100)v=100; auto codec=Board::GetInstance().GetAudioCodec(); if(codec) codec->SetOutputVolume(v); }
    const char* keys[] = {"rss1", "rss2", "rss3", "drone_url"};
    for (const char* k : keys) {
        cJSON* v = cJSON_GetObjectItem(o, k);
        if (cJSON_IsString(v) && v->valuestring && strlen(v->valuestring) <= 400) st.SetString(k, v->valuestring);
    }
    cJSON_Delete(o); httpd_resp_sendstr(req, "OK"); return ESP_OK;
}

esp_err_t ZhengchenWebRadio::HandleRoot(httpd_req_t* req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, kHtml, HTTPD_RESP_USE_STRLEN);
}

esp_err_t ZhengchenWebRadio::HandleStationsGet(httpd_req_t* req) {
    cJSON* array = cJSON_CreateArray();
    for (int i = 0; i < MAX_STATIONS; ++i) {
        cJSON* obj = cJSON_CreateObject();
        cJSON_AddNumberToObject(obj, "slot", i);
        cJSON_AddStringToObject(obj, "name", stations_[i].name.c_str());
        cJSON_AddStringToObject(obj, "url", stations_[i].url.c_str());
        cJSON_AddStringToObject(obj, "type", stations_[i].type.c_str());
        cJSON_AddBoolToObject(obj, "playing", current_slot_ == i && radio_.IsPlaying());
        cJSON_AddItemToArray(array, obj);
    }
    char* text = cJSON_PrintUnformatted(array);
    cJSON_Delete(array);
    httpd_resp_set_type(req, "application/json");
    esp_err_t ret = httpd_resp_send(req, text ? text : "[]", HTTPD_RESP_USE_STRLEN);
    if (text) {
        cJSON_free(text);
    }
    return ret;
}

esp_err_t ZhengchenWebRadio::HandleStationsPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body");
        return ESP_OK;
    }
    cJSON* obj = cJSON_Parse(body.c_str());
    if (!obj) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
        return ESP_OK;
    }

    cJSON* slot_item = cJSON_GetObjectItem(obj, "slot");
    int slot = cJSON_IsNumber(slot_item) ? slot_item->valueint : -1;
    cJSON* del = cJSON_GetObjectItem(obj, "delete");
    if (cJSON_IsTrue(del)) {
        StopRadio();
        ClearStation(slot);
    } else {
        cJSON* name = cJSON_GetObjectItem(obj, "name");
        cJSON* url = cJSON_GetObjectItem(obj, "url");
        cJSON* type = cJSON_GetObjectItem(obj, "type");
        if (slot < 0 || slot >= MAX_STATIONS || !cJSON_IsString(url)) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid station");
            return ESP_OK;
        }
        Station station;
        station.name = cJSON_IsString(name) ? name->valuestring : "";
        station.url = url->valuestring;
        station.type = cJSON_IsString(type) ? type->valuestring : "mp3";
        if (station.url.size() > 400 || station.name.size() > 80) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Too long");
            return ESP_OK;
        }
        if (station.type != "mp3" && station.type != "aac" &&
            station.type != "ogg" && station.type != "wav") {
            station.type = "mp3";
        }
        SaveStation(slot, station);
    }
    cJSON_Delete(obj);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t ZhengchenWebRadio::HandlePlay(httpd_req_t* req) {
    char query[64];
    char value[16];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "slot", value, sizeof(value)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "slot required");
        return ESP_OK;
    }
    int slot = atoi(value);
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Station not found");
        return ESP_OK;
    }
    StartRadio(slot);
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t ZhengchenWebRadio::HandleStop(httpd_req_t* req) {
    StopRadio();
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

void ZhengchenWebRadio::SetPageIndicator(int page) {
    if (page < 0) page = 0;
    if (page > 2) page = 2;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;
    if (!page_indicator_root_) {
        page_indicator_root_ = lv_obj_create(lv_screen_active());
        lv_obj_set_size(page_indicator_root_, 78, 16);
        lv_obj_set_pos(page_indicator_root_, 141, 338);
        lv_obj_set_style_bg_opa(page_indicator_root_, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_set_style_radius(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_clear_flag(page_indicator_root_, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_clear_flag(page_indicator_root_, LV_OBJ_FLAG_CLICKABLE);
        // Three solid white dots: left=map, center=assistant, right=radio.
        const int centers[3] = {12, 39, 66};
        for (int i = 0; i < 3; ++i) {
            lv_obj_t* dot = lv_obj_create(page_indicator_root_);
            lv_obj_set_size(dot, 6, 6);
            lv_obj_set_pos(dot, centers[i] - 3, 5);
            lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
            lv_obj_set_style_bg_color(dot, lv_color_white(), LV_PART_MAIN);
            lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_width(dot, 0, LV_PART_MAIN);
            lv_obj_set_style_pad_all(dot, 0, LV_PART_MAIN);
            lv_obj_clear_flag(dot, LV_OBJ_FLAG_CLICKABLE);
            lv_obj_clear_flag(dot, LV_OBJ_FLAG_SCROLLABLE);
        }
        // Active page is a short, thick white dash (the Android-style page pill).
        page_indicator_active_ = lv_obj_create(page_indicator_root_);
        lv_obj_set_size(page_indicator_active_, 20, 6);
        lv_obj_set_pos(page_indicator_active_, 2, 5);
        lv_obj_set_style_radius(page_indicator_active_, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(page_indicator_active_, lv_color_white(), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(page_indicator_active_, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_width(page_indicator_active_, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(page_indicator_active_, 0, LV_PART_MAIN);
        lv_obj_clear_flag(page_indicator_active_, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(page_indicator_active_, LV_OBJ_FLAG_SCROLLABLE);
    }
    // Animate only the tiny indicator. Full-screen sliding would force the map and
    // assistant to redraw large areas during radio/network work and can cause stutter.
    lv_anim_delete(page_indicator_active_, nullptr);
    lv_anim_t anim;
    lv_anim_init(&anim);
    lv_anim_set_var(&anim, page_indicator_active_);
    lv_anim_set_values(&anim, lv_obj_get_x(page_indicator_active_), 2 + page * 27);
    lv_anim_set_time(&anim, 140);
    lv_anim_set_path_cb(&anim, lv_anim_path_ease_out);
    lv_anim_set_exec_cb(&anim, [](void* obj, int32_t x) { lv_obj_set_x(static_cast<lv_obj_t*>(obj), x); });
    lv_anim_start(&anim);
    lv_obj_move_foreground(page_indicator_root_);
}


void ZhengchenWebRadio::EnsureRadioUi() {
    if (radio_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    // Use the actual radio-face artwork from the approved composite reference.
    // The map artwork is not touched. Transparent hit zones are placed over the
    // three pictured buttons; only the station title is dynamically overlaid.
    radio_ui_root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(radio_ui_root_, 240, 240);
    lv_obj_set_pos(radio_ui_root_, 0, 0);
    lv_obj_set_style_radius(radio_ui_root_, 8, LV_PART_MAIN);
    lv_obj_set_style_border_width(radio_ui_root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(radio_ui_root_, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(radio_ui_root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_pad_all(radio_ui_root_, 0, LV_PART_MAIN);
    lv_obj_clear_flag(radio_ui_root_, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t* face = lv_image_create(radio_ui_root_);
    lv_image_set_src(face, &kRadioFaceImage);
    // Source artwork is 240x240 RGB565; upscale once to fit the round 360px display.
    lv_obj_set_pos(face, 0, 0);
    lv_image_set_scale(face, 256); // Native 240x240 artwork on the square Zhengchen display
    lv_obj_clear_flag(face, LV_OBJ_FLAG_CLICKABLE);

    // Live volume percentage sits immediately above the station name.
    radio_volume_label_ = lv_label_create(radio_ui_root_);
    lv_label_set_text(radio_volume_label_, "40%");
    lv_obj_set_size(radio_volume_label_, 67, 12);
    lv_obj_set_pos(radio_volume_label_, 87, 102);
    lv_obj_set_style_text_color(radio_volume_label_, lv_color_make(255, 196, 90), LV_PART_MAIN);
    lv_obj_set_style_text_font(radio_volume_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_set_style_text_align(radio_volume_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(radio_volume_label_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_clear_flag(radio_volume_label_, LV_OBJ_FLAG_CLICKABLE);

    // Cover the station name printed in the reference image so the live station
    // name can be shown without changing the surrounding vintage panel artwork.
    // Narrow the panel slightly to make room for the +/- volume controls.
    lv_obj_t* title_panel = lv_obj_create(radio_ui_root_);
    lv_obj_set_size(title_panel, 136, 28);
    lv_obj_set_pos(title_panel, 52, 117);
    lv_obj_set_style_radius(title_panel, 3, LV_PART_MAIN);
    lv_obj_set_style_border_width(title_panel, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(title_panel, lv_color_make(20, 13, 7), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(title_panel, LV_OPA_90, LV_PART_MAIN);
    lv_obj_set_style_pad_all(title_panel, 0, LV_PART_MAIN);
    lv_obj_clear_flag(title_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(title_panel, LV_OBJ_FLAG_CLICKABLE);

    radio_station_label_ = lv_label_create(title_panel);
    lv_label_set_text(radio_station_label_, "Интернет-радио");
    lv_label_set_long_mode(radio_station_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(radio_station_label_, 200);
    lv_obj_set_height(radio_station_label_, 36);
    lv_obj_set_style_bg_opa(radio_station_label_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_text_align(radio_station_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(radio_station_label_, lv_color_make(255, 184, 66), LV_PART_MAIN);
    lv_obj_set_style_text_font(radio_station_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(radio_station_label_, LV_ALIGN_CENTER, 0, 0);
    lv_obj_move_foreground(title_panel);

    // Transparent touch targets match the three physical-looking station controls.
    const int ys[3] = {155, 155, 155};
    for (int i = 0; i < 3; ++i) {
        lv_obj_t* btn = lv_btn_create(radio_ui_root_);
        radio_buttons_[i] = btn;
        lv_obj_set_size(btn, 53, 56);
        const int wide_x[3] = {40, 93, 147};
        lv_obj_set_pos(btn, wide_x[i], ys[i] - 9);
        lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(255, 170, 55), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(btn, 0, LV_PART_MAIN);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(i + 1)));
        lv_obj_add_flag(btn, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(btn, RadioUiEvent, LV_EVENT_CLICKED, this);
    }

    // Visible +/- controls, matching the radio's dark enamel and warm amber trim.
    // Minus is on the left, plus on the right. Each tap changes 5%.
    const int volume_x[2] = {21, 183};
    const char* volume_text[2] = {"-", "+"};
    for (int i = 0; i < 2; ++i) {
        const int action = i == 0 ? 4 : 5;
        lv_obj_t* btn = lv_btn_create(radio_ui_root_);
        radio_buttons_[action - 1] = btn;
        lv_obj_set_size(btn, 36, 31);
        lv_obj_set_pos(btn, volume_x[i], 174);
        lv_obj_set_style_radius(btn, 7, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(35, 22, 12), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_color(btn, lv_color_make(205, 139, 48), LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 2, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(btn, 0, LV_PART_MAIN);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(action)));
        lv_obj_add_event_cb(btn, RadioUiEvent, LV_EVENT_CLICKED, this);
        lv_obj_t* label = lv_label_create(btn);
        lv_label_set_text(label, volume_text[i]);
        lv_obj_set_style_text_color(label, lv_color_make(255, 190, 76), LV_PART_MAIN);
        lv_obj_set_style_text_font(label, &lv_font_montserrat_14, LV_PART_MAIN);
        lv_obj_center(label);
    }
    lv_obj_add_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
}

void ZhengchenWebRadio::RadioButtonFlashTimerCallback(lv_timer_t* timer) {
    auto* self = static_cast<ZhengchenWebRadio*>(lv_timer_get_user_data(timer));
    if (!self) return;
    for (int i = 0; i < 5; ++i) {
        auto* btn = self->radio_buttons_[i];
        if (!btn) continue;
        if (i >= 3) {
            lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_color(btn, lv_color_make(205, 139, 48), LV_PART_MAIN);
            lv_obj_set_style_border_width(btn, 2, LV_PART_MAIN);
        } else {
            lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, LV_PART_MAIN);
            lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
        }
    }
    // repeat_count=1 makes LVGL retire this one-shot timer after the callback.
    self->radio_button_flash_timer_ = nullptr;
}

void ZhengchenWebRadio::FlashRadioButton(int action) {
    if (action < 1 || action > 5 || !radio_buttons_[action - 1]) return;
    auto* btn = radio_buttons_[action - 1];
    if (radio_button_flash_timer_) {
        // Reuse the existing one-shot timer instead of deleting/recreating it
        // on rapid taps (avoids timer churn while LVGL is servicing input).
        lv_timer_reset(radio_button_flash_timer_);
        lv_timer_resume(radio_button_flash_timer_);
    }
    for (int i = 0; i < 5; ++i) {
        auto* item = radio_buttons_[i];
        if (!item) continue;
        if (i >= 3) {
            lv_obj_set_style_bg_opa(item, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_color(item, lv_color_make(205, 139, 48), LV_PART_MAIN);
            lv_obj_set_style_border_width(item, 2, LV_PART_MAIN);
        } else {
            lv_obj_set_style_bg_opa(item, LV_OPA_TRANSP, LV_PART_MAIN);
            lv_obj_set_style_border_width(item, 0, LV_PART_MAIN);
        }
    }
    lv_obj_set_style_bg_opa(btn, LV_OPA_70, LV_PART_MAIN);
    lv_obj_set_style_border_color(btn, lv_color_make(255, 204, 90), LV_PART_MAIN);
    lv_obj_set_style_border_width(btn, 4, LV_PART_MAIN);
    if (!radio_button_flash_timer_) {
        radio_button_flash_timer_ = lv_timer_create(RadioButtonFlashTimerCallback, 150, this);
        lv_timer_set_repeat_count(radio_button_flash_timer_, 1);
    }
}

void ZhengchenWebRadio::ShowRadioUi(bool show) {
    if (show && music_ui_visible_) ShowMusicUi(false);
    EnsureRadioUi();
    if (!radio_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    {
        DisplayLockGuard lock(display);
        if (!lock) return;
        if (show) {
            UpdateRadioStationLabel();
            lv_obj_clear_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_move_foreground(radio_ui_root_);
            radio_ui_visible_ = true;
        } else {
            radio_ui_visible_ = false;
            lv_obj_add_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
        }
    }
    // Do this after releasing the GUI lock: the display method takes its own lock.
    display->SetRadioLowMotionMode(show);
}

void ZhengchenWebRadio::UpdateRadioStationLabel() {
    if (radio_volume_label_) {
        char volume_text[8];
        snprintf(volume_text, sizeof(volume_text), "%d%%", radio_.GetVolume());
        lv_label_set_text(radio_volume_label_, volume_text);
        lv_obj_clear_flag(radio_volume_label_, LV_OBJ_FLAG_HIDDEN);
    }
    if (!radio_station_label_) return;
    static const char* display_names[MAX_STATIONS] = {
        "Europa Plus", "Rock Classic", "Casseta Disco", "Rock Ataka",
        "Maximus Rock", "Rock Arsenal", "Nashe Rock", "Melodia"
    };
    const char* name = (current_slot_ >= 0 && current_slot_ < MAX_STATIONS)
        ? display_names[current_slot_] : "Internet Radio";
    lv_label_set_text(radio_station_label_, name);
    lv_obj_clear_flag(radio_station_label_, LV_OBJ_FLAG_HIDDEN);
}

void ZhengchenWebRadio::RadioUiEvent(lv_event_t* event) {
    auto* self = static_cast<ZhengchenWebRadio*>(lv_event_get_user_data(event));
    // LVGL 9 provides a typed widget-target accessor. Use it instead of
    // lv_event_get_target(), whose return type is void* in this LVGL build.
    lv_obj_t* target_obj = lv_event_get_target_obj(event);
    if (!self || target_obj == nullptr) return;
    intptr_t action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(target_obj));
    // Some LVGL input paths can report a child label as the target.
    if (action < 1 || action > 5) {
        lv_obj_t* parent = lv_obj_get_parent(target_obj);
        if (parent) action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(parent));
    }
    if (action < 1 || action > 5) {
        return;
    }
    ESP_LOGI(TAG, "Radio touch action=%ld", static_cast<long>(action));
    self->FlashRadioButton(static_cast<int>(action));
    // The board also has a manual CST816S tap path. Share the debounce window
    // so one physical tap cannot be processed once by LVGL and once manually.
    const int64_t now_us = esp_timer_get_time();
    if (now_us - self->last_radio_action_us_ < 450000) return;
    self->last_radio_action_us_ = now_us;
    if (action == 4 || action == 5) {
        const int delta = action == 4 ? -5 : 5;
        self->radio_.SetVolume(self->radio_.GetVolume() + delta);
        self->UpdateRadioStationLabel();
    } else if (action == 1) {
        int start = self->current_slot_;
        for (int n = 1; n <= MAX_STATIONS; ++n) {
            int slot = (start - n + MAX_STATIONS * 2) % MAX_STATIONS;
            if (!self->stations_[slot].url.empty()) { self->StartRadio(slot); break; }
        }
    } else if (action == 2) {
        self->StopRadio();
        Application::GetInstance().ToggleChatState();
    } else if (action == 3) self->NextStation();
}

void ZhengchenWebRadio::HandleTouchDown(int x, int y) {
    if (music_ui_visible_) {
        const int sx = 359 - x, sy = 359 - y;
        int action = 0;
        if (sy >= 4 && sy <= 72 && sx >= 45 && sx <= 315) action = 6;
        else if (sy >= 225 && sy <= 288) action = (sx >= 20 && sx < 120) ? 1 : ((sx >= 120 && sx < 240) ? 2 : ((sx >= 240 && sx <= 340) ? 3 : 0));
        else if (sy >= 291 && sy <= 344) action = (sx >= 75 && sx < 180) ? 4 : ((sx >= 185 && sx <= 285) ? 5 : 0);
        if (action) {
            auto display = Board::GetInstance().GetDisplay();
            if (display) { DisplayLockGuard lock(display); if (lock) {
                if (action == 6 && music_return_button_) lv_obj_set_style_border_width(music_return_button_, 2, LV_PART_MAIN);
                else if (action >= 1 && action <= 5 && music_buttons_[action - 1]) lv_obj_set_style_border_width(music_buttons_[action - 1], 4, LV_PART_MAIN);
            } }
        }
        return;
    }
    if (!radio_ui_visible_) return;
    const int sx = 359 - x;
    const int sy = 359 - y;
    int action = 0;
    if (sy >= 164 && sy <= 226) {
        if (sx >= 24 && sx <= 92) action = 4;        // volume +
        else if (sx >= 268 && sx <= 338) action = 5; // volume -
    } else if (sy >= 214 && sy <= 326) {
        action = (sx >= 15 && sx < 125) ? 1 :
                 ((sx >= 115 && sx < 225) ? 2 :
                 ((sx >= 215 && sx <= 340) ? 3 : 0));
    }
    if (!action) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    DisplayLockGuard lock(display);
    if (lock) {
            FlashRadioButton(action);
    }
}

bool ZhengchenWebRadio::HandleTouchTap(int x, int y) {
    if (music_ui_visible_) {
        const int sx = 359 - x, sy = 359 - y;
        int action = 0;
        if (sy >= 4 && sy <= 72 && sx >= 45 && sx <= 315) action = 6;
        else if (sy >= 225 && sy <= 288) action = (sx >= 20 && sx < 120) ? 1 : ((sx >= 120 && sx < 240) ? 2 : ((sx >= 240 && sx <= 340) ? 3 : 0));
        else if (sy >= 291 && sy <= 344) action = (sx >= 75 && sx < 180) ? 4 : ((sx >= 185 && sx <= 285) ? 5 : 0);
        if (action) {
            // The board's manual CST816S handler and LVGL can observe the same
            // physical tap. Use one debounce timestamp so a single tap cannot
            // stop music and immediately retrigger another UI action.
            const int64_t now_us = esp_timer_get_time();
            if (now_us - last_music_action_us_ < 450000) return true;
            last_music_action_us_ = now_us;
            if (action == 6) {
                ESP_LOGI(TAG, "Touch return to assistant: stopping music");
                if (music_player_) music_player_->StopStreaming();
                auto& audio = Application::GetInstance().GetAudioService();
                audio.ResetDecoder();
                for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                CancelSilentStandbyTimer();
                SetAssistantDuck(false);
                ShowMusicUi(false);
                Application::GetInstance().ExitRadioSilentIdle();
                Application::GetInstance().ToggleChatState();
                Application::GetInstance().ResetIdleDisplayTimer();
                UpdateWifiPowerSave();
            } else if (action == 1) MoveMusicHistory(-1);
            else if (action == 3) MoveMusicHistory(1);
            else if (action == 2) {
                if (music_player_ && music_player_->IsPlaying()) {
                    music_player_->StopStreaming();
                    auto& audio = Application::GetInstance().GetAudioService();
                    audio.ResetDecoder();
                    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                } else if (music_history_index_ >= 0 && music_history_index_ < (int)music_history_.size()) { auto item = music_history_[music_history_index_]; PlayMusicSearch(item.first, item.second, false); }
                UpdateMusicUi();
            } else {
                auto codec = Board::GetInstance().GetAudioCodec();
                if (codec) codec->SetOutputVolume(std::max(0, std::min(100, codec->output_volume() + (action == 4 ? -5 : 5))));
                UpdateMusicUi();
            }
        }
        return true;
    }
    // UI visibility, not decoder state, is authoritative: the stream can be
    // temporarily buffering while the radio screen remains on display.
    if (!radio_ui_visible_) return false;

    // The LCD is mirrored in both axes in config.h, while CST816S reports
    // native sensor coordinates. Convert to the visible 360x360 coordinate space.
    const int sx = 359 - x;
    const int sy = 359 - y;
    // The station-name area remains display-only, except for the two volume keys.
    // Assistant activation is disabled while radio owns the audio path.
    int action = 0;
    if (sy >= 174 && sy <= 220) {
        if (sx >= 36 && sx <= 78) action = 4;        // left: volume -
        else if (sx >= 282 && sx <= 324) action = 5; // right: volume +
        else return true;
    } else if (sy < 220) {
        return true;
    } else if (sy > 320) {
        return true; // ignore the bottom margin of the radio page
    } else if (sx >= 25 && sx < 115) action = 1;       // left: previous
    else if (sx >= 115 && sx < 210) action = 2;        // center: power / return
    else if (sx >= 210 && sx <= 330) action = 3;       // right: next
    if (!action) return true; // outside the three buttons: ignore safely
    auto display = Board::GetInstance().GetDisplay();
    if (display) {
        DisplayLockGuard lock(display);
        if (lock) FlashRadioButton(action);
    }
    // Always show the press, but do not start/stop/reconnect the audio pipeline
    // repeatedly when the user taps several times in quick succession.
    const int64_t now_us = esp_timer_get_time();
    if (now_us - last_radio_action_us_ < 450000) return true;
    last_radio_action_us_ = now_us;
    if (action == 4 || action == 5) {
        const int delta = action == 4 ? -5 : 5;
        radio_.SetVolume(radio_.GetVolume() + delta);
        auto display = Board::GetInstance().GetDisplay();
        if (display) {
            DisplayLockGuard lock(display);
            if (lock) UpdateRadioStationLabel();
        }
        return true;
    }
    if (action == 1) {
        int start = current_slot_;
        for (int n = 1; n <= MAX_STATIONS; ++n) {
            int slot = (start - n + MAX_STATIONS * 2) % MAX_STATIONS;
            if (!stations_[slot].url.empty()) { StartRadio(slot); return true; }
        }
        return true;
    }
    if (action == 2) {
        StopRadio();
        // The radio leaves the assistant in silent idle. Re-enter its normal
        // listening/assistant UI immediately after the user presses power.
        Application::GetInstance().ToggleChatState();
        return true;
    }
    NextStation();
    return true;
}

void ZhengchenWebRadio::StartRadio(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) return;
    // Never stop/join network and audio threads from LVGL touch callbacks or MCP
    // callbacks. Keep only the latest requested station while a switch is in progress.
    pending_station_slot_.store(slot);
    bool expected = false;
    if (station_switch_task_running_.compare_exchange_strong(expected, true)) {
        if (xTaskCreate(&ZhengchenWebRadio::StationSwitchTask, "radio_switch", 4096, this, 5, nullptr) != pdPASS) {
            station_switch_task_running_.store(false);
            ESP_LOGE(TAG, "Could not create station-switch task; switching synchronously as fallback");
            const int requested = pending_station_slot_.exchange(-1);
            if (requested >= 0) StartRadioNow(requested);
        }
    }
}

void ZhengchenWebRadio::StationSwitchTask(void* arg) {
    auto* self = static_cast<ZhengchenWebRadio*>(arg);
    if (!self) { vTaskDelete(nullptr); return; }
    for (;;) {
        const int slot = self->pending_station_slot_.exchange(-1);
        if (slot >= 0) {
            self->StartRadioNow(slot);
            continue;
        }
        self->station_switch_task_running_.store(false);
        // Close the race where a new request arrives just as the worker exits.
        if (self->pending_station_slot_.load() >= 0) {
            bool expected = false;
            if (self->station_switch_task_running_.compare_exchange_strong(expected, true)) continue;
        }
        break;
    }
    vTaskDelete(nullptr);
}

void ZhengchenWebRadio::StartRadioNow(int slot) {
    // Stop/join the previous stream in the dedicated switch worker, never in
    // the physical-button/LVGL callback. While Stop() waits for network/audio
    // workers, new button presses only replace pending_station_slot_.
    if (music_player_ && (music_player_->IsPlaying() || music_player_->IsDownloading()))
        music_player_->StopStreaming();
    if (music_ui_visible_) ShowMusicUi(false);

    if (radio_.IsPlaying() || radio_.IsDownloading()) {
        ESP_LOGI(TAG, "Stopping old radio stream before applying latest station selection");
        radio_.Stop();
    }

    // A newer button press may have arrived while the old HTTP stream was
    // shutting down. Discard the stale request and start only the latest one.
    const int latest = pending_station_slot_.exchange(-1);
    if (latest >= 0) slot = latest;
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        ESP_LOGW(TAG, "Station switch cancelled: no valid selected station");
        return;
    }

    if (!radio_.PlayUrl(stations_[slot].url, stations_[slot].name)) {
        ESP_LOGE(TAG, "Failed to start station %d: %s", slot + 1, stations_[slot].url.c_str());
        current_slot_ = -1;
        UpdateWifiPowerSave();
        return;
    }

    current_slot_ = slot;
    ShowRadioUi(true);
    const auto app_state = Application::GetInstance().GetDeviceState();
    const bool voice_session_active = app_state == kDeviceStateListening ||
                                      app_state == kDeviceStateSpeaking ||
                                      app_state == kDeviceStateConnecting;
    CancelSilentStandbyTimer();
    if (voice_session_active) {
        SetAssistantDuck(true);
    } else {
        SetAssistantDuck(false);
        Application::GetInstance().EnterRadioSilentIdle();
    }
    UpdateWifiPowerSave();
}

void ZhengchenWebRadio::EnterSilentRadioModeNow() {
    // Touch/swipe launch should not open a voice session or stream microphone
    // audio to the assistant. Keep the normal idle/wake-word behavior, but do
    // not wait the 10-second voice-command grace period.
    CancelSilentStandbyTimer();
    Application::GetInstance().EnterRadioSilentIdle();
}

void ZhengchenWebRadio::SilentStandbyTimerCallback(void* arg) {
    auto* self = static_cast<ZhengchenWebRadio*>(arg);
    if (!self || !self->IsRadioActive()) {
        return;
    }
    ZhengchenWebRadio::SetAssistantDuck(false);
    Application::GetInstance().EnterRadioSilentIdle(false);
}

bool ZhengchenWebRadio::PlayMusicSearch(const std::string& song, const std::string& artist, bool add_history, uint32_t playlist_generation) {
    if (!music_player_ || (song.empty() && artist.empty())) return false;
    // Match Taiji: keep Wi-Fi at performance level for the entire search and playback handoff.
    music_search_active_.store(true);
    UpdateWifiPowerSave();
    StopRadio();
    music_player_->StopStreaming();
    vTaskDelay(pdMS_TO_TICKS(250));

    // Drain queued assistant PCM before the MP3 task writes directly to the codec.
    auto& app = Application::GetInstance();
    auto& audio = app.GetAudioService();
    audio.ResetDecoder();
    for (int wait_ms = 0; wait_ms < 500 && !audio.IsPlaybackIdle(); wait_ms += 10)
        vTaskDelay(pdMS_TO_TICKS(10));
    app.EnterRadioSilentIdle(false);

    if (!music_player_->Download(song, artist)) {
        music_search_active_.store(false);
        UpdateWifiPowerSave();
        UpdateMusicUi();
        return false;
    }
    // Only playlist-originated searches carry a generation. A normal single-song
    // request must never be rejected merely because playlist_active_ is false.
    if (playlist_generation != 0 &&
        (!playlist_active_.load() || playlist_generation_.load() != playlist_generation)) {
        music_player_->StopStreaming();
        music_search_active_.store(false);
        UpdateWifiPowerSave();
        return false;
    }
    if (add_history) {
        if (music_history_index_ + 1 < static_cast<int>(music_history_.size()))
            music_history_.erase(music_history_.begin() + music_history_index_ + 1, music_history_.end());
        music_history_.push_back({music_player_->GetCurrentSong(), music_player_->GetCurrentArtist()});
        music_history_index_ = static_cast<int>(music_history_.size()) - 1;
    }
    ShowRadioUi(false);
    if (!music_ui_visible_) ShowMusicUi(true);
    UpdateMusicUi();
    SetAssistantDuck(false);
    CancelSilentStandbyTimer();
    auto& board = Board::GetInstance();
    if (auto display = board.GetDisplay()) display->SetPowerSaveMode(false);
    if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    music_search_active_.store(false);
    UpdateWifiPowerSave();
    return true;
}

bool ZhengchenWebRadio::StartPlaylist(const std::string& playlist) {
    if (playlist.empty() || playlist.size() > 1200 || !music_player_ || playlist_active_.exchange(true)) return false;
    playlist_items_.clear();
    playlist_current_index_.store(-1);
    size_t pos = 0;
    while (pos < playlist.size() && playlist_items_.size() < 20) {
        size_t end = playlist.find('\n', pos);
        if (end == std::string::npos) end = playlist.size();
        std::string row = playlist.substr(pos, end - pos);
        if (!row.empty() && row.back() == '\r') row.pop_back();
        const size_t sep = row.find('|');
        if (sep != std::string::npos) {
            std::string artist = row.substr(0, sep);
            std::string song = row.substr(sep + 1);
            auto trim = [](std::string& value) {
                const size_t first = value.find_first_not_of(" \t");
                if (first == std::string::npos) { value.clear(); return; }
                const size_t last = value.find_last_not_of(" \t");
                value = value.substr(first, last - first + 1);
            };
            trim(artist); trim(song);
            if (!artist.empty() || !song.empty()) playlist_items_.emplace_back(song, artist);
        }
        pos = end + 1;
    }
    if (playlist_items_.empty()) { playlist_active_.store(false); return false; }
    const uint32_t generation = playlist_generation_.fetch_add(1) + 1;
    auto* gen = new (std::nothrow) uint32_t(generation);
    if (!gen || xTaskCreate(PlaylistTask, "music_playlist", 6144, gen, 4, nullptr) != pdPASS) {
        delete gen;
        playlist_active_.store(false);
        playlist_items_.clear();
        return false;
    }
    return true;
}

void ZhengchenWebRadio::PlaylistTask(void* arg) {
    const uint32_t generation = arg ? *static_cast<uint32_t*>(arg) : 0;
    delete static_cast<uint32_t*>(arg);
    auto* self = instance_;
    if (self) self->RunPlaylist(generation);
    vTaskDelete(nullptr);
}

void ZhengchenWebRadio::RunPlaylist(uint32_t generation) {
    const auto items = playlist_items_;
    for (size_t i = 0; i < items.size() && playlist_active_.load() && playlist_generation_.load() == generation; ++i) {
        playlist_current_index_.store(static_cast<int>(i));
        UpdateMusicUi();
        const auto& track = items[i];
        if (!PlayMusicSearch(track.first, track.second, true, generation)) {
            if (music_player_ && music_player_->HasPendingShortSong()) music_player_->StopStreaming();
            continue;
        }
        if (!playlist_active_.load() || playlist_generation_.load() != generation) {
            if (music_player_) music_player_->StopStreaming();
            break;
        }
        bool saw_playing = false;
        while (playlist_active_.load() && playlist_generation_.load() == generation) {
            const bool playing = music_player_ && music_player_->IsPlaying();
            if (playing) saw_playing = true;
            if (saw_playing && !playing && !(music_player_ && music_player_->IsDownloading())) break;
            vTaskDelay(pdMS_TO_TICKS(250));
        }
        if (!playlist_active_.load() || playlist_generation_.load() != generation) break;
        for (int wait_ms = 0; wait_ms < 2500 && playlist_active_.load() && playlist_generation_.load() == generation; wait_ms += 100)
            vTaskDelay(pdMS_TO_TICKS(100));
    }
    if (playlist_generation_.load() == generation) {
        playlist_active_.store(false);
        playlist_current_index_.store(-1);
        playlist_items_.clear();
        UpdateMusicUi();
    }
}

bool ZhengchenWebRadio::ConfirmShortSongPlayback() {
    if (!music_player_ || !music_player_->HasPendingShortSong()) return false;
    StopRadio();
    auto& app = Application::GetInstance();
    auto& audio = app.GetAudioService();
    audio.ResetDecoder();
    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
    if (!music_player_->ConfirmPendingShortSong()) return false;
    if (music_history_index_ + 1 < static_cast<int>(music_history_.size()))
        music_history_.erase(music_history_.begin() + music_history_index_ + 1, music_history_.end());
    music_history_.push_back({music_player_->GetCurrentSong(), music_player_->GetCurrentArtist()});
    music_history_index_ = static_cast<int>(music_history_.size()) - 1;
    ShowRadioUi(false);
    ShowMusicUi(true);
    UpdateMusicUi();
    SetAssistantDuck(false);
    CancelSilentStandbyTimer();
    auto& board = Board::GetInstance();
    if (auto display = board.GetDisplay()) display->SetPowerSaveMode(false);
    if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    UpdateWifiPowerSave();
    return true;
}

void ZhengchenWebRadio::MoveMusicHistory(int delta) {
    // Never perform network search/download from the physical-button callback.
    // Update the selected history row immediately and coalesce rapid presses to
    // the newest requested index; one worker serializes all music searches.
    if (music_history_.empty()) return;
    int next = music_history_index_ + delta;
    if (next < 0 || next >= static_cast<int>(music_history_.size())) return;
    music_history_index_ = next;
    pending_music_history_index_.store(next);
    UpdateMusicUi();
    bool expected = false;
    if (music_switch_worker_running_.compare_exchange_strong(expected, true)) {
        if (xTaskCreate(&ZhengchenWebRadio::MusicSwitchTask, "music_switch", 6144, this, 5, nullptr) != pdPASS) {
            music_switch_worker_running_.store(false);
            ESP_LOGW(TAG, "Could not start music switch worker");
        }
    }
}

void ZhengchenWebRadio::MusicSwitchTask(void* arg) {
    auto* self = static_cast<ZhengchenWebRadio*>(arg);
    if (!self) { vTaskDelete(nullptr); return; }
    for (;;) {
        const int index = self->pending_music_history_index_.exchange(-2);
        if (index == -2) break;
        if (index < 0 || index >= static_cast<int>(self->music_history_.size())) continue;
        const auto item = self->music_history_[index];
        self->PlayMusicSearch(item.first, item.second, false);
        // If more presses arrived while resolving the track, discard the stale
        // queued target and resolve only the latest selection on the next loop.
    }
    self->music_switch_worker_running_.store(false);
    // Close the race where a press queued work between the last exchange and
    // clearing the worker flag.
    if (self->pending_music_history_index_.load() != -2) {
        bool expected = false;
        if (self->music_switch_worker_running_.compare_exchange_strong(expected, true)) {
            if (xTaskCreate(&ZhengchenWebRadio::MusicSwitchTask, "music_switch", 6144, self, 5, nullptr) != pdPASS)
                self->music_switch_worker_running_.store(false);
        }
    }
    vTaskDelete(nullptr);
}

// Convert UTF-8 Cyrillic artist names to uppercase for the compact player header.
static std::string MusicUppercaseArtist(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (size_t i = 0; i < input.size();) {
        const unsigned char c = static_cast<unsigned char>(input[i]);
        if (i + 1 < input.size() && c == 0xD0) {
            const unsigned char d = static_cast<unsigned char>(input[i + 1]);
            if (d >= 0xB0 && d <= 0xBF) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d - 0x20)); i += 2; continue; }
            if (d == 0x91) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(0x81)); i += 2; continue; }
        } else if (i + 1 < input.size() && c == 0xD1) {
            const unsigned char d = static_cast<unsigned char>(input[i + 1]);
            if (d >= 0x80 && d <= 0x8F) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d - 0x20)); i += 2; continue; }
        }
        out.push_back(input[i++]);
    }
    return out;
}

void ZhengchenWebRadio::EnsureMusicUi() {
    if (music_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    // Keep the compact Montserrat 14 appearance for Latin text such as <<<play>>>,
    // while falling back to the board's Noto text font for Cyrillic song metadata.
    music_text_font_ = lv_font_montserrat_14;
    auto* board_theme = display->GetTheme();
    auto board_text_font = board_theme ? board_theme->GetTextFont() : nullptr;
    music_text_font_.fallback = board_text_font ? board_text_font->font() : nullptr;

    music_ui_root_ = lv_obj_create(lv_screen_active());
    // Leave the top system status strip (time / battery / Wi-Fi) unobstructed.
    // The existing board status bar occupies the top 22 pixels.
    lv_obj_set_size(music_ui_root_, 240, 218);
    lv_obj_set_pos(music_ui_root_, 0, 22);
    lv_obj_set_style_radius(music_ui_root_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(music_ui_root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(music_ui_root_, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(music_ui_root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_pad_all(music_ui_root_, 0, LV_PART_MAIN);
    lv_obj_clear_flag(music_ui_root_, LV_OBJ_FLAG_SCROLLABLE);

    // Keep the screen intentionally plain: black background, cyan metadata,
    // white current track, and a compact playlist below it. This board's build
    // only enables Montserrat 14, so avoid the unavailable font-16 symbol.
    // No in-player "Помощник" button: return to assistant with the physical BOOT key.

    music_artist_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_artist_label_, "Исполнитель");
    lv_label_set_long_mode(music_artist_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(music_artist_label_, 220);
    lv_obj_set_style_text_align(music_artist_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(music_artist_label_, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_artist_label_, &music_text_font_, LV_PART_MAIN);
    lv_obj_align(music_artist_label_, LV_ALIGN_TOP_MID, 0, 7);

    music_song_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_song_label_, "Название песни");
    lv_label_set_long_mode(music_song_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(music_song_label_, 224);
    lv_obj_set_style_text_align(music_song_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(music_song_label_, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_song_label_, &music_text_font_, LV_PART_MAIN);
    lv_obj_align(music_song_label_, LV_ALIGN_TOP_MID, 0, 25);

    music_status_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_status_label_, "Ожидание");
    lv_obj_set_style_text_color(music_status_label_, lv_color_make(0, 175, 235), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_status_label_, &music_text_font_, LV_PART_MAIN);
    lv_obj_align(music_status_label_, LV_ALIGN_TOP_MID, 0, 49);

    music_volume_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_volume_label_, "Громкость");
    lv_obj_set_style_text_color(music_volume_label_, lv_color_make(0, 175, 235), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_volume_label_, &music_text_font_, LV_PART_MAIN);
    lv_obj_align(music_volume_label_, LV_ALIGN_TOP_MID, 0, 67);

    music_playlist_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_playlist_label_, "");
    lv_label_set_long_mode(music_playlist_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(music_playlist_label_, 220);
    lv_obj_set_height(music_playlist_label_, 82);
    lv_obj_set_style_text_align(music_playlist_label_, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN);
    lv_obj_set_style_text_color(music_playlist_label_, lv_color_make(0, 175, 235), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_playlist_label_, &music_text_font_, LV_PART_MAIN);
    lv_obj_align(music_playlist_label_, LV_ALIGN_TOP_MID, 0, 86);

    // Minimal controls remain at the bottom for builds that have a touch input.
    const int xs[3] = {25, 96, 167};
    const char* labels[3] = {"|<", "STOP", ">|"};
    for (int i = 0; i < 3; ++i) {
        lv_obj_t* btn = lv_btn_create(music_ui_root_);
        music_buttons_[i] = btn;
        lv_obj_set_size(btn, 48, 28);
        lv_obj_set_pos(btn, xs[i], 183);
        lv_obj_set_style_radius(btn, 2, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_black(), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_color(btn, lv_color_make(0, 170, 235), LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 1, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(i + 1)));
        lv_obj_add_event_cb(btn, MusicUiEvent, LV_EVENT_CLICKED, this);
        lv_obj_t* label = lv_label_create(btn);
        lv_label_set_text(label, labels[i]);
        if (i == 1) music_center_button_label_ = label;
        lv_obj_set_style_text_color(label, lv_color_make(0, 190, 255), LV_PART_MAIN);
        lv_obj_set_style_text_font(label, &music_text_font_, LV_PART_MAIN);
        lv_obj_center(label);
    }
    lv_obj_add_flag(music_ui_root_, LV_OBJ_FLAG_HIDDEN);
}

void ZhengchenWebRadio::ShowMusicUi(bool show) {
    EnsureMusicUi();
    if (!music_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    {
        DisplayLockGuard lock(display);
        if (!lock) return;
        if (show) {
            UpdateMusicUiLocked();
            lv_obj_clear_flag(music_ui_root_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_move_foreground(music_ui_root_);
            music_ui_visible_ = true;
        } else {
            lv_obj_add_flag(music_ui_root_, LV_OBJ_FLAG_HIDDEN);
            music_ui_visible_ = false;
        }
    }
    display->SetRadioLowMotionMode(show);
}

void ZhengchenWebRadio::UpdateMusicUi() {
    if (!music_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    DisplayLockGuard lock(display);
    if (!lock) return;
    UpdateMusicUiLocked();
}

void ZhengchenWebRadio::UpdateMusicUiLocked() {
    if (!music_ui_root_) return;
    if (music_player_) {
        const std::string artist_raw = music_player_->GetCurrentArtist().empty() ? "Неизвестный исполнитель" : music_player_->GetCurrentArtist();
        const std::string artist = MusicUppercaseArtist(artist_raw);
        const std::string song = music_player_->GetCurrentSong().empty() ? "Попросите включить песню" : music_player_->GetCurrentSong();
        lv_label_set_text(music_artist_label_, artist.c_str());
        lv_label_set_text(music_song_label_, song.c_str());
        std::string playlist_text;
        if (playlist_active_.load() && !playlist_items_.empty()) {
            const size_t max_rows = 5;
            const int active_index = playlist_current_index_.load();
            for (size_t i = 0; i < playlist_items_.size() && i < max_rows; ++i) {
                if (i) playlist_text += "\n";
                const bool selected = active_index == static_cast<int>(i);
                if (selected) playlist_text += "#FFFFFF ";
                playlist_text += (playlist_items_[i].second.empty() ? "" : playlist_items_[i].second + " — ");
                playlist_text += playlist_items_[i].first;
                if (selected) playlist_text += "#";
            }
            if (playlist_items_.size() > max_rows) playlist_text += "\n…";
        }
        if (music_playlist_label_) {
            lv_label_set_recolor(music_playlist_label_, true);
            lv_label_set_text(music_playlist_label_, playlist_text.c_str());
        }
        const bool playing = music_player_->IsPlaying();
        lv_label_set_text(music_status_label_, playing ? "<<<play>>>" : "ОСТАНОВЛЕНО");
        if (music_center_button_label_) lv_label_set_text(music_center_button_label_, playing ? "STOP" : "PLAY");
    }
    char volume[24];
    snprintf(volume, sizeof(volume), "Громкость %d%%", Esp32Music::GetVolume());
    lv_label_set_text(music_volume_label_, volume);
}

void ZhengchenWebRadio::MusicUiEvent(lv_event_t* event) {
    auto* self = static_cast<ZhengchenWebRadio*>(lv_event_get_user_data(event));
    lv_obj_t* target = lv_event_get_target_obj(event);
    if (!self || !target) return;
    intptr_t action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(target));
    if (action < 1 || action > 6) {
        lv_obj_t* parent = lv_obj_get_parent(target);
        if (parent) action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(parent));
    }
    if (action < 1 || action > 6) return;
    // Claim the tap synchronously before dispatching the slow action to a task.
    // This closes the race with the board's parallel CST816S touch handler.
    const int64_t event_now = esp_timer_get_time();
    if (event_now - self->last_music_action_us_ < 450000) return;
    self->last_music_action_us_ = event_now;
    struct Args { ZhengchenWebRadio* self; int action; };
    auto* args = new (std::nothrow) Args{self, static_cast<int>(action)};
    if (!args) return;
    if (xTaskCreate([](void* raw) {
        auto* a = static_cast<Args*>(raw);
        ZhengchenWebRadio* s = a->self;
        const int act = a->action;
        delete a;
        if (act == 6) {
                ESP_LOGI(TAG, "Returning from music player to assistant; stopping music");
                if (s->music_player_) s->music_player_->StopStreaming();
                auto& audio = Application::GetInstance().GetAudioService();
                audio.ResetDecoder();
                for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                s->CancelSilentStandbyTimer();
                ZhengchenWebRadio::SetAssistantDuck(false);
                s->ShowMusicUi(false);
                Application::GetInstance().ExitRadioSilentIdle();
                Application::GetInstance().ToggleChatState();
                Application::GetInstance().ResetIdleDisplayTimer();
                ZhengchenWebRadio::UpdateWifiPowerSave();
            } else if (act == 1) s->MoveMusicHistory(-1);
            else if (act == 3) s->MoveMusicHistory(1);
            else if (act == 2) {
                if (s->music_player_ && s->music_player_->IsPlaying()) {
                    s->music_player_->StopStreaming();
                    auto& audio = Application::GetInstance().GetAudioService();
                    audio.ResetDecoder();
                    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                } else if (s->music_history_index_ >= 0 && s->music_history_index_ < (int)s->music_history_.size()) {
                    const auto item = s->music_history_[s->music_history_index_];
                    s->PlayMusicSearch(item.first, item.second, false);
                }
                s->UpdateMusicUi();
            } else {
                Esp32Music::SetVolume(Esp32Music::GetVolume() + (act == 4 ? -5 : 5));
                s->UpdateMusicUi();
            }
        vTaskDelete(nullptr);
    }, "music_ui_action", 4096, args, 4, nullptr) != pdPASS) delete args;
}

void ZhengchenWebRadio::StartSilentStandbyTimer() {
    if (!silent_standby_timer_) {
        esp_timer_create_args_t args = {
            .callback = &ZhengchenWebRadio::SilentStandbyTimerCallback,
            .arg = this,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "radio_silent_idle",
            .skip_unhandled_events = true,
        };
        if (esp_timer_create(&args, &silent_standby_timer_) != ESP_OK) {
            silent_standby_timer_ = nullptr;
            ESP_LOGW(TAG, "Failed to create 10s silent standby timer");
            return;
        }
    }
    esp_timer_stop(silent_standby_timer_);
    esp_timer_start_once(silent_standby_timer_, 10 * 1000 * 1000);
}

void ZhengchenWebRadio::CancelSilentStandbyTimer() {
    if (silent_standby_timer_) {
        esp_timer_stop(silent_standby_timer_);
    }
}

bool ZhengchenWebRadio::HandlePhysicalButton(bool up, bool long_press) {
    if (!IsRadioUiVisible()) return false;
    auto codec = Board::GetInstance().GetAudioCodec();
    if (music_ui_visible_) {
        if (long_press) {
            // Long press in the music player skips tracks; search runs in its worker.
            MoveMusicHistory(up ? 1 : -1);
        } else {
            // Short press changes volume in 5% steps and refreshes the player immediately.
            if (codec) {
                int volume = codec->output_volume() + (up ? 5 : -5);
                volume = std::max(0, std::min(100, volume));
                codec->SetOutputVolume(volume);
            }
            UpdateMusicUi();
        }
        return true;
    }
    if (long_press) {
        if (!codec) return true;
        int volume = codec->output_volume() + (up ? 5 : -5);
        volume = std::max(0, std::min(100, volume));
        codec->SetOutputVolume(volume);
        UpdateRadioUiVolumeLabel();
        return true;
    }
    if (radio_ui_visible_) {
        if (up) NextStation();
        else {
            int prev = current_slot_ - 1;
            if (prev < 0) prev = static_cast<int>(stations_.size()) - 1;
            if (prev >= 0) StartRadio(prev);
        }
        return true;
    }
    return false;
}

void ZhengchenWebRadio::UpdateRadioUiVolumeLabel() {
    if (!radio_volume_label_) return;
    auto display = Board::GetInstance().GetDisplay();
    auto codec = Board::GetInstance().GetAudioCodec();
    if (!display || !codec) return;
    DisplayLockGuard lock(display);
    if (!lock) return;
    char text[12];
    snprintf(text, sizeof(text), "%d%%", codec->output_volume());
    lv_label_set_text(radio_volume_label_, text);
}

bool ZhengchenWebRadio::StopRadio() {
    pending_station_slot_.store(-1);
    CancelSilentStandbyTimer();
    SetAssistantDuck(false);
    const auto state_before_stop = Application::GetInstance().GetDeviceState();
    const bool assistant_was_active = state_before_stop == kDeviceStateListening ||
                                      state_before_stop == kDeviceStateSpeaking ||
                                      state_before_stop == kDeviceStateConnecting;
    const bool active = radio_.IsPlaying() || radio_.IsDownloading();
    if (active) {
        ESP_LOGD(TAG, "Stopping radio");
    }
    const bool stopped = radio_.Stop();
    current_slot_ = -1;
    ShowRadioUi(false);
    // A stop command is often executed as an MCP action inside the active voice
    // turn. Do not tear down that turn; only leave radio-silent-idle when it was
    // already an idle radio-only session.
    if (!assistant_was_active) Application::GetInstance().ExitRadioSilentIdle();
    UpdateWifiPowerSave();
    return stopped;
}
