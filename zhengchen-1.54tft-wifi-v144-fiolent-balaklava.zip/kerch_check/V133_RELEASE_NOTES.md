# Zhengchen 1.54 TFT WiFi — v133

This archive targets **Zhengchen 1.54 TFT WiFi / ESP32-S3 only**. The GitHub Actions workflow is unchanged.

## Included

- Currency MCP tools (`self.currency.get_rates`, `self.currency.convert`) using the CBR daily rates API.
- Random joke MCP tool (`self.jokes.random`) using rzhunemogu.ru.
- Zhengchen-owned copy of the radio/music/web/MCP service. The Zhengchen board-local source glob compiles `boards/zhengchen/1.54tft-wifi/zhengchen_web_radio.cc`; it does not compile `boards/taiji-pi-s3/taiji_web_radio.cc`. The Taiji Pi board files were not modified.
- Automatic firmware version discovery is disabled for Zhengchen. The startup request to the Xiaozhi/Tenclass configuration endpoint is intentionally retained because it supplies MQTT/WebSocket credentials, activation data and server time. Firmware is still updated manually with the existing flashing workflow.
- Initial MQTT connection failures now schedule a retry without requiring a reboot; retries are permitted during startup/activation as well as idle.
- OTA/configuration retry backoff is capped at 30 seconds instead of growing without a bound.
- Audio task creation is checked, failed task creation can be retried, and task handles are cleared when tasks exit so a service restart can recreate them.
- AFE/audio-engine initialization gets a second attempt; a failed MultiNet initialization no longer clears the selected detector before retry.
- Startup diagnostics report missing audio tasks and protocol startup failures.

## Validation notes

- ZIP structure and CRC are checked before delivery.
- Source-level checks verify that Zhengchen selects its own radio/MCP source and that the Taiji Pi radio source is excluded from the Zhengchen CMake branch.
- A full ESP-IDF firmware build and hardware boot test were not run in this environment. Please run the existing manual GitHub Actions workflow and share the complete build log if it reports an error.
