# Zhengchen 1.54 TFT WiFi — v134

## Build fix
- Added a Zhengchen-local copy of `radio_face_image.h`, required by `zhengchen_web_radio.cc`.
- The Zhengchen radio source now resolves its board-local artwork header without adding the Taiji Pi board directory to Zhengchen include paths.
- No Taiji Pi source, board configuration, or build workflow was changed.

## Scope
- Based on v133; all v133 startup retry, audio initialization, firmware-update-discovery, and Zhengchen MCP changes are retained.

## Validation
- ZIP integrity and source/include dependency checks performed.
- Verified all quoted includes in the Zhengchen radio source/header resolve either to a project file in the configured main/include paths or to an ESP-IDF/component header.
- Full ESP-IDF build and hardware test were not run in this environment.
