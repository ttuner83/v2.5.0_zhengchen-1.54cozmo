# v135 — board-specific radio ducking bridge and Taiji dependency audit

## Fixed
- Fixed the Zhengchen linker failure caused by shared audio sources directly referencing `TaijiWebRadio::IsAssistantDuckActive()` while the Zhengchen build links `ZhengchenWebRadio` instead.
- Added `main/boards/common/radio_assistant_duck.h`, a small Kconfig-selected bridge. Taiji builds continue to call `TaijiWebRadio`; Zhengchen builds call `ZhengchenWebRadio`; boards without either web-radio service get a safe no-op implementation.
- Updated the shared radio decoder and MP3 music output paths to use that bridge. The existing 3% duck gain while the assistant is active is preserved, and MP3 completion/error/stop paths still clear the duck state on the selected board.
- Removed Taiji-specific User-Agent branding from shared music and drone-map HTTP requests; request behavior is unchanged.

## Audit findings
- Verified that Zhengchen's `zhengchen_web_radio.h/.cc` implementation matches the Taiji radio implementation after normalizing the class name, header name, and intentional board branding differences. No radio, music, web UI, station, playlist, timeout, power-save, voice-command, or MCP methods were dropped in the port.
- Verified that CMake selects the Zhengchen board-local source for Zhengchen and does not compile `boards/taiji-pi-s3/taiji_web_radio.cc`; Taiji Pi continues to select its original source.
- Kept the Zhengchen-local `radio_face_image.h` dependency from v134. No Taiji include directory was added to the Zhengchen build.
- No GitHub Actions workflow, board configuration, display, microphone, or hardware-driver files were changed.

## Validation limits
- ZIP integrity, source-reference checks, Kconfig-branch checks, and normalized Taiji/Zhengchen radio implementation parity checks were run.
- A full ESP-IDF compile/link and physical-device test were not run in this environment. Run the existing Zhengchen GitHub Actions workflow to confirm the final toolchain build.
