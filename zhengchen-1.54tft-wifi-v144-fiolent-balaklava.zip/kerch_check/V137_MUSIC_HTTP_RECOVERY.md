# Zhengchen v137 — MP3 HTTP recovery and board-radio cleanup

Based on Zhengchen v136.

## Music transport
- Raises the MP3 transport timeout floor to 35 seconds.
- Tracks the advertised response body length and distinguishes normal EOF from a truncated response.
- Adds three bounded recovery attempts spaced 650 ms apart (about 1.95 seconds total) when the response ends before the advertised length, or when the initial response is empty.
- Retries an empty initial response from byte zero; after partial data, resumes only with an HTTP 206 Range response at the exact received byte offset. A server that ignores Range is rejected to avoid corrupting the MP3 stream.
- Logs HTTP status, Content-Length/body length, Content-Type, Content-Range, received byte count, and recovery outcome.
- Returns a read error after exhausted recovery rather than reporting a truncated MP3 as clean EOF.
- Uses a neutral `ESP32-Xiaozhi/2.5 (ESP32-S3)` User-Agent in music search/metadata/audio HTTP paths instead of the old Taiji-labelled string.
- Clarifies in logs that the playback-start callback means the player has decoded its first audio frame; `Play()` returning true only means the asynchronous start was accepted.

## MP3 decoder
The `mydazy/esp_mp3_player` component remains at the existing `^0.2.0` dependency. Its documented v0.2.0 behavior already tolerates up to 16 consecutive decode errors before rejecting a stream with no valid MP3 frame. The component source is not vendored in this project archive, so its internal decoder threshold was not changed. The additional ~2 seconds are applied at the HTTP transport boundary, where the observed zero-byte/truncated response occurs.

## Board-radio separation
- Adds `radio_service.h` with a board-selected `ActiveWebRadio` alias.
- Removes the Zhengchen-side `using TaijiWebRadio = ZhengchenWebRadio` compatibility alias from `application.cc`.
- Common application and ducking code now call the board-neutral `ActiveWebRadio`; Taiji implementation files remain available only for Taiji builds, selected by the existing board configuration/CMake conditions.
- No workflow files, board pin mappings, display, microphone, or wake-word configuration were changed.

## Validation
Source-level checks and archive structure checks only. A full ESP-IDF build and hardware playback test were not performed.
