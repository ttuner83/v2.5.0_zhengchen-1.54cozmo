# Zhengchen v138 — Taiji/Spotpear player lifecycle port

Base: Zhengchen v137. The Zhengchen 240x240 music-player UI and board-specific I2S/audio codec are retained.

Changes:
- Restored Taiji-style playlist generation tokens and cancellation checks.
- A standalone `self.music.play_song` request now uses generation 0 and is not incorrectly rejected because `playlist_active` is false. The previous v137 condition could stop a successfully resolved single track immediately after `Esp32Music::Download()` had already called `Mp3Player::Play()`.
- Voice/BOOT takeover invalidates playlist generations, includes in-flight music searches in the stop path, resets the assistant decoder queue and waits for output drain.
- Restored the Taiji-style playlist worker lifecycle and bounded playlist parsing (maximum 20 entries), preserving Zhengchen's playlist UI data model.
- Restored independent persisted music volume (`radio/music_volume`) and connected the existing Zhengchen music UI volume controls to it, rather than changing the assistant codec volume.
- Restored MCP `self.music.get_volume` and `self.music.set_volume` tools.
- Kept v137 HTTP read recovery, 35-second minimum timeout, diagnostics, neutral music User-Agent, ZhengchenWebRadio and Zhengchen screen layout.

Not changed:
- GitHub Actions workflows.
- Zhengchen board pinout, standard I2S codec, microphone, AEC, display, buttons, or screen layout.
- Taiji board source files.

Validation: ZIP integrity and source-level structural checks only. No full ESP-IDF build or hardware playback test was performed.
