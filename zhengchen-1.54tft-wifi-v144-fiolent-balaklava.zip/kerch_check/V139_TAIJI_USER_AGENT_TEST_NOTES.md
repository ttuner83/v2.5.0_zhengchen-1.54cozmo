# Zhengchen v139 — Taiji v124 music User-Agent test

Base: Zhengchen v138.

## Single controlled change

In `main/boards/common/esp32_music.cc`, all four music HTTP request paths now use the exact User-Agent string from Taiji v124:

`Mozilla/5.0 (compatible; XiaozhiTaijiRadio/1.0)`

This applies to the music search/metadata/audio HTTP paths that previously used `ESP32-Xiaozhi/2.5 (ESP32-S3)`.

## Deliberately unchanged

- v138 Taiji-derived single-track and playlist lifecycle logic
- v138 independent music volume and MCP volume controls
- v137 HTTP timeout, retry, Range-resume and response diagnostics
- Zhengchen 240x240 player UI, board-specific I2S/audio codec, microphone and buttons
- GitHub Actions workflow files

No other source behavior was intentionally changed. This archive has been structurally checked, but a full ESP-IDF build and a device playback test have not been performed.
