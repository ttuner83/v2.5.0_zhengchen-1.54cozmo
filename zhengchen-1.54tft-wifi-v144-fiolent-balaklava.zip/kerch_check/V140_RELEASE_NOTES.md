# Zhengchen v140 — physical volume controls and persistent source volumes

Based on v139 (Taiji-compatible music HTTP User-Agent retained).

Changes:
- Short physical +/- presses adjust the active source volume in 5% steps.
- Long +/- presses skip forward/backward in the music playlist, or switch next/previous Internet radio station.
- When neither music nor radio is active, short +/- presses adjust assistant output volume in 5% steps; long presses are ignored in assistant mode.
- Assistant, music player, and radio volumes are stored independently (0–100%) and persisted in Settings.
- Web settings expose three independent source volume values; saving updates persistent settings and active codec/source volume.
- Rapid track/station switch requests are coalesced in the worker with a 300 ms debounce window; network work remains outside button callbacks.
- Existing radio/music HTTP implementation and User-Agent from v139 retained.

Validation: ZIP structure/CRC and source-level checks only. A full ESP-IDF build and device test have not been performed in this environment.
