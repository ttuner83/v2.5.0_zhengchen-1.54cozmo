# Zhengchen v142 — Argus location coverage, rocket alerts, instant volume feedback

Based on v141. GitHub Actions workflows are unchanged.

## Argus
- Added independent handling of active UAV/drone and missile/rocket threat records from Argus.
- The voice result reports the two threat classes separately and no longer describes an active event with an unresolved location as a clear sky.
- Expanded Russian location aliases for Saki, Sovietsky, Krasnogvardeyskoye, Gvardeyskoye and additional districts/settlements.
- Retained morphology-aware matching for common Russian grammatical forms and expanded event text fields to include road/route/direction names.
- Added explicit Tavrida and selected route aliases. District/route anchors are approximate; exact event coordinates from the source take precedence when present.

## Volume
- Music player range is now 0–150% in the web settings and MCP volume tool; assistant and radio remain 0–100%.
- Added up to 1.5x software gain for music PCM with a soft-knee peak limiter to reduce hard clipping.
- Music, radio and assistant volume changes update their live value immediately and defer NVS writes until 800 ms after the last change, coalescing rapid presses.
- Assistant button volume uses a cached current value rather than reading NVS on every press.

## Validation
- ZIP structure and CRC checked.
- Existing workflow files compared with v141 and retained unchanged.
- ESP-IDF compilation and physical-device testing were not run in this environment.
