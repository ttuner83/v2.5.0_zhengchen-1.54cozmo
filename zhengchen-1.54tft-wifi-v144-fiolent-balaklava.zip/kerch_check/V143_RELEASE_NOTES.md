# Zhengchen v143 — expanded Crimean place matching, background music search, 2× player gain

Based on v142. Existing GitHub Actions workflows are unchanged.

## Argus location recognition
- Added Feodosia and nearby settlements/areas: Beregovoye, Primorsky, Nasypnoye, Blizhneye, Ordzhonikidze, Shchebetovka, Kurortnoye, Krasnokamenka, Yuzhnoye, Solnechnoye and Blizhniye Kamyshi.
- Added Kacha and Belbek, including common grammatical forms and Belbek airfield references.
- Expanded Tarkhankut and Olenevka forms, plus all common grammatical variants of Novofedorovka and Feodosia.
- Added more event text keys for city/town/village/settlement, road, highway, route, direction and location text fields.
- Place pins are approximate map anchors when Argus does not provide coordinates; coordinates from an event remain preferred.

## Music search
- `self.music.play_song` now launches search and playback handoff in a dedicated FreeRTOS task and returns immediately to the assistant/MCP caller instead of holding the tool response open during slow HTTP requests.
- A second request while a search is active is rejected as already in progress; playlist generation is invalidated when a new single-track request starts.
- Search itself still depends on Meting/NetEase network response and can fail later; failures are logged on-device rather than being returned synchronously through the MCP call.

## Music player gain
- Replaced the previous 150% ceiling with 200% (2.0× digital PCM gain) in the player settings and MCP tool.
- Gain is applied to the music PCM path before the shared codec, preserving independent assistant and radio levels.
- Soft-knee peak limiting is retained to reduce hard clipping. 2× is a signal-amplitude multiplier (+6 dB), not a guarantee of twice the perceived loudness; source mastering and speaker/amplifier headroom still limit the result.
- Assistant and radio remain capped at 100%.

## Validation
- ZIP structure and CRC checked.
- Existing workflow files compared with v142 and retained unchanged.
- ESP-IDF compilation and physical-device testing were not run in this environment.
