idf_component_register(
    SRCS "AsyncTimer.cpp"
         "BlinkAssistant.cpp"
         "Eye.cpp"
         "EyeBlink.cpp"
         "EyeTransition.cpp"
         "EyeTransformation.cpp"
         "EyeVariation.cpp"
         "Face.cpp"
         "FaceBehavior.cpp"
         "FaceExpression.cpp"
         "LookAssistant.cpp"
         "eye_fb.cpp"
         "cozmo_eyes.cpp"
    INCLUDE_DIRS "."
)

# The ported esp32-eyes library (https://github.com/playfultechnology/esp32-eyes)
# is licensed under AGPL v3. See the individual file headers.
