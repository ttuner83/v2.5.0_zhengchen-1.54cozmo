#include "cozmo_eyes.h"

#include "Face.h"
#include "eye_fb.h"

#include "esp_heap_caps.h"
#include "esp_random.h"
#include "esp_timer.h"
#include <algorithm>
#include <cmath>

namespace {

// Maps XiaoZhi emotion names onto esp32-eyes expressions.
const char* MapEmotion(const std::string& emotion) {
    if (emotion == "neutral" || emotion == "normal" || emotion == "relaxed") {
        return (esp_random() & 1) ? "normal" : "unimpressed";
    }
    if (emotion == "happy" || emotion == "loving" || emotion == "delicious") {
        return (esp_random() & 1) ? "happy" : "glee";
    }
    if (emotion == "laughing" || emotion == "funny" || emotion == "kissy" || emotion == "silly") {
        return (esp_random() & 1) ? "glee" : "awe";
    }
    if (emotion == "sad" || emotion == "crying") {
        return (esp_random() & 1) ? "sad" : "worried";
    }
    if (emotion == "angry") {
        return (esp_random() & 1) ? "angry" : "annoyed";
    }
    if (emotion == "embarrassed") {
        return (esp_random() & 1) ? "worried" : "scared";
    }
    if (emotion == "surprised" || emotion == "shocked") {
        return (esp_random() & 1) ? "surprised" : "awe";
    }
    if (emotion == "thinking" || emotion == "confident") {
        return (esp_random() & 1) ? "focused" : "skeptic";
    }
    if (emotion == "winking") {
        return (esp_random() & 1) ? "squint" : "sleepy";
    }
    if (emotion == "cool" || emotion == "confused") {
        return (esp_random() & 1) ? "skeptic" : "suspicious";
    }
    if (emotion == "sleepy") {
        return "sleepy";
    }
    return nullptr;
}

void ApplyExpression(Face* face, const std::string& expression) {
    if (expression == "angry") {
        face->Expression.GoTo_Angry();
    } else if (expression == "glee") {
        face->Expression.GoTo_Glee();
    } else if (expression == "happy") {
        face->Expression.GoTo_Happy();
    } else if (expression == "sad") {
        face->Expression.GoTo_Sad();
    } else if (expression == "worried") {
        face->Expression.GoTo_Worried();
    } else if (expression == "focused") {
        face->Expression.GoTo_Focused();
    } else if (expression == "annoyed") {
        face->Expression.GoTo_Annoyed();
    } else if (expression == "surprised") {
        face->Expression.GoTo_Surprised();
    } else if (expression == "skeptic") {
        face->Expression.GoTo_Skeptic();
    } else if (expression == "frustrated") {
        face->Expression.GoTo_Frustrated();
    } else if (expression == "unimpressed") {
        face->Expression.GoTo_Unimpressed();
    } else if (expression == "sleepy") {
        face->Expression.GoTo_Sleepy();
    } else if (expression == "suspicious") {
        face->Expression.GoTo_Suspicious();
    } else if (expression == "squint") {
        face->Expression.GoTo_Squint();
    } else if (expression == "furious") {
        face->Expression.GoTo_Furious();
    } else if (expression == "scared") {
        face->Expression.GoTo_Scared();
    } else if (expression == "awe") {
        face->Expression.GoTo_Awe();
    } else {
        face->Expression.GoTo_Normal();
    }
}

}  // namespace

CozmoEyes::CozmoEyes(int virtual_w, int virtual_h, int eye_size, int scale) {
    width_ = virtual_w * scale;
    height_ = virtual_h * scale;

    size_t bytes = static_cast<size_t>(width_) * height_ * sizeof(uint16_t);
    fb_ = static_cast<uint16_t*>(heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM));
    if (fb_ == nullptr) {
        fb_ = static_cast<uint16_t*>(malloc(bytes));
    }
    g_fb.Configure(fb_, width_, height_, scale);

    face_ = std::make_unique<Face>(virtual_w, virtual_h, eye_size);
    // Keep the emotion selected by the application instead of switching randomly.
    face_->RandomBehavior = false;
    // Natural autonomous behaviour.
    face_->RandomLook = true;
    face_->RandomBlink = true;
    face_->CenterX = 60;
    face_->CenterY = 43;
    face_->EyeSize = 29;
    face_->EyeInterDistance = 8;
    face_->Expression.GoTo_Normal();
}

CozmoEyes::~CozmoEyes() {
    face_.reset();
    if (fb_ != nullptr) {
        free(fb_);
    }
}

void CozmoEyes::SetColors(uint16_t bg, uint16_t ink) {
    std::lock_guard<std::mutex> lk(mutex_);
    g_fb.bg = bg;
    g_fb.ink = ink;
}

void CozmoEyes::SetEmotion(const std::string& emotion) {
    std::lock_guard<std::mutex> lk(mutex_);
    current_emotion_ = emotion;
}

// <<ttuner83>> Cosmo facial expression and speech-lip animation control.
void CozmoEyes::SetSpeaking(bool speaking) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (speaking && !speaking_) {
        speaking_started_us_ = esp_timer_get_time();
        mouth_phase_us_ = 0;
    }
    speaking_ = speaking;
}

// <<ttuner83>> Custom 240x240 Cosmo renderer: randomized expression variants and outlined animated lips.
void CozmoEyes::Update() {
    if (face_ == nullptr || fb_ == nullptr) {
        return;
    }

    // Hold the lock for the whole frame so SetEmotion/SetColors
    // (called from other tasks) never race the render.
    std::lock_guard<std::mutex> lk(mutex_);

    if (current_emotion_ != last_applied_) {
        const char* expr = MapEmotion(current_emotion_);
        ApplyExpression(face_.get(), expr != nullptr ? expr : "normal");
        last_applied_ = current_emotion_;
    }

    face_->Update();

    // Draw only the lip contours. The mouth follows a varied, speech-like
    // aperture; no pixels inside the lips are filled.
    const int cx = width_ / 2;
    const int cy = 176;
    auto plot = [&](int x, int y) {
        if (x >= 1 && x < width_ - 1 && y >= 1 && y < height_ - 1) {
            fb_[y * width_ + x] = g_fb.ink;
        }
    };
    auto line = [&](float x0, float y0, float x1, float y1) {
        const int steps = std::max(1, static_cast<int>(std::max(fabsf(x1-x0), fabsf(y1-y0)) * 1.5f));
        for (int i = 0; i <= steps; ++i) {
            const float t = static_cast<float>(i) / steps;
            plot(cx + static_cast<int>(x0 + (x1-x0)*t), cy + static_cast<int>(y0 + (y1-y0)*t));
        }
    };

    float width_factor = 1.0f;
    float opening = 0.0f;
    float asymmetry = 0.0f;
    if (speaking_) {
        const int64_t now = esp_timer_get_time();
        const int64_t elapsed = now - speaking_started_us_;
        // The voice often starts slightly after the status changes.
        if (elapsed >= 1500000) {
            const float t = static_cast<float>(elapsed - 1500000) / 1000000.0f * 1.8f;
            const float cycle = fmodf(t, 2.35f);
            // Short, irregular closures imitate the gaps between words.
            const bool pause = (cycle > 0.73f && cycle < 0.86f) ||
                               (cycle > 1.61f && cycle < 1.76f) ||
                               (cycle > 2.13f);
            if (!pause) {
                const float a = 0.5f + 0.5f * sinf(t * 8.1f + 0.3f * sinf(t * 2.7f));
                const float b = 0.5f + 0.5f * sinf(t * 4.9f + 1.2f);
                opening = 1.0f + 8.5f * a + 4.0f * b;
                width_factor = 1.0f + 0.13f * sinf(t * 3.3f) + 0.06f * sinf(t * 7.7f);
                asymmetry = 1.5f * sinf(t * 5.2f);
            }
        }
    }

    const float half_w = 25.0f * width_factor; // wider, more natural lips
    // Cupid's bow and the two soft upper-lip lobes.
    for (int i = 0; i <= 48; ++i) {
        const float u = -1.0f + 2.0f * i / 48.0f;
        const float x = u * half_w;
        const float arch = 1.0f - u*u;
        const float cupid = 1.0f - 0.22f * expf(-((fabsf(u)-0.25f)*(fabsf(u)-0.25f))*90.0f);
        const float upper = -opening * 0.43f * arch + 2.0f * arch * cupid;
        const float lower = opening * 0.57f * arch + 2.0f * arch;
        plot(cx + static_cast<int>(x), cy + static_cast<int>(upper + asymmetry * u));
        plot(cx + static_cast<int>(x), cy + static_cast<int>(lower + asymmetry * u));
    }
    // A subtle inner contour appears only when the mouth opens; it remains
    // an outline, never a filled black or colored shape.
    if (opening > 3.0f) {
        for (int i = 0; i <= 36; ++i) {
            const float u = -0.9f + 1.8f * i / 36.0f;
            const float arch = 1.0f - (u/0.9f)*(u/0.9f);
            plot(cx + static_cast<int>(u * half_w * 0.9f),
                 cy + static_cast<int>(opening * 0.08f + opening * 0.34f * arch));
        }
    }
}

bool CozmoEyes::IsMapped(const std::string& emotion) {
    return MapEmotion(emotion) != nullptr;
}
