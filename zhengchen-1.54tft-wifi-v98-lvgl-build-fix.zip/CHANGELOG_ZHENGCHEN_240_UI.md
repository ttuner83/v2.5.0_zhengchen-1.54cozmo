Zhengchen 1.54 TFT Wi-Fi — square 240x240 UI patch

Changes in this patch:
- Resized the radio and music player screens and their touch hit areas from the Taiji 360x360 layout to the Zhengchen 240x240 display.
- Uses the 240x240 radio artwork at native scale and square screen corners.
- Reduced Cozmo eyes framebuffer from 360x360 to 240x240.
- Pauses the eyes/GIF/chat motion and hides the eyes while media UI is active; restores the eyes when leaving media UI.
- Assistant button and wake-word transition stop radio/music and hide both media overlays before assistant UI takes over.
- Reduced Xiaozhi status/chat label font to Montserrat 12 and nudged status/chat labels away from the eye area.
- Wikipedia response defaults to a short summary; explicit “подробнее/подробно” requests permit longer extracts and “совсем подробно” permits the longest extract.
- RSS tool prompt requests short, grounded, conversational Xiaozhi comments after each news item.

Build note: static source edits only. Run the existing GitHub Actions ESP-IDF build to verify compile/link and hardware touch calibration.


## v97 — Physical-button-only square UI correction

- Removed all LVGL click/touch event handlers and the legacy CST816S touch API from the radio/player integration. The Zhengchen board has no touch input.
- Physical volume-up/down buttons now navigate previous/next track or station on short press while a media screen is active; long press changes media volume. Outside radio/player, the original system volume behavior remains.
- Assistant button takeover stops the music stream, resets the audio decoder, and hides both media layers even when playback state is temporarily stale.
- Radio and player screens mutually hide one another. Their decorative button graphics are non-clickable.
- Player controls are positioned inside the 240x240 screen bounds; smaller labels are used.
- Cozmo eye layer is explicitly hidden and its animation timer paused while radio/player is visible, then restored if it was visible before media mode.
- This is a source-level patch; an ESP-IDF/GitHub Actions build is still required to verify compilation and hardware behavior.
